/*
 * pelco_d.c
 *
 *  Created on: 9 de fev. de 2025
 *      Author: rtek1000
 */




