#ifndef UTIL_H
#define UTIL_H

void putstring(const char *s);
void puthex(unsigned char v);
void puthex2(const unsigned char x);

#endif