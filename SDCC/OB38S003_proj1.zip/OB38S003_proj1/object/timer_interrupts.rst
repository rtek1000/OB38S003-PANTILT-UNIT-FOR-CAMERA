                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.5.0 #15242 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module timer_interrupts
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-small
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _timer2_isr
                                     12 	.globl _timer1_isr
                                     13 	.globl _timer0_isr
                                     14 	.globl _set_timer1_reload
                                     15 	.globl _set_timer0_reload
                                     16 	.globl _motor2_step_ccw
                                     17 	.globl _motor2_step_cc
                                     18 	.globl _motor1_step_ccw
                                     19 	.globl _motor1_step_cc
                                     20 	.globl _clear_capture_flag
                                     21 	.globl _get_capture_mode
                                     22 	.globl _EXEN2
                                     23 	.globl _IEIIC
                                     24 	.globl _IELVI
                                     25 	.globl _IEKBI
                                     26 	.globl _IEADC
                                     27 	.globl _IESPI
                                     28 	.globl _IEPWM
                                     29 	.globl _EXF2
                                     30 	.globl _TF2
                                     31 	.globl _IICIF
                                     32 	.globl _LVIIF
                                     33 	.globl _KBIIF
                                     34 	.globl _ADCIF
                                     35 	.globl _SPIIF
                                     36 	.globl _PWMIF
                                     37 	.globl _MPIF
                                     38 	.globl _LAIF
                                     39 	.globl _RXIF
                                     40 	.globl _TXIF
                                     41 	.globl _RXAK
                                     42 	.globl _TXAK
                                     43 	.globl _BB
                                     44 	.globl _RW
                                     45 	.globl _SM0
                                     46 	.globl _SM1
                                     47 	.globl _SM2
                                     48 	.globl _REN
                                     49 	.globl _TB8
                                     50 	.globl _RB8
                                     51 	.globl _TI
                                     52 	.globl _RI
                                     53 	.globl _EA
                                     54 	.globl _ET2
                                     55 	.globl _ES
                                     56 	.globl _ET1
                                     57 	.globl _EX1
                                     58 	.globl _ET0
                                     59 	.globl _EX0
                                     60 	.globl _TF1
                                     61 	.globl _TR1
                                     62 	.globl _TF0
                                     63 	.globl _TR0
                                     64 	.globl _IE1
                                     65 	.globl _IT1
                                     66 	.globl _IE0
                                     67 	.globl _IT0
                                     68 	.globl _CY
                                     69 	.globl _AC
                                     70 	.globl _F0
                                     71 	.globl _RS1
                                     72 	.globl _RS0
                                     73 	.globl _OV
                                     74 	.globl _F1
                                     75 	.globl _P
                                     76 	.globl _P3_1
                                     77 	.globl _P3_0
                                     78 	.globl _P1_7
                                     79 	.globl _P1_6
                                     80 	.globl _P1_5
                                     81 	.globl _P1_4
                                     82 	.globl _P1_3
                                     83 	.globl _P1_2
                                     84 	.globl _P1_1
                                     85 	.globl _P1_0
                                     86 	.globl _P0_7
                                     87 	.globl _P0_6
                                     88 	.globl _P0_5
                                     89 	.globl _P0_4
                                     90 	.globl _P0_3
                                     91 	.globl _P0_2
                                     92 	.globl _P0_1
                                     93 	.globl _P0_0
                                     94 	.globl _T2
                                     95 	.globl _CRC
                                     96 	.globl _CC3
                                     97 	.globl _CC2
                                     98 	.globl _CC1
                                     99 	.globl _CMP1CON
                                    100 	.globl _CMP0CON
                                    101 	.globl _OPPIN
                                    102 	.globl _IICEBT
                                    103 	.globl _IICRWD
                                    104 	.globl _IICA2
                                    105 	.globl _IICA1
                                    106 	.globl _IICCTL
                                    107 	.globl _IICS
                                    108 	.globl _SPIS
                                    109 	.globl _SPIRXD
                                    110 	.globl _SPITXD
                                    111 	.globl _SPIC2
                                    112 	.globl _SPIC1
                                    113 	.globl _P3M1
                                    114 	.globl _P3M0
                                    115 	.globl _P1M1
                                    116 	.globl _P1M0
                                    117 	.globl _P0M1
                                    118 	.globl _P0M0
                                    119 	.globl _TH2
                                    120 	.globl _TL2
                                    121 	.globl _CRCH
                                    122 	.globl _CRCL
                                    123 	.globl _CCCON
                                    124 	.globl _T2CON
                                    125 	.globl _CCH3
                                    126 	.globl _CCL3
                                    127 	.globl _CCH2
                                    128 	.globl _CCL2
                                    129 	.globl _CCH1
                                    130 	.globl _CCL1
                                    131 	.globl _CCEN2
                                    132 	.globl _CCEN
                                    133 	.globl _WDTK
                                    134 	.globl _WDTC
                                    135 	.globl _PWMMDL
                                    136 	.globl _PWMMDH
                                    137 	.globl _PWMD3L
                                    138 	.globl _PWMD3H
                                    139 	.globl _PWMD2L
                                    140 	.globl _PWMD2H
                                    141 	.globl _PWMD1L
                                    142 	.globl _PWMD1H
                                    143 	.globl _PWMD0L
                                    144 	.globl _PWMD0H
                                    145 	.globl _PWMC
                                    146 	.globl _ADCSH
                                    147 	.globl _ADCCS
                                    148 	.globl _ADCDL
                                    149 	.globl _ADCDH
                                    150 	.globl _ADCC2
                                    151 	.globl _ADCC1
                                    152 	.globl _SWRES
                                    153 	.globl _LVC
                                    154 	.globl _RSTS
                                    155 	.globl _IRCON2
                                    156 	.globl _KBD
                                    157 	.globl _KBF
                                    158 	.globl _KBE
                                    159 	.globl _KBLS
                                    160 	.globl _ENHIT
                                    161 	.globl _INTDEG
                                    162 	.globl _IRCON
                                    163 	.globl _IP1
                                    164 	.globl _IP0
                                    165 	.globl _IEN1
                                    166 	.globl _IEN0
                                    167 	.globl _IEN2
                                    168 	.globl _PFCON
                                    169 	.globl _SRELH
                                    170 	.globl _SRELL
                                    171 	.globl _S0RELH
                                    172 	.globl _S0RELL
                                    173 	.globl _S0BUF
                                    174 	.globl _S0CON
                                    175 	.globl _ISPFC
                                    176 	.globl _ISPFDH
                                    177 	.globl _ISPFDL
                                    178 	.globl _ISPFAL
                                    179 	.globl _ISPFAH
                                    180 	.globl _TAKEY
                                    181 	.globl _IFCON
                                    182 	.globl _AUX
                                    183 	.globl _DPH1
                                    184 	.globl _DPL1
                                    185 	.globl _IP
                                    186 	.globl _IE
                                    187 	.globl _SBUF
                                    188 	.globl _SCON
                                    189 	.globl _CKCON
                                    190 	.globl _TH1
                                    191 	.globl _TH0
                                    192 	.globl _TL1
                                    193 	.globl _TL0
                                    194 	.globl _TMOD
                                    195 	.globl _TCON
                                    196 	.globl _PCON
                                    197 	.globl _DPH
                                    198 	.globl _DPL
                                    199 	.globl _SP
                                    200 	.globl _B
                                    201 	.globl _ACC
                                    202 	.globl _PSW
                                    203 	.globl _P3
                                    204 	.globl _P1
                                    205 	.globl _P0
                                    206 	.globl _timer0_cnt2
                                    207 	.globl _timer0_cnt1
                                    208 	.globl _clear_interrupt_flags_pca
                                    209 	.globl _clear_pca_counter
                                    210 	.globl _init_first_delay_ms
                                    211 	.globl _init_second_delay_us
                                    212 	.globl _init_second_delay_ms
                                    213 	.globl _wait_first_delay_finished
                                    214 	.globl _wait_second_delay_finished
                                    215 	.globl _stop_first_delay
                                    216 	.globl _stop_second_delay
                                    217 	.globl _is_first_delay_finished
                                    218 	.globl _is_second_delay_finished
                                    219 ;--------------------------------------------------------
                                    220 ; special function registers
                                    221 ;--------------------------------------------------------
                                    222 	.area RSEG    (ABS,DATA)
      000000                        223 	.org 0x0000
                           000080   224 _P0	=	0x0080
                           000090   225 _P1	=	0x0090
                           0000B0   226 _P3	=	0x00b0
                           0000D0   227 _PSW	=	0x00d0
                           0000E0   228 _ACC	=	0x00e0
                           0000F0   229 _B	=	0x00f0
                           000081   230 _SP	=	0x0081
                           000082   231 _DPL	=	0x0082
                           000083   232 _DPH	=	0x0083
                           000087   233 _PCON	=	0x0087
                           000088   234 _TCON	=	0x0088
                           000089   235 _TMOD	=	0x0089
                           00008A   236 _TL0	=	0x008a
                           00008B   237 _TL1	=	0x008b
                           00008C   238 _TH0	=	0x008c
                           00008D   239 _TH1	=	0x008d
                           00008E   240 _CKCON	=	0x008e
                           000098   241 _SCON	=	0x0098
                           000099   242 _SBUF	=	0x0099
                           0000A8   243 _IE	=	0x00a8
                           0000A9   244 _IP	=	0x00a9
                           000084   245 _DPL1	=	0x0084
                           000085   246 _DPH1	=	0x0085
                           000091   247 _AUX	=	0x0091
                           00008F   248 _IFCON	=	0x008f
                           0000F7   249 _TAKEY	=	0x00f7
                           0000E1   250 _ISPFAH	=	0x00e1
                           0000E2   251 _ISPFAL	=	0x00e2
                           0000E3   252 _ISPFDL	=	0x00e3
                           0000EB   253 _ISPFDH	=	0x00eb
                           0000E4   254 _ISPFC	=	0x00e4
                           000098   255 _S0CON	=	0x0098
                           000099   256 _S0BUF	=	0x0099
                           0000AA   257 _S0RELL	=	0x00aa
                           0000BA   258 _S0RELH	=	0x00ba
                           0000AA   259 _SRELL	=	0x00aa
                           0000BA   260 _SRELH	=	0x00ba
                           0000D9   261 _PFCON	=	0x00d9
                           00009A   262 _IEN2	=	0x009a
                           0000A8   263 _IEN0	=	0x00a8
                           0000B8   264 _IEN1	=	0x00b8
                           0000A9   265 _IP0	=	0x00a9
                           0000B9   266 _IP1	=	0x00b9
                           0000C0   267 _IRCON	=	0x00c0
                           0000EE   268 _INTDEG	=	0x00ee
                           0000E5   269 _ENHIT	=	0x00e5
                           000093   270 _KBLS	=	0x0093
                           000094   271 _KBE	=	0x0094
                           000095   272 _KBF	=	0x0095
                           000096   273 _KBD	=	0x0096
                           000097   274 _IRCON2	=	0x0097
                           0000A1   275 _RSTS	=	0x00a1
                           0000E6   276 _LVC	=	0x00e6
                           0000E7   277 _SWRES	=	0x00e7
                           0000AB   278 _ADCC1	=	0x00ab
                           0000AC   279 _ADCC2	=	0x00ac
                           0000AD   280 _ADCDH	=	0x00ad
                           0000AE   281 _ADCDL	=	0x00ae
                           0000AF   282 _ADCCS	=	0x00af
                           0000EF   283 _ADCSH	=	0x00ef
                           0000B5   284 _PWMC	=	0x00b5
                           0000BC   285 _PWMD0H	=	0x00bc
                           0000BD   286 _PWMD0L	=	0x00bd
                           0000BE   287 _PWMD1H	=	0x00be
                           0000BF   288 _PWMD1L	=	0x00bf
                           0000B1   289 _PWMD2H	=	0x00b1
                           0000B2   290 _PWMD2L	=	0x00b2
                           0000B3   291 _PWMD3H	=	0x00b3
                           0000B4   292 _PWMD3L	=	0x00b4
                           0000CE   293 _PWMMDH	=	0x00ce
                           0000CF   294 _PWMMDL	=	0x00cf
                           0000B6   295 _WDTC	=	0x00b6
                           0000B7   296 _WDTK	=	0x00b7
                           0000C1   297 _CCEN	=	0x00c1
                           0000D1   298 _CCEN2	=	0x00d1
                           0000C2   299 _CCL1	=	0x00c2
                           0000C3   300 _CCH1	=	0x00c3
                           0000C4   301 _CCL2	=	0x00c4
                           0000C5   302 _CCH2	=	0x00c5
                           0000C6   303 _CCL3	=	0x00c6
                           0000C7   304 _CCH3	=	0x00c7
                           0000C8   305 _T2CON	=	0x00c8
                           0000C9   306 _CCCON	=	0x00c9
                           0000CA   307 _CRCL	=	0x00ca
                           0000CB   308 _CRCH	=	0x00cb
                           0000CC   309 _TL2	=	0x00cc
                           0000CD   310 _TH2	=	0x00cd
                           0000D2   311 _P0M0	=	0x00d2
                           0000D3   312 _P0M1	=	0x00d3
                           0000D4   313 _P1M0	=	0x00d4
                           0000D5   314 _P1M1	=	0x00d5
                           0000DA   315 _P3M0	=	0x00da
                           0000DB   316 _P3M1	=	0x00db
                           0000F1   317 _SPIC1	=	0x00f1
                           0000F2   318 _SPIC2	=	0x00f2
                           0000F3   319 _SPITXD	=	0x00f3
                           0000F4   320 _SPIRXD	=	0x00f4
                           0000F5   321 _SPIS	=	0x00f5
                           0000F8   322 _IICS	=	0x00f8
                           0000F9   323 _IICCTL	=	0x00f9
                           0000FA   324 _IICA1	=	0x00fa
                           0000FB   325 _IICA2	=	0x00fb
                           0000FC   326 _IICRWD	=	0x00fc
                           0000FD   327 _IICEBT	=	0x00fd
                           0000F6   328 _OPPIN	=	0x00f6
                           0000FE   329 _CMP0CON	=	0x00fe
                           0000FF   330 _CMP1CON	=	0x00ff
                           00C3C2   331 _CC1	=	0xc3c2
                           00C5C4   332 _CC2	=	0xc5c4
                           00C7C6   333 _CC3	=	0xc7c6
                           00CBCA   334 _CRC	=	0xcbca
                           00CDCC   335 _T2	=	0xcdcc
                                    336 ;--------------------------------------------------------
                                    337 ; special function bits
                                    338 ;--------------------------------------------------------
                                    339 	.area RSEG    (ABS,DATA)
      000000                        340 	.org 0x0000
                           000080   341 _P0_0	=	0x0080
                           000081   342 _P0_1	=	0x0081
                           000082   343 _P0_2	=	0x0082
                           000083   344 _P0_3	=	0x0083
                           000084   345 _P0_4	=	0x0084
                           000085   346 _P0_5	=	0x0085
                           000086   347 _P0_6	=	0x0086
                           000087   348 _P0_7	=	0x0087
                           000090   349 _P1_0	=	0x0090
                           000091   350 _P1_1	=	0x0091
                           000092   351 _P1_2	=	0x0092
                           000093   352 _P1_3	=	0x0093
                           000094   353 _P1_4	=	0x0094
                           000095   354 _P1_5	=	0x0095
                           000096   355 _P1_6	=	0x0096
                           000097   356 _P1_7	=	0x0097
                           0000B0   357 _P3_0	=	0x00b0
                           0000B2   358 _P3_1	=	0x00b2
                           0000D0   359 _P	=	0x00d0
                           0000D1   360 _F1	=	0x00d1
                           0000D2   361 _OV	=	0x00d2
                           0000D3   362 _RS0	=	0x00d3
                           0000D4   363 _RS1	=	0x00d4
                           0000D5   364 _F0	=	0x00d5
                           0000D6   365 _AC	=	0x00d6
                           0000D7   366 _CY	=	0x00d7
                           000088   367 _IT0	=	0x0088
                           000089   368 _IE0	=	0x0089
                           00008A   369 _IT1	=	0x008a
                           00008B   370 _IE1	=	0x008b
                           00008C   371 _TR0	=	0x008c
                           00008D   372 _TF0	=	0x008d
                           00008E   373 _TR1	=	0x008e
                           00008F   374 _TF1	=	0x008f
                           0000A8   375 _EX0	=	0x00a8
                           0000A9   376 _ET0	=	0x00a9
                           0000AA   377 _EX1	=	0x00aa
                           0000AB   378 _ET1	=	0x00ab
                           0000AC   379 _ES	=	0x00ac
                           0000AD   380 _ET2	=	0x00ad
                           0000AF   381 _EA	=	0x00af
                           000098   382 _RI	=	0x0098
                           000099   383 _TI	=	0x0099
                           00009A   384 _RB8	=	0x009a
                           00009B   385 _TB8	=	0x009b
                           00009C   386 _REN	=	0x009c
                           00009D   387 _SM2	=	0x009d
                           00009E   388 _SM1	=	0x009e
                           00009F   389 _SM0	=	0x009f
                           0000F8   390 _RW	=	0x00f8
                           0000F8   391 _BB	=	0x00f8
                           0000F9   392 _TXAK	=	0x00f9
                           0000FA   393 _RXAK	=	0x00fa
                           0000FB   394 _TXIF	=	0x00fb
                           0000FC   395 _RXIF	=	0x00fc
                           0000FD   396 _LAIF	=	0x00fd
                           0000FE   397 _MPIF	=	0x00fe
                           0000C0   398 _PWMIF	=	0x00c0
                           0000C1   399 _SPIIF	=	0x00c1
                           0000C2   400 _ADCIF	=	0x00c2
                           0000C3   401 _KBIIF	=	0x00c3
                           0000C4   402 _LVIIF	=	0x00c4
                           0000C5   403 _IICIF	=	0x00c5
                           0000C6   404 _TF2	=	0x00c6
                           0000C7   405 _EXF2	=	0x00c7
                           0000B8   406 _IEPWM	=	0x00b8
                           0000B9   407 _IESPI	=	0x00b9
                           0000BA   408 _IEADC	=	0x00ba
                           0000BB   409 _IEKBI	=	0x00bb
                           0000BC   410 _IELVI	=	0x00bc
                           0000BD   411 _IEIIC	=	0x00bd
                           0000BF   412 _EXEN2	=	0x00bf
                                    413 ;--------------------------------------------------------
                                    414 ; overlayable register banks
                                    415 ;--------------------------------------------------------
                                    416 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        417 	.ds 8
                                    418 ;--------------------------------------------------------
                                    419 ; overlayable bit register bank
                                    420 ;--------------------------------------------------------
                                    421 	.area BIT_BANK	(REL,OVR,DATA)
      000021                        422 bits:
      000021                        423 	.ds 1
                           008000   424 	b0 = bits[0]
                           008100   425 	b1 = bits[1]
                           008200   426 	b2 = bits[2]
                           008300   427 	b3 = bits[3]
                           008400   428 	b4 = bits[4]
                           008500   429 	b5 = bits[5]
                           008600   430 	b6 = bits[6]
                           008700   431 	b7 = bits[7]
                                    432 ;--------------------------------------------------------
                                    433 ; internal ram data
                                    434 ;--------------------------------------------------------
                                    435 	.area DSEG    (DATA)
      00001B                        436 _timer0_cnt1::
      00001B                        437 	.ds 1
      00001C                        438 _timer0_cnt2::
      00001C                        439 	.ds 1
                                    440 ;--------------------------------------------------------
                                    441 ; overlayable items in internal ram
                                    442 ;--------------------------------------------------------
                                    443 	.area	OSEG    (OVR,DATA)
                                    444 	.area	OSEG    (OVR,DATA)
                                    445 ;--------------------------------------------------------
                                    446 ; indirectly addressable internal ram data
                                    447 ;--------------------------------------------------------
                                    448 	.area ISEG    (DATA)
                                    449 ;--------------------------------------------------------
                                    450 ; absolute internal ram data
                                    451 ;--------------------------------------------------------
                                    452 	.area IABS    (ABS,DATA)
                                    453 	.area IABS    (ABS,DATA)
                                    454 ;--------------------------------------------------------
                                    455 ; bit data
                                    456 ;--------------------------------------------------------
                                    457 	.area BSEG    (BIT)
      000000                        458 _is_first_delay_finished_sloc0_1_0:
      000000                        459 	.ds 1
      000001                        460 _is_second_delay_finished_sloc0_1_0:
      000001                        461 	.ds 1
                                    462 ;--------------------------------------------------------
                                    463 ; paged external ram data
                                    464 ;--------------------------------------------------------
                                    465 	.area PSEG    (PAG,XDATA)
                                    466 ;--------------------------------------------------------
                                    467 ; uninitialized external ram data
                                    468 ;--------------------------------------------------------
                                    469 	.area XSEG    (XDATA)
      000001                        470 _gTimer0Timeout:
      000001                        471 	.ds 2
      000003                        472 _gTimer1Timeout:
      000003                        473 	.ds 2
                                    474 ;--------------------------------------------------------
                                    475 ; absolute external ram data
                                    476 ;--------------------------------------------------------
                                    477 	.area XABS    (ABS,XDATA)
                                    478 ;--------------------------------------------------------
                                    479 ; initialized external ram data
                                    480 ;--------------------------------------------------------
                                    481 	.area XISEG   (XDATA)
                                    482 	.area HOME    (CODE)
                                    483 	.area GSINIT0 (CODE)
                                    484 	.area GSINIT1 (CODE)
                                    485 	.area GSINIT2 (CODE)
                                    486 	.area GSINIT3 (CODE)
                                    487 	.area GSINIT4 (CODE)
                                    488 	.area GSINIT5 (CODE)
                                    489 	.area GSINIT  (CODE)
                                    490 	.area GSFINAL (CODE)
                                    491 	.area CSEG    (CODE)
                                    492 ;--------------------------------------------------------
                                    493 ; global & static initialisations
                                    494 ;--------------------------------------------------------
                                    495 	.area HOME    (CODE)
                                    496 	.area GSINIT  (CODE)
                                    497 	.area GSFINAL (CODE)
                                    498 	.area GSINIT  (CODE)
                                    499 ;	drivers/ob38s003/src/timer_interrupts.c:24: uint8_t timer0_cnt1 = 0;
      00018C 75 1B 00         [24]  500 	mov	_timer0_cnt1,#0x00
                                    501 ;	drivers/ob38s003/src/timer_interrupts.c:25: uint8_t timer0_cnt2 = 0;
      00018F 75 1C 00         [24]  502 	mov	_timer0_cnt2,#0x00
                                    503 ;--------------------------------------------------------
                                    504 ; Home
                                    505 ;--------------------------------------------------------
                                    506 	.area HOME    (CODE)
                                    507 	.area HOME    (CODE)
                                    508 ;--------------------------------------------------------
                                    509 ; code
                                    510 ;--------------------------------------------------------
                                    511 	.area CSEG    (CODE)
                                    512 ;------------------------------------------------------------
                                    513 ;Allocation info for local variables in function 'clear_interrupt_flags_pca'
                                    514 ;------------------------------------------------------------
                                    515 ;	drivers/ob38s003/src/timer_interrupts.c:44: void clear_interrupt_flags_pca(void) {
                                    516 ;	-----------------------------------------
                                    517 ;	 function clear_interrupt_flags_pca
                                    518 ;	-----------------------------------------
      000500                        519 _clear_interrupt_flags_pca:
                           000007   520 	ar7 = 0x07
                           000006   521 	ar6 = 0x06
                           000005   522 	ar5 = 0x05
                           000004   523 	ar4 = 0x04
                           000003   524 	ar3 = 0x03
                           000002   525 	ar2 = 0x02
                           000001   526 	ar1 = 0x01
                           000000   527 	ar0 = 0x00
                                    528 ;	drivers/ob38s003/src/timer_interrupts.c:47: CCCON &= ~0x0F;
      000500 53 C9 F0         [24]  529 	anl	_CCCON,#0xf0
                                    530 ;	drivers/ob38s003/src/timer_interrupts.c:48: }
      000503 22               [24]  531 	ret
                                    532 ;------------------------------------------------------------
                                    533 ;Allocation info for local variables in function 'clear_pca_counter'
                                    534 ;------------------------------------------------------------
                                    535 ;	drivers/ob38s003/src/timer_interrupts.c:50: void clear_pca_counter(void) {
                                    536 ;	-----------------------------------------
                                    537 ;	 function clear_pca_counter
                                    538 ;	-----------------------------------------
      000504                        539 _clear_pca_counter:
                                    540 ;	drivers/ob38s003/src/timer_interrupts.c:54: T2CON &= ~0x03;
      000504 53 C8 FC         [24]  541 	anl	_T2CON,#0xfc
                                    542 ;	drivers/ob38s003/src/timer_interrupts.c:59: TH2 = 0x00;
      000507 75 CD 00         [24]  543 	mov	_TH2,#0x00
                                    544 ;	drivers/ob38s003/src/timer_interrupts.c:60: TL2 = 0x00;
      00050A 75 CC 00         [24]  545 	mov	_TL2,#0x00
                                    546 ;	drivers/ob38s003/src/timer_interrupts.c:63: T2CON |= 0x01;
      00050D 43 C8 01         [24]  547 	orl	_T2CON,#0x01
                                    548 ;	drivers/ob38s003/src/timer_interrupts.c:64: }
      000510 22               [24]  549 	ret
                                    550 ;------------------------------------------------------------
                                    551 ;Allocation info for local variables in function 'set_timer0_reload'
                                    552 ;------------------------------------------------------------
                                    553 ;reload        Allocated to registers r7 
                                    554 ;------------------------------------------------------------
                                    555 ;	drivers/ob38s003/src/timer_interrupts.c:76: void set_timer0_reload(const uint8_t reload) {
                                    556 ;	-----------------------------------------
                                    557 ;	 function set_timer0_reload
                                    558 ;	-----------------------------------------
      000511                        559 _set_timer0_reload:
      000511 AF 82            [24]  560 	mov	r7, dpl
                                    561 ;	drivers/ob38s003/src/timer_interrupts.c:78: TH0 = reload;
      000513 8F 8C            [24]  562 	mov	_TH0,r7
                                    563 ;	drivers/ob38s003/src/timer_interrupts.c:80: TL0 = reload;
      000515 8F 8A            [24]  564 	mov	_TL0,r7
                                    565 ;	drivers/ob38s003/src/timer_interrupts.c:81: }
      000517 22               [24]  566 	ret
                                    567 ;------------------------------------------------------------
                                    568 ;Allocation info for local variables in function 'set_timer1_reload'
                                    569 ;------------------------------------------------------------
                                    570 ;reload        Allocated to registers r7 
                                    571 ;------------------------------------------------------------
                                    572 ;	drivers/ob38s003/src/timer_interrupts.c:83: void set_timer1_reload(const uint8_t reload) {
                                    573 ;	-----------------------------------------
                                    574 ;	 function set_timer1_reload
                                    575 ;	-----------------------------------------
      000518                        576 _set_timer1_reload:
      000518 AF 82            [24]  577 	mov	r7, dpl
                                    578 ;	drivers/ob38s003/src/timer_interrupts.c:85: TH1 = reload;
      00051A 8F 8D            [24]  579 	mov	_TH1,r7
                                    580 ;	drivers/ob38s003/src/timer_interrupts.c:87: TL1 = reload;
      00051C 8F 8B            [24]  581 	mov	_TL1,r7
                                    582 ;	drivers/ob38s003/src/timer_interrupts.c:88: }
      00051E 22               [24]  583 	ret
                                    584 ;------------------------------------------------------------
                                    585 ;Allocation info for local variables in function 'init_first_delay_ms'
                                    586 ;------------------------------------------------------------
                                    587 ;timeout       Allocated to registers 
                                    588 ;------------------------------------------------------------
                                    589 ;	drivers/ob38s003/src/timer_interrupts.c:117: void init_first_delay_ms(const uint16_t timeout) {
                                    590 ;	-----------------------------------------
                                    591 ;	 function init_first_delay_ms
                                    592 ;	-----------------------------------------
      00051F                        593 _init_first_delay_ms:
                                    594 ;	drivers/ob38s003/src/timer_interrupts.c:119: PFCON &= ~0x03;
      00051F 53 D9 FC         [24]  595 	anl	_PFCON,#0xfc
                                    596 ;	drivers/ob38s003/src/timer_interrupts.c:120: PFCON |= 0x02;
      000522 43 D9 02         [24]  597 	orl	_PFCON,#0x02
                                    598 ;	drivers/ob38s003/src/timer_interrupts.c:123: set_timer0_reload(TIMER0_RELOAD_1MILLIS);
      000525 75 82 58         [24]  599 	mov	dpl, #0x58
      000528 12 05 11         [24]  600 	lcall	_set_timer0_reload
                                    601 ;	drivers/ob38s003/src/timer_interrupts.c:128: TR0 = true;
                                    602 ;	assignBit
      00052B D2 8C            [12]  603 	setb	_TR0
                                    604 ;	drivers/ob38s003/src/timer_interrupts.c:129: }
      00052D 22               [24]  605 	ret
                                    606 ;------------------------------------------------------------
                                    607 ;Allocation info for local variables in function 'init_second_delay_us'
                                    608 ;------------------------------------------------------------
                                    609 ;timeout       Allocated to registers r6 r7 
                                    610 ;------------------------------------------------------------
                                    611 ;	drivers/ob38s003/src/timer_interrupts.c:134: void init_second_delay_us(const uint16_t timeout) {
                                    612 ;	-----------------------------------------
                                    613 ;	 function init_second_delay_us
                                    614 ;	-----------------------------------------
      00052E                        615 _init_second_delay_us:
      00052E AE 82            [24]  616 	mov	r6, dpl
      000530 AF 83            [24]  617 	mov	r7, dph
                                    618 ;	drivers/ob38s003/src/timer_interrupts.c:136: PFCON &= ~0x0C;
      000532 53 D9 F3         [24]  619 	anl	_PFCON,#0xf3
                                    620 ;	drivers/ob38s003/src/timer_interrupts.c:137: PFCON |= 0x04;
      000535 43 D9 04         [24]  621 	orl	_PFCON,#0x04
                                    622 ;	drivers/ob38s003/src/timer_interrupts.c:140: set_timer1_reload(TIMER1_RELOAD_10MICROS);
      000538 75 82 5F         [24]  623 	mov	dpl, #0x5f
      00053B C0 07            [24]  624 	push	ar7
      00053D C0 06            [24]  625 	push	ar6
      00053F 12 05 18         [24]  626 	lcall	_set_timer1_reload
      000542 D0 06            [24]  627 	pop	ar6
      000544 D0 07            [24]  628 	pop	ar7
                                    629 ;	drivers/ob38s003/src/timer_interrupts.c:144: gTimer1Timeout = timeout;
      000546 90 00 03         [24]  630 	mov	dptr,#_gTimer1Timeout
      000549 EE               [12]  631 	mov	a,r6
      00054A F0               [24]  632 	movx	@dptr,a
      00054B EF               [12]  633 	mov	a,r7
      00054C A3               [24]  634 	inc	dptr
      00054D F0               [24]  635 	movx	@dptr,a
                                    636 ;	drivers/ob38s003/src/timer_interrupts.c:147: TR1 = true;
                                    637 ;	assignBit
      00054E D2 8E            [12]  638 	setb	_TR1
                                    639 ;	drivers/ob38s003/src/timer_interrupts.c:148: }
      000550 22               [24]  640 	ret
                                    641 ;------------------------------------------------------------
                                    642 ;Allocation info for local variables in function 'init_second_delay_ms'
                                    643 ;------------------------------------------------------------
                                    644 ;timeout       Allocated to registers r6 r7 
                                    645 ;------------------------------------------------------------
                                    646 ;	drivers/ob38s003/src/timer_interrupts.c:153: void init_second_delay_ms(const uint16_t timeout) {
                                    647 ;	-----------------------------------------
                                    648 ;	 function init_second_delay_ms
                                    649 ;	-----------------------------------------
      000551                        650 _init_second_delay_ms:
      000551 AE 82            [24]  651 	mov	r6, dpl
      000553 AF 83            [24]  652 	mov	r7, dph
                                    653 ;	drivers/ob38s003/src/timer_interrupts.c:155: PFCON &= ~0x0C;
      000555 53 D9 F3         [24]  654 	anl	_PFCON,#0xf3
                                    655 ;	drivers/ob38s003/src/timer_interrupts.c:156: PFCON |= 0x08;
      000558 43 D9 08         [24]  656 	orl	_PFCON,#0x08
                                    657 ;	drivers/ob38s003/src/timer_interrupts.c:159: set_timer1_reload(TIMER1_RELOAD_1MILLIS);
      00055B 75 82 58         [24]  658 	mov	dpl, #0x58
      00055E C0 07            [24]  659 	push	ar7
      000560 C0 06            [24]  660 	push	ar6
      000562 12 05 18         [24]  661 	lcall	_set_timer1_reload
      000565 D0 06            [24]  662 	pop	ar6
      000567 D0 07            [24]  663 	pop	ar7
                                    664 ;	drivers/ob38s003/src/timer_interrupts.c:161: gTimer1Timeout = timeout;
      000569 90 00 03         [24]  665 	mov	dptr,#_gTimer1Timeout
      00056C EE               [12]  666 	mov	a,r6
      00056D F0               [24]  667 	movx	@dptr,a
      00056E EF               [12]  668 	mov	a,r7
      00056F A3               [24]  669 	inc	dptr
      000570 F0               [24]  670 	movx	@dptr,a
                                    671 ;	drivers/ob38s003/src/timer_interrupts.c:164: TR1 = true;
                                    672 ;	assignBit
      000571 D2 8E            [12]  673 	setb	_TR1
                                    674 ;	drivers/ob38s003/src/timer_interrupts.c:165: }
      000573 22               [24]  675 	ret
                                    676 ;------------------------------------------------------------
                                    677 ;Allocation info for local variables in function 'wait_first_delay_finished'
                                    678 ;------------------------------------------------------------
                                    679 ;	drivers/ob38s003/src/timer_interrupts.c:167: void wait_first_delay_finished(void) {
                                    680 ;	-----------------------------------------
                                    681 ;	 function wait_first_delay_finished
                                    682 ;	-----------------------------------------
      000574                        683 _wait_first_delay_finished:
                                    684 ;	drivers/ob38s003/src/timer_interrupts.c:169: while (TR0)
      000574                        685 00101$:
      000574 20 8C FD         [24]  686 	jb	_TR0,00101$
                                    687 ;	drivers/ob38s003/src/timer_interrupts.c:171: }
      000577 22               [24]  688 	ret
                                    689 ;------------------------------------------------------------
                                    690 ;Allocation info for local variables in function 'wait_second_delay_finished'
                                    691 ;------------------------------------------------------------
                                    692 ;	drivers/ob38s003/src/timer_interrupts.c:173: void wait_second_delay_finished(void) {
                                    693 ;	-----------------------------------------
                                    694 ;	 function wait_second_delay_finished
                                    695 ;	-----------------------------------------
      000578                        696 _wait_second_delay_finished:
                                    697 ;	drivers/ob38s003/src/timer_interrupts.c:175: while (TR1)
      000578                        698 00101$:
      000578 20 8E FD         [24]  699 	jb	_TR1,00101$
                                    700 ;	drivers/ob38s003/src/timer_interrupts.c:177: }
      00057B 22               [24]  701 	ret
                                    702 ;------------------------------------------------------------
                                    703 ;Allocation info for local variables in function 'stop_first_delay'
                                    704 ;------------------------------------------------------------
                                    705 ;	drivers/ob38s003/src/timer_interrupts.c:179: void stop_first_delay(void) {
                                    706 ;	-----------------------------------------
                                    707 ;	 function stop_first_delay
                                    708 ;	-----------------------------------------
      00057C                        709 _stop_first_delay:
                                    710 ;	drivers/ob38s003/src/timer_interrupts.c:181: TR0 = false;
                                    711 ;	assignBit
      00057C C2 8C            [12]  712 	clr	_TR0
                                    713 ;	drivers/ob38s003/src/timer_interrupts.c:184: TF0 = false;
                                    714 ;	assignBit
      00057E C2 8D            [12]  715 	clr	_TF0
                                    716 ;	drivers/ob38s003/src/timer_interrupts.c:185: }
      000580 22               [24]  717 	ret
                                    718 ;------------------------------------------------------------
                                    719 ;Allocation info for local variables in function 'stop_second_delay'
                                    720 ;------------------------------------------------------------
                                    721 ;	drivers/ob38s003/src/timer_interrupts.c:187: void stop_second_delay(void) {
                                    722 ;	-----------------------------------------
                                    723 ;	 function stop_second_delay
                                    724 ;	-----------------------------------------
      000581                        725 _stop_second_delay:
                                    726 ;	drivers/ob38s003/src/timer_interrupts.c:189: TR1 = false;
                                    727 ;	assignBit
      000581 C2 8E            [12]  728 	clr	_TR1
                                    729 ;	drivers/ob38s003/src/timer_interrupts.c:192: TF1 = false;
                                    730 ;	assignBit
      000583 C2 8F            [12]  731 	clr	_TF1
                                    732 ;	drivers/ob38s003/src/timer_interrupts.c:193: }
      000585 22               [24]  733 	ret
                                    734 ;------------------------------------------------------------
                                    735 ;Allocation info for local variables in function 'is_first_delay_finished'
                                    736 ;------------------------------------------------------------
                                    737 ;	drivers/ob38s003/src/timer_interrupts.c:195: bool is_first_delay_finished(void) {
                                    738 ;	-----------------------------------------
                                    739 ;	 function is_first_delay_finished
                                    740 ;	-----------------------------------------
      000586                        741 _is_first_delay_finished:
                                    742 ;	drivers/ob38s003/src/timer_interrupts.c:196: return !TR0;
      000586 A2 8C            [12]  743 	mov	c,_TR0
      000588 B3               [12]  744 	cpl	c
      000589 92 00            [24]  745 	mov  _is_first_delay_finished_sloc0_1_0,c
      00058B E4               [12]  746 	clr	a
      00058C 33               [12]  747 	rlc	a
      00058D F5 82            [12]  748 	mov	dpl,a
                                    749 ;	drivers/ob38s003/src/timer_interrupts.c:197: }
      00058F 22               [24]  750 	ret
                                    751 ;------------------------------------------------------------
                                    752 ;Allocation info for local variables in function 'is_second_delay_finished'
                                    753 ;------------------------------------------------------------
                                    754 ;	drivers/ob38s003/src/timer_interrupts.c:199: bool is_second_delay_finished(void) {
                                    755 ;	-----------------------------------------
                                    756 ;	 function is_second_delay_finished
                                    757 ;	-----------------------------------------
      000590                        758 _is_second_delay_finished:
                                    759 ;	drivers/ob38s003/src/timer_interrupts.c:200: return !TR1;
      000590 A2 8E            [12]  760 	mov	c,_TR1
      000592 B3               [12]  761 	cpl	c
      000593 92 01            [24]  762 	mov  _is_second_delay_finished_sloc0_1_0,c
      000595 E4               [12]  763 	clr	a
      000596 33               [12]  764 	rlc	a
      000597 F5 82            [12]  765 	mov	dpl,a
                                    766 ;	drivers/ob38s003/src/timer_interrupts.c:201: }
      000599 22               [24]  767 	ret
                                    768 ;------------------------------------------------------------
                                    769 ;Allocation info for local variables in function 'timer0_isr'
                                    770 ;------------------------------------------------------------
                                    771 ;	drivers/ob38s003/src/timer_interrupts.c:206: void timer0_isr(void)
                                    772 ;	-----------------------------------------
                                    773 ;	 function timer0_isr
                                    774 ;	-----------------------------------------
      00059A                        775 _timer0_isr:
      00059A C0 21            [24]  776 	push	bits
      00059C C0 E0            [24]  777 	push	acc
      00059E C0 F0            [24]  778 	push	b
      0005A0 C0 82            [24]  779 	push	dpl
      0005A2 C0 83            [24]  780 	push	dph
      0005A4 C0 07            [24]  781 	push	(0+7)
      0005A6 C0 06            [24]  782 	push	(0+6)
      0005A8 C0 05            [24]  783 	push	(0+5)
      0005AA C0 04            [24]  784 	push	(0+4)
      0005AC C0 03            [24]  785 	push	(0+3)
      0005AE C0 02            [24]  786 	push	(0+2)
      0005B0 C0 01            [24]  787 	push	(0+1)
      0005B2 C0 00            [24]  788 	push	(0+0)
      0005B4 C0 D0            [24]  789 	push	psw
      0005B6 75 D0 00         [24]  790 	mov	psw,#0x00
                                    791 ;	drivers/ob38s003/src/timer_interrupts.c:220: if (timeout_receiv < 10) {
      0005B9 74 F6            [12]  792 	mov	a,#0x100 - 0x0a
      0005BB 25 4E            [12]  793 	add	a,_timeout_receiv
      0005BD 40 04            [24]  794 	jc	00104$
                                    795 ;	drivers/ob38s003/src/timer_interrupts.c:221: timeout_receiv++;
      0005BF 05 4E            [12]  796 	inc	_timeout_receiv
      0005C1 80 07            [24]  797 	sjmp	00105$
      0005C3                        798 00104$:
                                    799 ;	drivers/ob38s003/src/timer_interrupts.c:222: } else if (buffer_index2 > 0) {
      0005C3 E5 24            [12]  800 	mov	a,_buffer_index2
      0005C5 60 03            [24]  801 	jz	00105$
                                    802 ;	drivers/ob38s003/src/timer_interrupts.c:223: buffer_index2 = 0;
      0005C7 75 24 00         [24]  803 	mov	_buffer_index2,#0x00
      0005CA                        804 00105$:
                                    805 ;	drivers/ob38s003/src/timer_interrupts.c:226: if (timer0_cnt1 < mot1_speed_tmr) {
      0005CA C3               [12]  806 	clr	c
      0005CB E5 1B            [12]  807 	mov	a,_timer0_cnt1
      0005CD 95 15            [12]  808 	subb	a,_mot1_speed_tmr
      0005CF 50 04            [24]  809 	jnc	00114$
                                    810 ;	drivers/ob38s003/src/timer_interrupts.c:227: timer0_cnt1++;
      0005D1 05 1B            [12]  811 	inc	_timer0_cnt1
      0005D3 80 19            [24]  812 	sjmp	00115$
      0005D5                        813 00114$:
                                    814 ;	drivers/ob38s003/src/timer_interrupts.c:229: timer0_cnt1 = 0;
      0005D5 75 1B 00         [24]  815 	mov	_timer0_cnt1,#0x00
                                    816 ;	drivers/ob38s003/src/timer_interrupts.c:231: if (mot1_direction == MOTOR_CC) {
      0005D8 E5 0F            [12]  817 	mov	a,_mot1_direction
      0005DA 70 0A            [24]  818 	jnz	00111$
                                    819 ;	drivers/ob38s003/src/timer_interrupts.c:232: if (mot1_enabled == true) {
      0005DC 74 01            [12]  820 	mov	a,#0x01
      0005DE B5 0D 0D         [24]  821 	cjne	a,_mot1_enabled,00115$
                                    822 ;	drivers/ob38s003/src/timer_interrupts.c:233: motor1_step_cc();
      0005E1 12 03 98         [24]  823 	lcall	_motor1_step_cc
      0005E4 80 08            [24]  824 	sjmp	00115$
      0005E6                        825 00111$:
                                    826 ;	drivers/ob38s003/src/timer_interrupts.c:236: if (mot1_enabled == true) {
      0005E6 74 01            [12]  827 	mov	a,#0x01
      0005E8 B5 0D 03         [24]  828 	cjne	a,_mot1_enabled,00115$
                                    829 ;	drivers/ob38s003/src/timer_interrupts.c:237: motor1_step_ccw();
      0005EB 12 03 BC         [24]  830 	lcall	_motor1_step_ccw
      0005EE                        831 00115$:
                                    832 ;	drivers/ob38s003/src/timer_interrupts.c:242: if (timer0_cnt2 < mot2_speed_tmr) {
      0005EE C3               [12]  833 	clr	c
      0005EF E5 1C            [12]  834 	mov	a,_timer0_cnt2
      0005F1 95 16            [12]  835 	subb	a,_mot2_speed_tmr
      0005F3 50 04            [24]  836 	jnc	00124$
                                    837 ;	drivers/ob38s003/src/timer_interrupts.c:243: timer0_cnt2++;
      0005F5 05 1C            [12]  838 	inc	_timer0_cnt2
      0005F7 80 19            [24]  839 	sjmp	00126$
      0005F9                        840 00124$:
                                    841 ;	drivers/ob38s003/src/timer_interrupts.c:245: timer0_cnt2 = 0;
      0005F9 75 1C 00         [24]  842 	mov	_timer0_cnt2,#0x00
                                    843 ;	drivers/ob38s003/src/timer_interrupts.c:247: if (mot2_direction == MOTOR_CC) {
      0005FC E5 10            [12]  844 	mov	a,_mot2_direction
      0005FE 70 0A            [24]  845 	jnz	00121$
                                    846 ;	drivers/ob38s003/src/timer_interrupts.c:248: if (mot2_enabled == true) {
      000600 74 01            [12]  847 	mov	a,#0x01
      000602 B5 0E 0D         [24]  848 	cjne	a,_mot2_enabled,00126$
                                    849 ;	drivers/ob38s003/src/timer_interrupts.c:249: motor2_step_cc();
      000605 12 03 EF         [24]  850 	lcall	_motor2_step_cc
      000608 80 08            [24]  851 	sjmp	00126$
      00060A                        852 00121$:
                                    853 ;	drivers/ob38s003/src/timer_interrupts.c:252: if (mot2_enabled == true) {
      00060A 74 01            [12]  854 	mov	a,#0x01
      00060C B5 0E 03         [24]  855 	cjne	a,_mot2_enabled,00126$
                                    856 ;	drivers/ob38s003/src/timer_interrupts.c:253: motor2_step_ccw();
      00060F 12 03 FF         [24]  857 	lcall	_motor2_step_ccw
      000612                        858 00126$:
                                    859 ;	drivers/ob38s003/src/timer_interrupts.c:274: }
      000612 D0 D0            [24]  860 	pop	psw
      000614 D0 00            [24]  861 	pop	(0+0)
      000616 D0 01            [24]  862 	pop	(0+1)
      000618 D0 02            [24]  863 	pop	(0+2)
      00061A D0 03            [24]  864 	pop	(0+3)
      00061C D0 04            [24]  865 	pop	(0+4)
      00061E D0 05            [24]  866 	pop	(0+5)
      000620 D0 06            [24]  867 	pop	(0+6)
      000622 D0 07            [24]  868 	pop	(0+7)
      000624 D0 83            [24]  869 	pop	dph
      000626 D0 82            [24]  870 	pop	dpl
      000628 D0 F0            [24]  871 	pop	b
      00062A D0 E0            [24]  872 	pop	acc
      00062C D0 21            [24]  873 	pop	bits
      00062E 02 00 6C         [24]  874 	ljmp	sdcc_atomic_maybe_rollback
                                    875 ;------------------------------------------------------------
                                    876 ;Allocation info for local variables in function 'timer1_isr'
                                    877 ;------------------------------------------------------------
                                    878 ;	drivers/ob38s003/src/timer_interrupts.c:277: void timer1_isr(void)
                                    879 ;	-----------------------------------------
                                    880 ;	 function timer1_isr
                                    881 ;	-----------------------------------------
      000631                        882 _timer1_isr:
                                    883 ;	drivers/ob38s003/src/timer_interrupts.c:288: }
      000631 32               [24]  884 	reti
                                    885 ;	eliminated unneeded mov psw,# (no regs used in bank)
                                    886 ;	eliminated unneeded push/pop not_psw
                                    887 ;	eliminated unneeded push/pop dpl
                                    888 ;	eliminated unneeded push/pop dph
                                    889 ;	eliminated unneeded push/pop b
                                    890 ;	eliminated unneeded push/pop acc
                                    891 ;------------------------------------------------------------
                                    892 ;Allocation info for local variables in function 'timer2_isr'
                                    893 ;------------------------------------------------------------
                                    894 ;currentCapture Allocated to registers 
                                    895 ;------------------------------------------------------------
                                    896 ;	drivers/ob38s003/src/timer_interrupts.c:293: void timer2_isr(void)
                                    897 ;	-----------------------------------------
                                    898 ;	 function timer2_isr
                                    899 ;	-----------------------------------------
      000632                        900 _timer2_isr:
      000632 C0 21            [24]  901 	push	bits
      000634 C0 E0            [24]  902 	push	acc
      000636 C0 F0            [24]  903 	push	b
      000638 C0 82            [24]  904 	push	dpl
      00063A C0 83            [24]  905 	push	dph
      00063C C0 07            [24]  906 	push	(0+7)
      00063E C0 06            [24]  907 	push	(0+6)
      000640 C0 05            [24]  908 	push	(0+5)
      000642 C0 04            [24]  909 	push	(0+4)
      000644 C0 03            [24]  910 	push	(0+3)
      000646 C0 02            [24]  911 	push	(0+2)
      000648 C0 01            [24]  912 	push	(0+1)
      00064A C0 00            [24]  913 	push	(0+0)
      00064C C0 D0            [24]  914 	push	psw
      00064E 75 D0 00         [24]  915 	mov	psw,#0x00
                                    916 ;	drivers/ob38s003/src/timer_interrupts.c:296: uint16_t currentCapture = get_capture_mode();
      000651 12 04 DD         [24]  917 	lcall	_get_capture_mode
                                    918 ;	drivers/ob38s003/src/timer_interrupts.c:304: clear_capture_flag();
      000654 12 04 F0         [24]  919 	lcall	_clear_capture_flag
                                    920 ;	drivers/ob38s003/src/timer_interrupts.c:306: }
      000657 D0 D0            [24]  921 	pop	psw
      000659 D0 00            [24]  922 	pop	(0+0)
      00065B D0 01            [24]  923 	pop	(0+1)
      00065D D0 02            [24]  924 	pop	(0+2)
      00065F D0 03            [24]  925 	pop	(0+3)
      000661 D0 04            [24]  926 	pop	(0+4)
      000663 D0 05            [24]  927 	pop	(0+5)
      000665 D0 06            [24]  928 	pop	(0+6)
      000667 D0 07            [24]  929 	pop	(0+7)
      000669 D0 83            [24]  930 	pop	dph
      00066B D0 82            [24]  931 	pop	dpl
      00066D D0 F0            [24]  932 	pop	b
      00066F D0 E0            [24]  933 	pop	acc
      000671 D0 21            [24]  934 	pop	bits
      000673 02 00 6C         [24]  935 	ljmp	sdcc_atomic_maybe_rollback
                                    936 	.area CSEG    (CODE)
                                    937 	.area CONST   (CODE)
                                    938 	.area XINIT   (CODE)
                                    939 	.area CABS    (ABS,CODE)
