                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.5.0 #15242 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module main_rcswitch
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-small
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _main
                                     12 	.globl _startup_blink
                                     13 	.globl ___sdcc_external_startup
                                     14 	.globl _init_port_pins
                                     15 	.globl _set_clock_mode
                                     16 	.globl _delay1ms
                                     17 	.globl _EXEN2
                                     18 	.globl _IEIIC
                                     19 	.globl _IELVI
                                     20 	.globl _IEKBI
                                     21 	.globl _IEADC
                                     22 	.globl _IESPI
                                     23 	.globl _IEPWM
                                     24 	.globl _EXF2
                                     25 	.globl _TF2
                                     26 	.globl _IICIF
                                     27 	.globl _LVIIF
                                     28 	.globl _KBIIF
                                     29 	.globl _ADCIF
                                     30 	.globl _SPIIF
                                     31 	.globl _PWMIF
                                     32 	.globl _MPIF
                                     33 	.globl _LAIF
                                     34 	.globl _RXIF
                                     35 	.globl _TXIF
                                     36 	.globl _RXAK
                                     37 	.globl _TXAK
                                     38 	.globl _BB
                                     39 	.globl _RW
                                     40 	.globl _SM0
                                     41 	.globl _SM1
                                     42 	.globl _SM2
                                     43 	.globl _REN
                                     44 	.globl _TB8
                                     45 	.globl _RB8
                                     46 	.globl _TI
                                     47 	.globl _RI
                                     48 	.globl _EA
                                     49 	.globl _ET2
                                     50 	.globl _ES
                                     51 	.globl _ET1
                                     52 	.globl _EX1
                                     53 	.globl _ET0
                                     54 	.globl _EX0
                                     55 	.globl _TF1
                                     56 	.globl _TR1
                                     57 	.globl _TF0
                                     58 	.globl _TR0
                                     59 	.globl _IE1
                                     60 	.globl _IT1
                                     61 	.globl _IE0
                                     62 	.globl _IT0
                                     63 	.globl _CY
                                     64 	.globl _AC
                                     65 	.globl _F0
                                     66 	.globl _RS1
                                     67 	.globl _RS0
                                     68 	.globl _OV
                                     69 	.globl _F1
                                     70 	.globl _P
                                     71 	.globl _P3_1
                                     72 	.globl _P3_0
                                     73 	.globl _P1_7
                                     74 	.globl _P1_6
                                     75 	.globl _P1_5
                                     76 	.globl _P1_4
                                     77 	.globl _P1_3
                                     78 	.globl _P1_2
                                     79 	.globl _P1_1
                                     80 	.globl _P1_0
                                     81 	.globl _P0_7
                                     82 	.globl _P0_6
                                     83 	.globl _P0_5
                                     84 	.globl _P0_4
                                     85 	.globl _P0_3
                                     86 	.globl _P0_2
                                     87 	.globl _P0_1
                                     88 	.globl _P0_0
                                     89 	.globl _T2
                                     90 	.globl _CRC
                                     91 	.globl _CC3
                                     92 	.globl _CC2
                                     93 	.globl _CC1
                                     94 	.globl _CMP1CON
                                     95 	.globl _CMP0CON
                                     96 	.globl _OPPIN
                                     97 	.globl _IICEBT
                                     98 	.globl _IICRWD
                                     99 	.globl _IICA2
                                    100 	.globl _IICA1
                                    101 	.globl _IICCTL
                                    102 	.globl _IICS
                                    103 	.globl _SPIS
                                    104 	.globl _SPIRXD
                                    105 	.globl _SPITXD
                                    106 	.globl _SPIC2
                                    107 	.globl _SPIC1
                                    108 	.globl _P3M1
                                    109 	.globl _P3M0
                                    110 	.globl _P1M1
                                    111 	.globl _P1M0
                                    112 	.globl _P0M1
                                    113 	.globl _P0M0
                                    114 	.globl _TH2
                                    115 	.globl _TL2
                                    116 	.globl _CRCH
                                    117 	.globl _CRCL
                                    118 	.globl _CCCON
                                    119 	.globl _T2CON
                                    120 	.globl _CCH3
                                    121 	.globl _CCL3
                                    122 	.globl _CCH2
                                    123 	.globl _CCL2
                                    124 	.globl _CCH1
                                    125 	.globl _CCL1
                                    126 	.globl _CCEN2
                                    127 	.globl _CCEN
                                    128 	.globl _WDTK
                                    129 	.globl _WDTC
                                    130 	.globl _PWMMDL
                                    131 	.globl _PWMMDH
                                    132 	.globl _PWMD3L
                                    133 	.globl _PWMD3H
                                    134 	.globl _PWMD2L
                                    135 	.globl _PWMD2H
                                    136 	.globl _PWMD1L
                                    137 	.globl _PWMD1H
                                    138 	.globl _PWMD0L
                                    139 	.globl _PWMD0H
                                    140 	.globl _PWMC
                                    141 	.globl _ADCSH
                                    142 	.globl _ADCCS
                                    143 	.globl _ADCDL
                                    144 	.globl _ADCDH
                                    145 	.globl _ADCC2
                                    146 	.globl _ADCC1
                                    147 	.globl _SWRES
                                    148 	.globl _LVC
                                    149 	.globl _RSTS
                                    150 	.globl _IRCON2
                                    151 	.globl _KBD
                                    152 	.globl _KBF
                                    153 	.globl _KBE
                                    154 	.globl _KBLS
                                    155 	.globl _ENHIT
                                    156 	.globl _INTDEG
                                    157 	.globl _IRCON
                                    158 	.globl _IP1
                                    159 	.globl _IP0
                                    160 	.globl _IEN1
                                    161 	.globl _IEN0
                                    162 	.globl _IEN2
                                    163 	.globl _PFCON
                                    164 	.globl _SRELH
                                    165 	.globl _SRELL
                                    166 	.globl _S0RELH
                                    167 	.globl _S0RELL
                                    168 	.globl _S0BUF
                                    169 	.globl _S0CON
                                    170 	.globl _ISPFC
                                    171 	.globl _ISPFDH
                                    172 	.globl _ISPFDL
                                    173 	.globl _ISPFAL
                                    174 	.globl _ISPFAH
                                    175 	.globl _TAKEY
                                    176 	.globl _IFCON
                                    177 	.globl _AUX
                                    178 	.globl _DPH1
                                    179 	.globl _DPL1
                                    180 	.globl _IP
                                    181 	.globl _IE
                                    182 	.globl _SBUF
                                    183 	.globl _SCON
                                    184 	.globl _CKCON
                                    185 	.globl _TH1
                                    186 	.globl _TH0
                                    187 	.globl _TL1
                                    188 	.globl _TL0
                                    189 	.globl _TMOD
                                    190 	.globl _TCON
                                    191 	.globl _PCON
                                    192 	.globl _DPH
                                    193 	.globl _DPL
                                    194 	.globl _SP
                                    195 	.globl _B
                                    196 	.globl _ACC
                                    197 	.globl _PSW
                                    198 	.globl _P3
                                    199 	.globl _P1
                                    200 	.globl _P0
                                    201 	.globl _preset_id
                                    202 	.globl _P_chksum
                                    203 	.globl _P_dat2
                                    204 	.globl _P_dat1
                                    205 	.globl _P_cmd2
                                    206 	.globl _P_cmd1
                                    207 	.globl _P_addr
                                    208 	.globl _response_type
                                    209 	.globl _header_pos
                                    210 	.globl _frame_data
                                    211 	.globl _frame_index
                                    212 	.globl _alarms_data
                                    213 	.globl _is_preset
                                    214 	.globl _timer1_tilt_ref
                                    215 	.globl _timer1_pan_ref
                                    216 	.globl _timer1_tilt
                                    217 	.globl _timer1_pan
                                    218 	.globl _tilt_step_phase
                                    219 	.globl _pan_step_phase
                                    220 	.globl _tilt_counter
                                    221 	.globl _tilt_speed_old
                                    222 	.globl _tilt_speed
                                    223 	.globl _tilt_direction
                                    224 	.globl _tilt_enabled
                                    225 	.globl _pan_counter
                                    226 	.globl _pan_speed_old
                                    227 	.globl _pan_speed
                                    228 	.globl _pan_direction
                                    229 	.globl _pan_enabled
                                    230 	.globl _preset_enabled
                                    231 	.globl _timeout_receiv
                                    232 	.globl _header_cnt
                                    233 	.globl _buffer_ready
                                    234 	.globl _buffer_data4
                                    235 	.globl _buffer_data3
                                    236 	.globl _buffer_data2
                                    237 	.globl _buffer_data1
                                    238 	.globl _buffer_data0
                                    239 	.globl _buffer_index2
                                    240 	.globl _buffer_index1
                                    241 	.globl _data_receiv
                                    242 ;--------------------------------------------------------
                                    243 ; special function registers
                                    244 ;--------------------------------------------------------
                                    245 	.area RSEG    (ABS,DATA)
      000000                        246 	.org 0x0000
                           000080   247 _P0	=	0x0080
                           000090   248 _P1	=	0x0090
                           0000B0   249 _P3	=	0x00b0
                           0000D0   250 _PSW	=	0x00d0
                           0000E0   251 _ACC	=	0x00e0
                           0000F0   252 _B	=	0x00f0
                           000081   253 _SP	=	0x0081
                           000082   254 _DPL	=	0x0082
                           000083   255 _DPH	=	0x0083
                           000087   256 _PCON	=	0x0087
                           000088   257 _TCON	=	0x0088
                           000089   258 _TMOD	=	0x0089
                           00008A   259 _TL0	=	0x008a
                           00008B   260 _TL1	=	0x008b
                           00008C   261 _TH0	=	0x008c
                           00008D   262 _TH1	=	0x008d
                           00008E   263 _CKCON	=	0x008e
                           000098   264 _SCON	=	0x0098
                           000099   265 _SBUF	=	0x0099
                           0000A8   266 _IE	=	0x00a8
                           0000A9   267 _IP	=	0x00a9
                           000084   268 _DPL1	=	0x0084
                           000085   269 _DPH1	=	0x0085
                           000091   270 _AUX	=	0x0091
                           00008F   271 _IFCON	=	0x008f
                           0000F7   272 _TAKEY	=	0x00f7
                           0000E1   273 _ISPFAH	=	0x00e1
                           0000E2   274 _ISPFAL	=	0x00e2
                           0000E3   275 _ISPFDL	=	0x00e3
                           0000EB   276 _ISPFDH	=	0x00eb
                           0000E4   277 _ISPFC	=	0x00e4
                           000098   278 _S0CON	=	0x0098
                           000099   279 _S0BUF	=	0x0099
                           0000AA   280 _S0RELL	=	0x00aa
                           0000BA   281 _S0RELH	=	0x00ba
                           0000AA   282 _SRELL	=	0x00aa
                           0000BA   283 _SRELH	=	0x00ba
                           0000D9   284 _PFCON	=	0x00d9
                           00009A   285 _IEN2	=	0x009a
                           0000A8   286 _IEN0	=	0x00a8
                           0000B8   287 _IEN1	=	0x00b8
                           0000A9   288 _IP0	=	0x00a9
                           0000B9   289 _IP1	=	0x00b9
                           0000C0   290 _IRCON	=	0x00c0
                           0000EE   291 _INTDEG	=	0x00ee
                           0000E5   292 _ENHIT	=	0x00e5
                           000093   293 _KBLS	=	0x0093
                           000094   294 _KBE	=	0x0094
                           000095   295 _KBF	=	0x0095
                           000096   296 _KBD	=	0x0096
                           000097   297 _IRCON2	=	0x0097
                           0000A1   298 _RSTS	=	0x00a1
                           0000E6   299 _LVC	=	0x00e6
                           0000E7   300 _SWRES	=	0x00e7
                           0000AB   301 _ADCC1	=	0x00ab
                           0000AC   302 _ADCC2	=	0x00ac
                           0000AD   303 _ADCDH	=	0x00ad
                           0000AE   304 _ADCDL	=	0x00ae
                           0000AF   305 _ADCCS	=	0x00af
                           0000EF   306 _ADCSH	=	0x00ef
                           0000B5   307 _PWMC	=	0x00b5
                           0000BC   308 _PWMD0H	=	0x00bc
                           0000BD   309 _PWMD0L	=	0x00bd
                           0000BE   310 _PWMD1H	=	0x00be
                           0000BF   311 _PWMD1L	=	0x00bf
                           0000B1   312 _PWMD2H	=	0x00b1
                           0000B2   313 _PWMD2L	=	0x00b2
                           0000B3   314 _PWMD3H	=	0x00b3
                           0000B4   315 _PWMD3L	=	0x00b4
                           0000CE   316 _PWMMDH	=	0x00ce
                           0000CF   317 _PWMMDL	=	0x00cf
                           0000B6   318 _WDTC	=	0x00b6
                           0000B7   319 _WDTK	=	0x00b7
                           0000C1   320 _CCEN	=	0x00c1
                           0000D1   321 _CCEN2	=	0x00d1
                           0000C2   322 _CCL1	=	0x00c2
                           0000C3   323 _CCH1	=	0x00c3
                           0000C4   324 _CCL2	=	0x00c4
                           0000C5   325 _CCH2	=	0x00c5
                           0000C6   326 _CCL3	=	0x00c6
                           0000C7   327 _CCH3	=	0x00c7
                           0000C8   328 _T2CON	=	0x00c8
                           0000C9   329 _CCCON	=	0x00c9
                           0000CA   330 _CRCL	=	0x00ca
                           0000CB   331 _CRCH	=	0x00cb
                           0000CC   332 _TL2	=	0x00cc
                           0000CD   333 _TH2	=	0x00cd
                           0000D2   334 _P0M0	=	0x00d2
                           0000D3   335 _P0M1	=	0x00d3
                           0000D4   336 _P1M0	=	0x00d4
                           0000D5   337 _P1M1	=	0x00d5
                           0000DA   338 _P3M0	=	0x00da
                           0000DB   339 _P3M1	=	0x00db
                           0000F1   340 _SPIC1	=	0x00f1
                           0000F2   341 _SPIC2	=	0x00f2
                           0000F3   342 _SPITXD	=	0x00f3
                           0000F4   343 _SPIRXD	=	0x00f4
                           0000F5   344 _SPIS	=	0x00f5
                           0000F8   345 _IICS	=	0x00f8
                           0000F9   346 _IICCTL	=	0x00f9
                           0000FA   347 _IICA1	=	0x00fa
                           0000FB   348 _IICA2	=	0x00fb
                           0000FC   349 _IICRWD	=	0x00fc
                           0000FD   350 _IICEBT	=	0x00fd
                           0000F6   351 _OPPIN	=	0x00f6
                           0000FE   352 _CMP0CON	=	0x00fe
                           0000FF   353 _CMP1CON	=	0x00ff
                           00C3C2   354 _CC1	=	0xc3c2
                           00C5C4   355 _CC2	=	0xc5c4
                           00C7C6   356 _CC3	=	0xc7c6
                           00CBCA   357 _CRC	=	0xcbca
                           00CDCC   358 _T2	=	0xcdcc
                                    359 ;--------------------------------------------------------
                                    360 ; special function bits
                                    361 ;--------------------------------------------------------
                                    362 	.area RSEG    (ABS,DATA)
      000000                        363 	.org 0x0000
                           000080   364 _P0_0	=	0x0080
                           000081   365 _P0_1	=	0x0081
                           000082   366 _P0_2	=	0x0082
                           000083   367 _P0_3	=	0x0083
                           000084   368 _P0_4	=	0x0084
                           000085   369 _P0_5	=	0x0085
                           000086   370 _P0_6	=	0x0086
                           000087   371 _P0_7	=	0x0087
                           000090   372 _P1_0	=	0x0090
                           000091   373 _P1_1	=	0x0091
                           000092   374 _P1_2	=	0x0092
                           000093   375 _P1_3	=	0x0093
                           000094   376 _P1_4	=	0x0094
                           000095   377 _P1_5	=	0x0095
                           000096   378 _P1_6	=	0x0096
                           000097   379 _P1_7	=	0x0097
                           0000B0   380 _P3_0	=	0x00b0
                           0000B2   381 _P3_1	=	0x00b2
                           0000D0   382 _P	=	0x00d0
                           0000D1   383 _F1	=	0x00d1
                           0000D2   384 _OV	=	0x00d2
                           0000D3   385 _RS0	=	0x00d3
                           0000D4   386 _RS1	=	0x00d4
                           0000D5   387 _F0	=	0x00d5
                           0000D6   388 _AC	=	0x00d6
                           0000D7   389 _CY	=	0x00d7
                           000088   390 _IT0	=	0x0088
                           000089   391 _IE0	=	0x0089
                           00008A   392 _IT1	=	0x008a
                           00008B   393 _IE1	=	0x008b
                           00008C   394 _TR0	=	0x008c
                           00008D   395 _TF0	=	0x008d
                           00008E   396 _TR1	=	0x008e
                           00008F   397 _TF1	=	0x008f
                           0000A8   398 _EX0	=	0x00a8
                           0000A9   399 _ET0	=	0x00a9
                           0000AA   400 _EX1	=	0x00aa
                           0000AB   401 _ET1	=	0x00ab
                           0000AC   402 _ES	=	0x00ac
                           0000AD   403 _ET2	=	0x00ad
                           0000AF   404 _EA	=	0x00af
                           000098   405 _RI	=	0x0098
                           000099   406 _TI	=	0x0099
                           00009A   407 _RB8	=	0x009a
                           00009B   408 _TB8	=	0x009b
                           00009C   409 _REN	=	0x009c
                           00009D   410 _SM2	=	0x009d
                           00009E   411 _SM1	=	0x009e
                           00009F   412 _SM0	=	0x009f
                           0000F8   413 _RW	=	0x00f8
                           0000F8   414 _BB	=	0x00f8
                           0000F9   415 _TXAK	=	0x00f9
                           0000FA   416 _RXAK	=	0x00fa
                           0000FB   417 _TXIF	=	0x00fb
                           0000FC   418 _RXIF	=	0x00fc
                           0000FD   419 _LAIF	=	0x00fd
                           0000FE   420 _MPIF	=	0x00fe
                           0000C0   421 _PWMIF	=	0x00c0
                           0000C1   422 _SPIIF	=	0x00c1
                           0000C2   423 _ADCIF	=	0x00c2
                           0000C3   424 _KBIIF	=	0x00c3
                           0000C4   425 _LVIIF	=	0x00c4
                           0000C5   426 _IICIF	=	0x00c5
                           0000C6   427 _TF2	=	0x00c6
                           0000C7   428 _EXF2	=	0x00c7
                           0000B8   429 _IEPWM	=	0x00b8
                           0000B9   430 _IESPI	=	0x00b9
                           0000BA   431 _IEADC	=	0x00ba
                           0000BB   432 _IEKBI	=	0x00bb
                           0000BC   433 _IELVI	=	0x00bc
                           0000BD   434 _IEIIC	=	0x00bd
                           0000BF   435 _EXEN2	=	0x00bf
                                    436 ;--------------------------------------------------------
                                    437 ; overlayable register banks
                                    438 ;--------------------------------------------------------
                                    439 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        440 	.ds 8
                                    441 ;--------------------------------------------------------
                                    442 ; internal ram data
                                    443 ;--------------------------------------------------------
                                    444 	.area DSEG    (DATA)
      000022                        445 _data_receiv::
      000022                        446 	.ds 1
      000023                        447 _buffer_index1::
      000023                        448 	.ds 1
      000024                        449 _buffer_index2::
      000024                        450 	.ds 1
      000025                        451 _buffer_data0::
      000025                        452 	.ds 7
      00002C                        453 _buffer_data1::
      00002C                        454 	.ds 7
      000033                        455 _buffer_data2::
      000033                        456 	.ds 7
      00003A                        457 _buffer_data3::
      00003A                        458 	.ds 7
      000041                        459 _buffer_data4::
      000041                        460 	.ds 7
      000048                        461 _buffer_ready::
      000048                        462 	.ds 5
      00004D                        463 _header_cnt::
      00004D                        464 	.ds 1
      00004E                        465 _timeout_receiv::
      00004E                        466 	.ds 1
      00004F                        467 _preset_enabled::
      00004F                        468 	.ds 1
      000050                        469 _pan_enabled::
      000050                        470 	.ds 1
      000051                        471 _pan_direction::
      000051                        472 	.ds 1
      000052                        473 _pan_speed::
      000052                        474 	.ds 1
      000053                        475 _pan_speed_old::
      000053                        476 	.ds 1
      000054                        477 _pan_counter::
      000054                        478 	.ds 2
      000056                        479 _tilt_enabled::
      000056                        480 	.ds 1
      000057                        481 _tilt_direction::
      000057                        482 	.ds 1
      000058                        483 _tilt_speed::
      000058                        484 	.ds 1
      000059                        485 _tilt_speed_old::
      000059                        486 	.ds 1
      00005A                        487 _tilt_counter::
      00005A                        488 	.ds 2
      00005C                        489 _pan_step_phase::
      00005C                        490 	.ds 1
      00005D                        491 _tilt_step_phase::
      00005D                        492 	.ds 1
      00005E                        493 _timer1_pan::
      00005E                        494 	.ds 1
      00005F                        495 _timer1_tilt::
      00005F                        496 	.ds 1
      000060                        497 _timer1_pan_ref::
      000060                        498 	.ds 1
      000061                        499 _timer1_tilt_ref::
      000061                        500 	.ds 1
      000062                        501 _is_preset::
      000062                        502 	.ds 1
      000063                        503 _alarms_data::
      000063                        504 	.ds 1
      000064                        505 _frame_index::
      000064                        506 	.ds 1
      000065                        507 _frame_data::
      000065                        508 	.ds 7
      00006C                        509 _header_pos::
      00006C                        510 	.ds 1
      00006D                        511 _response_type::
      00006D                        512 	.ds 1
      00006E                        513 _P_addr::
      00006E                        514 	.ds 1
      00006F                        515 _P_cmd1::
      00006F                        516 	.ds 1
      000070                        517 _P_cmd2::
      000070                        518 	.ds 1
      000071                        519 _P_dat1::
      000071                        520 	.ds 1
      000072                        521 _P_dat2::
      000072                        522 	.ds 1
      000073                        523 _P_chksum::
      000073                        524 	.ds 1
      000074                        525 _preset_id::
      000074                        526 	.ds 1
                                    527 ;--------------------------------------------------------
                                    528 ; overlayable items in internal ram
                                    529 ;--------------------------------------------------------
                                    530 ;--------------------------------------------------------
                                    531 ; Stack segment in internal ram
                                    532 ;--------------------------------------------------------
                                    533 	.area SSEG
      000075                        534 __start__stack:
      000075                        535 	.ds	1
                                    536 
                                    537 ;--------------------------------------------------------
                                    538 ; indirectly addressable internal ram data
                                    539 ;--------------------------------------------------------
                                    540 	.area ISEG    (DATA)
                                    541 ;--------------------------------------------------------
                                    542 ; absolute internal ram data
                                    543 ;--------------------------------------------------------
                                    544 	.area IABS    (ABS,DATA)
                                    545 	.area IABS    (ABS,DATA)
                                    546 ;--------------------------------------------------------
                                    547 ; bit data
                                    548 ;--------------------------------------------------------
                                    549 	.area BSEG    (BIT)
                                    550 ;--------------------------------------------------------
                                    551 ; paged external ram data
                                    552 ;--------------------------------------------------------
                                    553 	.area PSEG    (PAG,XDATA)
                                    554 ;--------------------------------------------------------
                                    555 ; uninitialized external ram data
                                    556 ;--------------------------------------------------------
                                    557 	.area XSEG    (XDATA)
                                    558 ;--------------------------------------------------------
                                    559 ; absolute external ram data
                                    560 ;--------------------------------------------------------
                                    561 	.area XABS    (ABS,XDATA)
                                    562 ;--------------------------------------------------------
                                    563 ; initialized external ram data
                                    564 ;--------------------------------------------------------
                                    565 	.area XISEG   (XDATA)
                                    566 	.area HOME    (CODE)
                                    567 	.area GSINIT0 (CODE)
                                    568 	.area GSINIT1 (CODE)
                                    569 	.area GSINIT2 (CODE)
                                    570 	.area GSINIT3 (CODE)
                                    571 	.area GSINIT4 (CODE)
                                    572 	.area GSINIT5 (CODE)
                                    573 	.area GSINIT  (CODE)
                                    574 	.area GSFINAL (CODE)
                                    575 	.area CSEG    (CODE)
                                    576 ;--------------------------------------------------------
                                    577 ; interrupt vector
                                    578 ;--------------------------------------------------------
                                    579 	.area HOME    (CODE)
      000000                        580 __interrupt_vect:
      000000 02 00 96         [24]  581 	ljmp	__sdcc_gsinit_startup
      000003 32               [24]  582 	reti
      000004                        583 	.ds	7
      00000B 02 05 9A         [24]  584 	ljmp	_timer0_isr
      00000E                        585 	.ds	5
      000013 32               [24]  586 	reti
      000014                        587 	.ds	7
      00001B 32               [24]  588 	reti
      00001C                        589 	.ds	7
      000023 02 02 17         [24]  590 	ljmp	_uart_isr
                                    591 ; restartable atomic support routines
      000026                        592 	.ds	2
      000028                        593 sdcc_atomic_exchange_rollback_start::
      000028 00               [12]  594 	nop
      000029 00               [12]  595 	nop
      00002A                        596 sdcc_atomic_exchange_pdata_impl:
      00002A E2               [24]  597 	movx	a, @r0
      00002B FB               [12]  598 	mov	r3, a
      00002C EA               [12]  599 	mov	a, r2
      00002D F2               [24]  600 	movx	@r0, a
      00002E 80 2C            [24]  601 	sjmp	sdcc_atomic_exchange_exit
      000030 00               [12]  602 	nop
      000031 00               [12]  603 	nop
      000032                        604 sdcc_atomic_exchange_xdata_impl:
      000032 E0               [24]  605 	movx	a, @dptr
      000033 FB               [12]  606 	mov	r3, a
      000034 EA               [12]  607 	mov	a, r2
      000035 F0               [24]  608 	movx	@dptr, a
      000036 80 24            [24]  609 	sjmp	sdcc_atomic_exchange_exit
      000038                        610 sdcc_atomic_compare_exchange_idata_impl:
      000038 E6               [12]  611 	mov	a, @r0
      000039 B5 02 02         [24]  612 	cjne	a, ar2, .+#5
      00003C EB               [12]  613 	mov	a, r3
      00003D F6               [12]  614 	mov	@r0, a
      00003E 22               [24]  615 	ret
      00003F 00               [12]  616 	nop
      000040                        617 sdcc_atomic_compare_exchange_pdata_impl:
      000040 E2               [24]  618 	movx	a, @r0
      000041 B5 02 02         [24]  619 	cjne	a, ar2, .+#5
      000044 EB               [12]  620 	mov	a, r3
      000045 F2               [24]  621 	movx	@r0, a
      000046 22               [24]  622 	ret
      000047 00               [12]  623 	nop
      000048                        624 sdcc_atomic_compare_exchange_xdata_impl:
      000048 E0               [24]  625 	movx	a, @dptr
      000049 B5 02 02         [24]  626 	cjne	a, ar2, .+#5
      00004C EB               [12]  627 	mov	a, r3
      00004D F0               [24]  628 	movx	@dptr, a
      00004E 22               [24]  629 	ret
      00004F                        630 sdcc_atomic_exchange_rollback_end::
                                    631 
      00004F                        632 sdcc_atomic_exchange_gptr_impl::
      00004F 30 F6 E0         [24]  633 	jnb	b.6, sdcc_atomic_exchange_xdata_impl
      000052 A8 82            [24]  634 	mov	r0, dpl
      000054 20 F5 D3         [24]  635 	jb	b.5, sdcc_atomic_exchange_pdata_impl
      000057                        636 sdcc_atomic_exchange_idata_impl:
      000057 EA               [12]  637 	mov	a, r2
      000058 C6               [12]  638 	xch	a, @r0
      000059 F5 82            [12]  639 	mov	dpl, a
      00005B 22               [24]  640 	ret
      00005C                        641 sdcc_atomic_exchange_exit:
      00005C 8B 82            [24]  642 	mov	dpl, r3
      00005E 22               [24]  643 	ret
      00005F                        644 sdcc_atomic_compare_exchange_gptr_impl::
      00005F 30 F6 E6         [24]  645 	jnb	b.6, sdcc_atomic_compare_exchange_xdata_impl
      000062 A8 82            [24]  646 	mov	r0, dpl
      000064 20 F5 D9         [24]  647 	jb	b.5, sdcc_atomic_compare_exchange_pdata_impl
      000067 80 CF            [24]  648 	sjmp	sdcc_atomic_compare_exchange_idata_impl
                                    649 ;--------------------------------------------------------
                                    650 ; global & static initialisations
                                    651 ;--------------------------------------------------------
                                    652 	.area HOME    (CODE)
                                    653 	.area GSINIT  (CODE)
                                    654 	.area GSFINAL (CODE)
                                    655 	.area GSINIT  (CODE)
                                    656 	.globl __sdcc_gsinit_startup
                                    657 	.globl __sdcc_program_startup
                                    658 	.globl __start__stack
                                    659 	.globl __mcs51_genXINIT
                                    660 	.globl __mcs51_genXRAMCLEAR
                                    661 	.globl __mcs51_genRAMCLEAR
                                    662 ;	src/main_rcswitch.c:70: volatile uint8_t data_receiv = 0;
      0000EF 75 22 00         [24]  663 	mov	_data_receiv,#0x00
                                    664 ;	src/main_rcswitch.c:71: volatile uint8_t buffer_index1 = 0;
      0000F2 75 23 00         [24]  665 	mov	_buffer_index1,#0x00
                                    666 ;	src/main_rcswitch.c:72: volatile uint8_t buffer_index2 = 0;
      0000F5 75 24 00         [24]  667 	mov	_buffer_index2,#0x00
                                    668 ;	src/main_rcswitch.c:73: volatile uint8_t buffer_data0[BUFFER_SIZE] = { 0 };
      0000F8 75 25 00         [24]  669 	mov	_buffer_data0,#0x00
                                    670 ;	src/main_rcswitch.c:74: volatile uint8_t buffer_data1[BUFFER_SIZE] = { 0 };
      0000FB 75 2C 00         [24]  671 	mov	_buffer_data1,#0x00
                                    672 ;	src/main_rcswitch.c:75: volatile uint8_t buffer_data2[BUFFER_SIZE] = { 0 };
      0000FE 75 33 00         [24]  673 	mov	_buffer_data2,#0x00
                                    674 ;	src/main_rcswitch.c:76: volatile uint8_t buffer_data3[BUFFER_SIZE] = { 0 };
      000101 75 3A 00         [24]  675 	mov	_buffer_data3,#0x00
                                    676 ;	src/main_rcswitch.c:77: volatile uint8_t buffer_data4[BUFFER_SIZE] = { 0 };
      000104 75 41 00         [24]  677 	mov	_buffer_data4,#0x00
                                    678 ;	src/main_rcswitch.c:79: volatile _Bool buffer_ready[BUFFER_ARRAY] = { 0 };
      000107 75 48 00         [24]  679 	mov	_buffer_ready,#0x00
                                    680 ;	src/main_rcswitch.c:81: volatile uint8_t header_cnt = 0;
      00010A 75 4D 00         [24]  681 	mov	_header_cnt,#0x00
                                    682 ;	src/main_rcswitch.c:83: volatile uint8_t timeout_receiv = 0;
      00010D 75 4E 00         [24]  683 	mov	_timeout_receiv,#0x00
                                    684 ;	src/main_rcswitch.c:85: volatile _Bool preset_enabled = MOTOR_DISABLED;
      000110 75 4F 00         [24]  685 	mov	_preset_enabled,#0x00
                                    686 ;	src/main_rcswitch.c:87: volatile _Bool pan_enabled = MOTOR_DISABLED;
      000113 75 50 00         [24]  687 	mov	_pan_enabled,#0x00
                                    688 ;	src/main_rcswitch.c:88: volatile _Bool pan_direction = MOVE_CC;
      000116 75 51 00         [24]  689 	mov	_pan_direction,#0x00
                                    690 ;	src/main_rcswitch.c:89: volatile uint8_t pan_speed = 0;
      000119 75 52 00         [24]  691 	mov	_pan_speed,#0x00
                                    692 ;	src/main_rcswitch.c:90: volatile uint8_t pan_speed_old = 0;
      00011C 75 53 00         [24]  693 	mov	_pan_speed_old,#0x00
                                    694 ;	src/main_rcswitch.c:91: volatile uint16_t pan_counter = 0;
      00011F E4               [12]  695 	clr	a
      000120 F5 54            [12]  696 	mov	_pan_counter,a
      000122 F5 55            [12]  697 	mov	(_pan_counter + 1),a
                                    698 ;	src/main_rcswitch.c:93: volatile _Bool tilt_enabled = MOTOR_DISABLED;
      000124 F5 56            [12]  699 	mov	_tilt_enabled,a
                                    700 ;	src/main_rcswitch.c:94: volatile _Bool tilt_direction = MOVE_CC;
      000126 F5 57            [12]  701 	mov	_tilt_direction,a
                                    702 ;	src/main_rcswitch.c:95: volatile uint8_t tilt_speed = 0;
      000128 F5 58            [12]  703 	mov	_tilt_speed,a
                                    704 ;	src/main_rcswitch.c:96: volatile uint8_t tilt_speed_old = 0;
      00012A F5 59            [12]  705 	mov	_tilt_speed_old,a
                                    706 ;	src/main_rcswitch.c:97: volatile uint16_t tilt_counter = 0;
      00012C F5 5A            [12]  707 	mov	_tilt_counter,a
      00012E F5 5B            [12]  708 	mov	(_tilt_counter + 1),a
                                    709 ;	src/main_rcswitch.c:99: volatile uint8_t pan_step_phase = 0;
      000130 F5 5C            [12]  710 	mov	_pan_step_phase,a
                                    711 ;	src/main_rcswitch.c:100: volatile uint8_t tilt_step_phase = 0;
      000132 F5 5D            [12]  712 	mov	_tilt_step_phase,a
                                    713 ;	src/main_rcswitch.c:102: volatile uint8_t timer1_pan = 0;
      000134 F5 5E            [12]  714 	mov	_timer1_pan,a
                                    715 ;	src/main_rcswitch.c:103: volatile uint8_t timer1_tilt = 0;
      000136 F5 5F            [12]  716 	mov	_timer1_tilt,a
                                    717 ;	src/main_rcswitch.c:104: volatile uint8_t timer1_pan_ref = 0;
      000138 F5 60            [12]  718 	mov	_timer1_pan_ref,a
                                    719 ;	src/main_rcswitch.c:105: volatile uint8_t timer1_tilt_ref = 0;
      00013A F5 61            [12]  720 	mov	_timer1_tilt_ref,a
                                    721 ;	src/main_rcswitch.c:107: volatile uint8_t is_preset = 0;
      00013C F5 62            [12]  722 	mov	_is_preset,a
                                    723 ;	src/main_rcswitch.c:109: uint8_t alarms_data = 0;
      00013E F5 63            [12]  724 	mov	_alarms_data,a
                                    725 ;	src/main_rcswitch.c:111: uint8_t frame_index = 0;
      000140 F5 64            [12]  726 	mov	_frame_index,a
                                    727 ;	src/main_rcswitch.c:112: uint8_t frame_data[7] = { 0 };
      000142 F5 65            [12]  728 	mov	_frame_data,a
                                    729 ;	src/main_rcswitch.c:114: uint8_t header_pos = 0;
      000144 F5 6C            [12]  730 	mov	_header_pos,a
                                    731 ;	src/main_rcswitch.c:117: uint8_t response_type = RESP_NONE; // RESP_NONE
      000146 F5 6D            [12]  732 	mov	_response_type,a
                                    733 ;	src/main_rcswitch.c:119: uint8_t P_addr = 0;
      000148 F5 6E            [12]  734 	mov	_P_addr,a
                                    735 ;	src/main_rcswitch.c:120: uint8_t P_cmd1 = 0;
      00014A F5 6F            [12]  736 	mov	_P_cmd1,a
                                    737 ;	src/main_rcswitch.c:121: uint8_t P_cmd2 = 0;
      00014C F5 70            [12]  738 	mov	_P_cmd2,a
                                    739 ;	src/main_rcswitch.c:122: uint8_t P_dat1 = 0;
      00014E F5 71            [12]  740 	mov	_P_dat1,a
                                    741 ;	src/main_rcswitch.c:123: uint8_t P_dat2 = 0;
      000150 F5 72            [12]  742 	mov	_P_dat2,a
                                    743 ;	src/main_rcswitch.c:124: uint8_t P_chksum = 0;
      000152 F5 73            [12]  744 	mov	_P_chksum,a
                                    745 ;	src/main_rcswitch.c:126: uint8_t preset_id = 0;
      000154 F5 74            [12]  746 	mov	_preset_id,a
                                    747 	.area GSFINAL (CODE)
      000192 02 00 69         [24]  748 	ljmp	__sdcc_program_startup
                                    749 ;--------------------------------------------------------
                                    750 ; Home
                                    751 ;--------------------------------------------------------
                                    752 	.area HOME    (CODE)
                                    753 	.area HOME    (CODE)
      000069                        754 __sdcc_program_startup:
      000069 02 01 B6         [24]  755 	ljmp	_main
                                    756 ;	return from main will return to caller
                                    757 ;--------------------------------------------------------
                                    758 ; code
                                    759 ;--------------------------------------------------------
                                    760 	.area CSEG    (CODE)
                                    761 ;------------------------------------------------------------
                                    762 ;Allocation info for local variables in function '__sdcc_external_startup'
                                    763 ;------------------------------------------------------------
                                    764 ;	src/main_rcswitch.c:189: void __sdcc_external_startup(void) {
                                    765 ;	-----------------------------------------
                                    766 ;	 function __sdcc_external_startup
                                    767 ;	-----------------------------------------
      000195                        768 ___sdcc_external_startup:
                           000007   769 	ar7 = 0x07
                           000006   770 	ar6 = 0x06
                           000005   771 	ar5 = 0x05
                           000004   772 	ar4 = 0x04
                           000003   773 	ar3 = 0x03
                           000002   774 	ar2 = 0x02
                           000001   775 	ar1 = 0x01
                           000000   776 	ar0 = 0x00
                                    777 ;	src/main_rcswitch.c:191: }
      000195 22               [24]  778 	ret
                                    779 ;------------------------------------------------------------
                                    780 ;Allocation info for local variables in function 'startup_blink'
                                    781 ;------------------------------------------------------------
                                    782 ;	src/main_rcswitch.c:221: void startup_blink(void)
                                    783 ;	-----------------------------------------
                                    784 ;	 function startup_blink
                                    785 ;	-----------------------------------------
      000196                        786 _startup_blink:
                                    787 ;	drivers/ob38s003/inc/hal.h:46: LED = 0;
                                    788 ;	assignBit
      000196 C2 95            [12]  789 	clr	_P1_5
                                    790 ;	src/main_rcswitch.c:225: delay1ms(250);
      000198 90 00 FA         [24]  791 	mov	dptr,#0x00fa
      00019B 12 04 2B         [24]  792 	lcall	_delay1ms
                                    793 ;	drivers/ob38s003/inc/hal.h:41: LED = 1;
                                    794 ;	assignBit
      00019E D2 95            [12]  795 	setb	_P1_5
                                    796 ;	src/main_rcswitch.c:228: delay1ms(250);
      0001A0 90 00 FA         [24]  797 	mov	dptr,#0x00fa
      0001A3 12 04 2B         [24]  798 	lcall	_delay1ms
                                    799 ;	drivers/ob38s003/inc/hal.h:46: LED = 0;
                                    800 ;	assignBit
      0001A6 C2 95            [12]  801 	clr	_P1_5
                                    802 ;	src/main_rcswitch.c:231: delay1ms(250);
      0001A8 90 00 FA         [24]  803 	mov	dptr,#0x00fa
      0001AB 12 04 2B         [24]  804 	lcall	_delay1ms
                                    805 ;	drivers/ob38s003/inc/hal.h:41: LED = 1;
                                    806 ;	assignBit
      0001AE D2 95            [12]  807 	setb	_P1_5
                                    808 ;	src/main_rcswitch.c:234: delay1ms(250);
      0001B0 90 00 FA         [24]  809 	mov	dptr,#0x00fa
                                    810 ;	src/main_rcswitch.c:235: }
      0001B3 02 04 2B         [24]  811 	ljmp	_delay1ms
                                    812 ;------------------------------------------------------------
                                    813 ;Allocation info for local variables in function 'main'
                                    814 ;------------------------------------------------------------
                                    815 ;rxdataWithFlags Allocated to registers 
                                    816 ;i             Allocated to registers 
                                    817 ;chksum_calc   Allocated to registers 
                                    818 ;m             Allocated to registers 
                                    819 ;------------------------------------------------------------
                                    820 ;	src/main_rcswitch.c:240: int main(void) {
                                    821 ;	-----------------------------------------
                                    822 ;	 function main
                                    823 ;	-----------------------------------------
      0001B6                        824 _main:
                                    825 ;	src/main_rcswitch.c:250: delay1ms(500);
      0001B6 90 01 F4         [24]  826 	mov	dptr,#0x01f4
      0001B9 12 04 2B         [24]  827 	lcall	_delay1ms
                                    828 ;	src/main_rcswitch.c:253: set_clock_mode(); // 16MHz
      0001BC 12 04 4F         [24]  829 	lcall	_set_clock_mode
                                    830 ;	src/main_rcswitch.c:256: init_port_pins();
      0001BF 12 04 7E         [24]  831 	lcall	_init_port_pins
                                    832 ;	src/main_rcswitch.c:275: while (true) {
      0001C2                        833 00102$:
                                    834 ;	src/main_rcswitch.c:276: startup_blink();
      0001C2 12 01 96         [24]  835 	lcall	_startup_blink
                                    836 ;	src/main_rcswitch.c:535: frame_index = 0;
                                    837 ;	src/main_rcswitch.c:541: }
      0001C5 80 FB            [24]  838 	sjmp	00102$
                                    839 	.area CSEG    (CODE)
                                    840 	.area CONST   (CODE)
                                    841 	.area CONST   (CODE)
      000692                        842 ___str_2:
      000692 53 45 54 20 42 41 55   843 	.ascii "SET BAUD RATE "
             44 20 52 41 54 45 20
      0006A0 00                     844 	.db 0x00
                                    845 	.area CSEG    (CODE)
                                    846 	.area CONST   (CODE)
      0006A1                        847 ___str_3:
      0006A1 32 34 30 30            848 	.ascii "2400"
      0006A5 0D                     849 	.db 0x0d
      0006A6 0A                     850 	.db 0x0a
      0006A7 00                     851 	.db 0x00
                                    852 	.area CSEG    (CODE)
                                    853 	.area CONST   (CODE)
      0006A8                        854 ___str_4:
      0006A8 34 38 30 30            855 	.ascii "4800"
      0006AC 0D                     856 	.db 0x0d
      0006AD 0A                     857 	.db 0x0a
      0006AE 00                     858 	.db 0x00
                                    859 	.area CSEG    (CODE)
                                    860 	.area CONST   (CODE)
      0006AF                        861 ___str_5:
      0006AF 31 39 32 30 30         862 	.ascii "19200"
      0006B4 0D                     863 	.db 0x0d
      0006B5 0A                     864 	.db 0x0a
      0006B6 00                     865 	.db 0x00
                                    866 	.area CSEG    (CODE)
                                    867 	.area CONST   (CODE)
      0006B7                        868 ___str_6:
      0006B7 33 38 34 30 30         869 	.ascii "38400"
      0006BC 0D                     870 	.db 0x0d
      0006BD 0A                     871 	.db 0x0a
      0006BE 00                     872 	.db 0x00
                                    873 	.area CSEG    (CODE)
                                    874 	.area CONST   (CODE)
      0006BF                        875 ___str_7:
      0006BF 31 31 35 32 30 30      876 	.ascii "115200"
      0006C5 0D                     877 	.db 0x0d
      0006C6 0A                     878 	.db 0x0a
      0006C7 00                     879 	.db 0x00
                                    880 	.area CSEG    (CODE)
                                    881 	.area CONST   (CODE)
      0006C8                        882 ___str_8:
      0006C8 39 36 30 30            883 	.ascii "9600"
      0006CC 0D                     884 	.db 0x0d
      0006CD 0A                     885 	.db 0x0a
      0006CE 00                     886 	.db 0x00
                                    887 	.area CSEG    (CODE)
                                    888 	.area CONST   (CODE)
      0006CF                        889 ___str_9:
      0006CF 53 54 4F 50            890 	.ascii "STOP"
      0006D3 0D                     891 	.db 0x0d
      0006D4 0A                     892 	.db 0x0a
      0006D5 00                     893 	.db 0x00
                                    894 	.area CSEG    (CODE)
                                    895 	.area CONST   (CODE)
      0006D6                        896 ___str_10:
      0006D6 53 45 54 20 50 52 45   897 	.ascii "SET PRESET"
             53 45 54
      0006E0 0D                     898 	.db 0x0d
      0006E1 0A                     899 	.db 0x0a
      0006E2 00                     900 	.db 0x00
                                    901 	.area CSEG    (CODE)
                                    902 	.area CONST   (CODE)
      0006E3                        903 ___str_11:
      0006E3 43 4C 45 41 52 20 50   904 	.ascii "CLEAR PRESET"
             52 45 53 45 54
      0006EF 0D                     905 	.db 0x0d
      0006F0 0A                     906 	.db 0x0a
      0006F1 00                     907 	.db 0x00
                                    908 	.area CSEG    (CODE)
                                    909 	.area CONST   (CODE)
      0006F2                        910 ___str_12:
      0006F2 47 4F 54 4F 20 50 52   911 	.ascii "GOTO PRESET"
             45 53 45 54
      0006FD 0D                     912 	.db 0x0d
      0006FE 0A                     913 	.db 0x0a
      0006FF 00                     914 	.db 0x00
                                    915 	.area CSEG    (CODE)
                                    916 	.area CONST   (CODE)
      000700                        917 ___str_13:
      000700 4C 45 46 54            918 	.ascii "LEFT"
      000704 0D                     919 	.db 0x0d
      000705 0A                     920 	.db 0x0a
      000706 00                     921 	.db 0x00
                                    922 	.area CSEG    (CODE)
                                    923 	.area CONST   (CODE)
      000707                        924 ___str_14:
      000707 52 49 47 48 54         925 	.ascii "RIGHT"
      00070C 0D                     926 	.db 0x0d
      00070D 0A                     927 	.db 0x0a
      00070E 00                     928 	.db 0x00
                                    929 	.area CSEG    (CODE)
                                    930 	.area CONST   (CODE)
      00070F                        931 ___str_15:
      00070F 44 4F 57 4E            932 	.ascii "DOWN"
      000713 0D                     933 	.db 0x0d
      000714 0A                     934 	.db 0x0a
      000715 00                     935 	.db 0x00
                                    936 	.area CSEG    (CODE)
                                    937 	.area CONST   (CODE)
      000716                        938 ___str_16:
      000716 55 50                  939 	.ascii "UP"
      000718 0D                     940 	.db 0x0d
      000719 0A                     941 	.db 0x0a
      00071A 00                     942 	.db 0x00
                                    943 	.area CSEG    (CODE)
                                    944 	.area XINIT   (CODE)
                                    945 	.area CABS    (ABS,CODE)
