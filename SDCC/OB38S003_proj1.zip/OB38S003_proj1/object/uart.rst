                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.5.0 #15242 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module uart
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-small
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _uart_isr
                                     12 	.globl _EXEN2
                                     13 	.globl _IEIIC
                                     14 	.globl _IELVI
                                     15 	.globl _IEKBI
                                     16 	.globl _IEADC
                                     17 	.globl _IESPI
                                     18 	.globl _IEPWM
                                     19 	.globl _EXF2
                                     20 	.globl _TF2
                                     21 	.globl _IICIF
                                     22 	.globl _LVIIF
                                     23 	.globl _KBIIF
                                     24 	.globl _ADCIF
                                     25 	.globl _SPIIF
                                     26 	.globl _PWMIF
                                     27 	.globl _MPIF
                                     28 	.globl _LAIF
                                     29 	.globl _RXIF
                                     30 	.globl _TXIF
                                     31 	.globl _RXAK
                                     32 	.globl _TXAK
                                     33 	.globl _BB
                                     34 	.globl _RW
                                     35 	.globl _SM0
                                     36 	.globl _SM1
                                     37 	.globl _SM2
                                     38 	.globl _REN
                                     39 	.globl _TB8
                                     40 	.globl _RB8
                                     41 	.globl _TI
                                     42 	.globl _RI
                                     43 	.globl _EA
                                     44 	.globl _ET2
                                     45 	.globl _ES
                                     46 	.globl _ET1
                                     47 	.globl _EX1
                                     48 	.globl _ET0
                                     49 	.globl _EX0
                                     50 	.globl _TF1
                                     51 	.globl _TR1
                                     52 	.globl _TF0
                                     53 	.globl _TR0
                                     54 	.globl _IE1
                                     55 	.globl _IT1
                                     56 	.globl _IE0
                                     57 	.globl _IT0
                                     58 	.globl _CY
                                     59 	.globl _AC
                                     60 	.globl _F0
                                     61 	.globl _RS1
                                     62 	.globl _RS0
                                     63 	.globl _OV
                                     64 	.globl _F1
                                     65 	.globl _P
                                     66 	.globl _P3_1
                                     67 	.globl _P3_0
                                     68 	.globl _P1_7
                                     69 	.globl _P1_6
                                     70 	.globl _P1_5
                                     71 	.globl _P1_4
                                     72 	.globl _P1_3
                                     73 	.globl _P1_2
                                     74 	.globl _P1_1
                                     75 	.globl _P1_0
                                     76 	.globl _P0_7
                                     77 	.globl _P0_6
                                     78 	.globl _P0_5
                                     79 	.globl _P0_4
                                     80 	.globl _P0_3
                                     81 	.globl _P0_2
                                     82 	.globl _P0_1
                                     83 	.globl _P0_0
                                     84 	.globl _T2
                                     85 	.globl _CRC
                                     86 	.globl _CC3
                                     87 	.globl _CC2
                                     88 	.globl _CC1
                                     89 	.globl _CMP1CON
                                     90 	.globl _CMP0CON
                                     91 	.globl _OPPIN
                                     92 	.globl _IICEBT
                                     93 	.globl _IICRWD
                                     94 	.globl _IICA2
                                     95 	.globl _IICA1
                                     96 	.globl _IICCTL
                                     97 	.globl _IICS
                                     98 	.globl _SPIS
                                     99 	.globl _SPIRXD
                                    100 	.globl _SPITXD
                                    101 	.globl _SPIC2
                                    102 	.globl _SPIC1
                                    103 	.globl _P3M1
                                    104 	.globl _P3M0
                                    105 	.globl _P1M1
                                    106 	.globl _P1M0
                                    107 	.globl _P0M1
                                    108 	.globl _P0M0
                                    109 	.globl _TH2
                                    110 	.globl _TL2
                                    111 	.globl _CRCH
                                    112 	.globl _CRCL
                                    113 	.globl _CCCON
                                    114 	.globl _T2CON
                                    115 	.globl _CCH3
                                    116 	.globl _CCL3
                                    117 	.globl _CCH2
                                    118 	.globl _CCL2
                                    119 	.globl _CCH1
                                    120 	.globl _CCL1
                                    121 	.globl _CCEN2
                                    122 	.globl _CCEN
                                    123 	.globl _WDTK
                                    124 	.globl _WDTC
                                    125 	.globl _PWMMDL
                                    126 	.globl _PWMMDH
                                    127 	.globl _PWMD3L
                                    128 	.globl _PWMD3H
                                    129 	.globl _PWMD2L
                                    130 	.globl _PWMD2H
                                    131 	.globl _PWMD1L
                                    132 	.globl _PWMD1H
                                    133 	.globl _PWMD0L
                                    134 	.globl _PWMD0H
                                    135 	.globl _PWMC
                                    136 	.globl _ADCSH
                                    137 	.globl _ADCCS
                                    138 	.globl _ADCDL
                                    139 	.globl _ADCDH
                                    140 	.globl _ADCC2
                                    141 	.globl _ADCC1
                                    142 	.globl _SWRES
                                    143 	.globl _LVC
                                    144 	.globl _RSTS
                                    145 	.globl _IRCON2
                                    146 	.globl _KBD
                                    147 	.globl _KBF
                                    148 	.globl _KBE
                                    149 	.globl _KBLS
                                    150 	.globl _ENHIT
                                    151 	.globl _INTDEG
                                    152 	.globl _IRCON
                                    153 	.globl _IP1
                                    154 	.globl _IP0
                                    155 	.globl _IEN1
                                    156 	.globl _IEN0
                                    157 	.globl _IEN2
                                    158 	.globl _PFCON
                                    159 	.globl _SRELH
                                    160 	.globl _SRELL
                                    161 	.globl _S0RELH
                                    162 	.globl _S0RELL
                                    163 	.globl _S0BUF
                                    164 	.globl _S0CON
                                    165 	.globl _ISPFC
                                    166 	.globl _ISPFDH
                                    167 	.globl _ISPFDL
                                    168 	.globl _ISPFAL
                                    169 	.globl _ISPFAH
                                    170 	.globl _TAKEY
                                    171 	.globl _IFCON
                                    172 	.globl _AUX
                                    173 	.globl _DPH1
                                    174 	.globl _DPL1
                                    175 	.globl _IP
                                    176 	.globl _IE
                                    177 	.globl _SBUF
                                    178 	.globl _SCON
                                    179 	.globl _CKCON
                                    180 	.globl _TH1
                                    181 	.globl _TH0
                                    182 	.globl _TL1
                                    183 	.globl _TL0
                                    184 	.globl _TMOD
                                    185 	.globl _TCON
                                    186 	.globl _PCON
                                    187 	.globl _DPH
                                    188 	.globl _DPL
                                    189 	.globl _SP
                                    190 	.globl _B
                                    191 	.globl _ACC
                                    192 	.globl _PSW
                                    193 	.globl _P3
                                    194 	.globl _P1
                                    195 	.globl _P0
                                    196 	.globl _is_TI
                                    197 	.globl _uart_write
                                    198 	.globl _uart_write_Text
                                    199 	.globl _uart_init_tx_polling
                                    200 	.globl _is_uart_tx_finished
                                    201 	.globl _is_uart_tx_buffer_empty
                                    202 	.globl _uart_getc
                                    203 	.globl _uart_putc
                                    204 ;--------------------------------------------------------
                                    205 ; special function registers
                                    206 ;--------------------------------------------------------
                                    207 	.area RSEG    (ABS,DATA)
      000000                        208 	.org 0x0000
                           000080   209 _P0	=	0x0080
                           000090   210 _P1	=	0x0090
                           0000B0   211 _P3	=	0x00b0
                           0000D0   212 _PSW	=	0x00d0
                           0000E0   213 _ACC	=	0x00e0
                           0000F0   214 _B	=	0x00f0
                           000081   215 _SP	=	0x0081
                           000082   216 _DPL	=	0x0082
                           000083   217 _DPH	=	0x0083
                           000087   218 _PCON	=	0x0087
                           000088   219 _TCON	=	0x0088
                           000089   220 _TMOD	=	0x0089
                           00008A   221 _TL0	=	0x008a
                           00008B   222 _TL1	=	0x008b
                           00008C   223 _TH0	=	0x008c
                           00008D   224 _TH1	=	0x008d
                           00008E   225 _CKCON	=	0x008e
                           000098   226 _SCON	=	0x0098
                           000099   227 _SBUF	=	0x0099
                           0000A8   228 _IE	=	0x00a8
                           0000A9   229 _IP	=	0x00a9
                           000084   230 _DPL1	=	0x0084
                           000085   231 _DPH1	=	0x0085
                           000091   232 _AUX	=	0x0091
                           00008F   233 _IFCON	=	0x008f
                           0000F7   234 _TAKEY	=	0x00f7
                           0000E1   235 _ISPFAH	=	0x00e1
                           0000E2   236 _ISPFAL	=	0x00e2
                           0000E3   237 _ISPFDL	=	0x00e3
                           0000EB   238 _ISPFDH	=	0x00eb
                           0000E4   239 _ISPFC	=	0x00e4
                           000098   240 _S0CON	=	0x0098
                           000099   241 _S0BUF	=	0x0099
                           0000AA   242 _S0RELL	=	0x00aa
                           0000BA   243 _S0RELH	=	0x00ba
                           0000AA   244 _SRELL	=	0x00aa
                           0000BA   245 _SRELH	=	0x00ba
                           0000D9   246 _PFCON	=	0x00d9
                           00009A   247 _IEN2	=	0x009a
                           0000A8   248 _IEN0	=	0x00a8
                           0000B8   249 _IEN1	=	0x00b8
                           0000A9   250 _IP0	=	0x00a9
                           0000B9   251 _IP1	=	0x00b9
                           0000C0   252 _IRCON	=	0x00c0
                           0000EE   253 _INTDEG	=	0x00ee
                           0000E5   254 _ENHIT	=	0x00e5
                           000093   255 _KBLS	=	0x0093
                           000094   256 _KBE	=	0x0094
                           000095   257 _KBF	=	0x0095
                           000096   258 _KBD	=	0x0096
                           000097   259 _IRCON2	=	0x0097
                           0000A1   260 _RSTS	=	0x00a1
                           0000E6   261 _LVC	=	0x00e6
                           0000E7   262 _SWRES	=	0x00e7
                           0000AB   263 _ADCC1	=	0x00ab
                           0000AC   264 _ADCC2	=	0x00ac
                           0000AD   265 _ADCDH	=	0x00ad
                           0000AE   266 _ADCDL	=	0x00ae
                           0000AF   267 _ADCCS	=	0x00af
                           0000EF   268 _ADCSH	=	0x00ef
                           0000B5   269 _PWMC	=	0x00b5
                           0000BC   270 _PWMD0H	=	0x00bc
                           0000BD   271 _PWMD0L	=	0x00bd
                           0000BE   272 _PWMD1H	=	0x00be
                           0000BF   273 _PWMD1L	=	0x00bf
                           0000B1   274 _PWMD2H	=	0x00b1
                           0000B2   275 _PWMD2L	=	0x00b2
                           0000B3   276 _PWMD3H	=	0x00b3
                           0000B4   277 _PWMD3L	=	0x00b4
                           0000CE   278 _PWMMDH	=	0x00ce
                           0000CF   279 _PWMMDL	=	0x00cf
                           0000B6   280 _WDTC	=	0x00b6
                           0000B7   281 _WDTK	=	0x00b7
                           0000C1   282 _CCEN	=	0x00c1
                           0000D1   283 _CCEN2	=	0x00d1
                           0000C2   284 _CCL1	=	0x00c2
                           0000C3   285 _CCH1	=	0x00c3
                           0000C4   286 _CCL2	=	0x00c4
                           0000C5   287 _CCH2	=	0x00c5
                           0000C6   288 _CCL3	=	0x00c6
                           0000C7   289 _CCH3	=	0x00c7
                           0000C8   290 _T2CON	=	0x00c8
                           0000C9   291 _CCCON	=	0x00c9
                           0000CA   292 _CRCL	=	0x00ca
                           0000CB   293 _CRCH	=	0x00cb
                           0000CC   294 _TL2	=	0x00cc
                           0000CD   295 _TH2	=	0x00cd
                           0000D2   296 _P0M0	=	0x00d2
                           0000D3   297 _P0M1	=	0x00d3
                           0000D4   298 _P1M0	=	0x00d4
                           0000D5   299 _P1M1	=	0x00d5
                           0000DA   300 _P3M0	=	0x00da
                           0000DB   301 _P3M1	=	0x00db
                           0000F1   302 _SPIC1	=	0x00f1
                           0000F2   303 _SPIC2	=	0x00f2
                           0000F3   304 _SPITXD	=	0x00f3
                           0000F4   305 _SPIRXD	=	0x00f4
                           0000F5   306 _SPIS	=	0x00f5
                           0000F8   307 _IICS	=	0x00f8
                           0000F9   308 _IICCTL	=	0x00f9
                           0000FA   309 _IICA1	=	0x00fa
                           0000FB   310 _IICA2	=	0x00fb
                           0000FC   311 _IICRWD	=	0x00fc
                           0000FD   312 _IICEBT	=	0x00fd
                           0000F6   313 _OPPIN	=	0x00f6
                           0000FE   314 _CMP0CON	=	0x00fe
                           0000FF   315 _CMP1CON	=	0x00ff
                           00C3C2   316 _CC1	=	0xc3c2
                           00C5C4   317 _CC2	=	0xc5c4
                           00C7C6   318 _CC3	=	0xc7c6
                           00CBCA   319 _CRC	=	0xcbca
                           00CDCC   320 _T2	=	0xcdcc
                                    321 ;--------------------------------------------------------
                                    322 ; special function bits
                                    323 ;--------------------------------------------------------
                                    324 	.area RSEG    (ABS,DATA)
      000000                        325 	.org 0x0000
                           000080   326 _P0_0	=	0x0080
                           000081   327 _P0_1	=	0x0081
                           000082   328 _P0_2	=	0x0082
                           000083   329 _P0_3	=	0x0083
                           000084   330 _P0_4	=	0x0084
                           000085   331 _P0_5	=	0x0085
                           000086   332 _P0_6	=	0x0086
                           000087   333 _P0_7	=	0x0087
                           000090   334 _P1_0	=	0x0090
                           000091   335 _P1_1	=	0x0091
                           000092   336 _P1_2	=	0x0092
                           000093   337 _P1_3	=	0x0093
                           000094   338 _P1_4	=	0x0094
                           000095   339 _P1_5	=	0x0095
                           000096   340 _P1_6	=	0x0096
                           000097   341 _P1_7	=	0x0097
                           0000B0   342 _P3_0	=	0x00b0
                           0000B2   343 _P3_1	=	0x00b2
                           0000D0   344 _P	=	0x00d0
                           0000D1   345 _F1	=	0x00d1
                           0000D2   346 _OV	=	0x00d2
                           0000D3   347 _RS0	=	0x00d3
                           0000D4   348 _RS1	=	0x00d4
                           0000D5   349 _F0	=	0x00d5
                           0000D6   350 _AC	=	0x00d6
                           0000D7   351 _CY	=	0x00d7
                           000088   352 _IT0	=	0x0088
                           000089   353 _IE0	=	0x0089
                           00008A   354 _IT1	=	0x008a
                           00008B   355 _IE1	=	0x008b
                           00008C   356 _TR0	=	0x008c
                           00008D   357 _TF0	=	0x008d
                           00008E   358 _TR1	=	0x008e
                           00008F   359 _TF1	=	0x008f
                           0000A8   360 _EX0	=	0x00a8
                           0000A9   361 _ET0	=	0x00a9
                           0000AA   362 _EX1	=	0x00aa
                           0000AB   363 _ET1	=	0x00ab
                           0000AC   364 _ES	=	0x00ac
                           0000AD   365 _ET2	=	0x00ad
                           0000AF   366 _EA	=	0x00af
                           000098   367 _RI	=	0x0098
                           000099   368 _TI	=	0x0099
                           00009A   369 _RB8	=	0x009a
                           00009B   370 _TB8	=	0x009b
                           00009C   371 _REN	=	0x009c
                           00009D   372 _SM2	=	0x009d
                           00009E   373 _SM1	=	0x009e
                           00009F   374 _SM0	=	0x009f
                           0000F8   375 _RW	=	0x00f8
                           0000F8   376 _BB	=	0x00f8
                           0000F9   377 _TXAK	=	0x00f9
                           0000FA   378 _RXAK	=	0x00fa
                           0000FB   379 _TXIF	=	0x00fb
                           0000FC   380 _RXIF	=	0x00fc
                           0000FD   381 _LAIF	=	0x00fd
                           0000FE   382 _MPIF	=	0x00fe
                           0000C0   383 _PWMIF	=	0x00c0
                           0000C1   384 _SPIIF	=	0x00c1
                           0000C2   385 _ADCIF	=	0x00c2
                           0000C3   386 _KBIIF	=	0x00c3
                           0000C4   387 _LVIIF	=	0x00c4
                           0000C5   388 _IICIF	=	0x00c5
                           0000C6   389 _TF2	=	0x00c6
                           0000C7   390 _EXF2	=	0x00c7
                           0000B8   391 _IEPWM	=	0x00b8
                           0000B9   392 _IESPI	=	0x00b9
                           0000BA   393 _IEADC	=	0x00ba
                           0000BB   394 _IEKBI	=	0x00bb
                           0000BC   395 _IELVI	=	0x00bc
                           0000BD   396 _IEIIC	=	0x00bd
                           0000BF   397 _EXEN2	=	0x00bf
                                    398 ;--------------------------------------------------------
                                    399 ; overlayable register banks
                                    400 ;--------------------------------------------------------
                                    401 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        402 	.ds 8
                                    403 ;--------------------------------------------------------
                                    404 ; internal ram data
                                    405 ;--------------------------------------------------------
                                    406 	.area DSEG    (DATA)
      000008                        407 _is_TI::
      000008                        408 	.ds 1
      000009                        409 _gTXFinished:
      000009                        410 	.ds 1
                                    411 ;--------------------------------------------------------
                                    412 ; overlayable items in internal ram
                                    413 ;--------------------------------------------------------
                                    414 	.area	OSEG    (OVR,DATA)
                                    415 	.area	OSEG    (OVR,DATA)
                                    416 	.area	OSEG    (OVR,DATA)
                                    417 ;--------------------------------------------------------
                                    418 ; indirectly addressable internal ram data
                                    419 ;--------------------------------------------------------
                                    420 	.area ISEG    (DATA)
                                    421 ;--------------------------------------------------------
                                    422 ; absolute internal ram data
                                    423 ;--------------------------------------------------------
                                    424 	.area IABS    (ABS,DATA)
                                    425 	.area IABS    (ABS,DATA)
                                    426 ;--------------------------------------------------------
                                    427 ; bit data
                                    428 ;--------------------------------------------------------
                                    429 	.area BSEG    (BIT)
                                    430 ;--------------------------------------------------------
                                    431 ; paged external ram data
                                    432 ;--------------------------------------------------------
                                    433 	.area PSEG    (PAG,XDATA)
                                    434 ;--------------------------------------------------------
                                    435 ; uninitialized external ram data
                                    436 ;--------------------------------------------------------
                                    437 	.area XSEG    (XDATA)
                                    438 ;--------------------------------------------------------
                                    439 ; absolute external ram data
                                    440 ;--------------------------------------------------------
                                    441 	.area XABS    (ABS,XDATA)
                                    442 ;--------------------------------------------------------
                                    443 ; initialized external ram data
                                    444 ;--------------------------------------------------------
                                    445 	.area XISEG   (XDATA)
                                    446 	.area HOME    (CODE)
                                    447 	.area GSINIT0 (CODE)
                                    448 	.area GSINIT1 (CODE)
                                    449 	.area GSINIT2 (CODE)
                                    450 	.area GSINIT3 (CODE)
                                    451 	.area GSINIT4 (CODE)
                                    452 	.area GSINIT5 (CODE)
                                    453 	.area GSINIT  (CODE)
                                    454 	.area GSFINAL (CODE)
                                    455 	.area CSEG    (CODE)
                                    456 ;--------------------------------------------------------
                                    457 ; global & static initialisations
                                    458 ;--------------------------------------------------------
                                    459 	.area HOME    (CODE)
                                    460 	.area GSINIT  (CODE)
                                    461 	.area GSFINAL (CODE)
                                    462 	.area GSINIT  (CODE)
                                    463 ;	src/uart.c:30: volatile bool is_TI = 0;
      000156 75 08 00         [24]  464 	mov	_is_TI,#0x00
                                    465 ;	src/uart.c:61: static volatile bool gTXFinished = true;
      000159 75 09 01         [24]  466 	mov	_gTXFinished,#0x01
                                    467 ;--------------------------------------------------------
                                    468 ; Home
                                    469 ;--------------------------------------------------------
                                    470 	.area HOME    (CODE)
                                    471 	.area HOME    (CODE)
                                    472 ;--------------------------------------------------------
                                    473 ; code
                                    474 ;--------------------------------------------------------
                                    475 	.area CSEG    (CODE)
                                    476 ;------------------------------------------------------------
                                    477 ;Allocation info for local variables in function 'uart_write'
                                    478 ;------------------------------------------------------------
                                    479 ;value         Allocated to registers r7 
                                    480 ;------------------------------------------------------------
                                    481 ;	src/uart.c:68: void uart_write(const uint8_t value) {
                                    482 ;	-----------------------------------------
                                    483 ;	 function uart_write
                                    484 ;	-----------------------------------------
      0001C7                        485 _uart_write:
                           000007   486 	ar7 = 0x07
                           000006   487 	ar6 = 0x06
                           000005   488 	ar5 = 0x05
                           000004   489 	ar4 = 0x04
                           000003   490 	ar3 = 0x03
                           000002   491 	ar2 = 0x02
                           000001   492 	ar1 = 0x01
                           000000   493 	ar0 = 0x00
      0001C7 AF 82            [24]  494 	mov	r7, dpl
                                    495 ;	src/uart.c:69: TI = 0; // TI: Transmit interrupt flag, set by hardware after completion of a serial transfer.
                                    496 ;	assignBit
      0001C9 C2 99            [12]  497 	clr	_TI
                                    498 ;	src/uart.c:72: SBUF = value;
      0001CB 8F 99            [24]  499 	mov	_SBUF,r7
                                    500 ;	src/uart.c:74: is_TI = 0;
      0001CD 75 08 00         [24]  501 	mov	_is_TI,#0x00
                                    502 ;	src/uart.c:76: while (is_TI == 0)
      0001D0                        503 00101$:
      0001D0 E5 08            [12]  504 	mov	a,_is_TI
      0001D2 60 FC            [24]  505 	jz	00101$
                                    506 ;	src/uart.c:78: }
      0001D4 22               [24]  507 	ret
                                    508 ;------------------------------------------------------------
                                    509 ;Allocation info for local variables in function 'uart_write_Text'
                                    510 ;------------------------------------------------------------
                                    511 ;text          Allocated to registers r5 r6 r7 
                                    512 ;i             Allocated to registers r3 r4 
                                    513 ;------------------------------------------------------------
                                    514 ;	src/uart.c:80: void uart_write_Text(char *text) {
                                    515 ;	-----------------------------------------
                                    516 ;	 function uart_write_Text
                                    517 ;	-----------------------------------------
      0001D5                        518 _uart_write_Text:
      0001D5 AD 82            [24]  519 	mov	r5, dpl
      0001D7 AE 83            [24]  520 	mov	r6, dph
      0001D9 AF F0            [24]  521 	mov	r7, b
                                    522 ;	src/uart.c:82: for (i = 0; text[i] != '\0'; i++)
      0001DB 7B 00            [12]  523 	mov	r3,#0x00
      0001DD 7C 00            [12]  524 	mov	r4,#0x00
      0001DF                        525 00103$:
      0001DF EB               [12]  526 	mov	a,r3
      0001E0 2D               [12]  527 	add	a, r5
      0001E1 F8               [12]  528 	mov	r0,a
      0001E2 EC               [12]  529 	mov	a,r4
      0001E3 3E               [12]  530 	addc	a, r6
      0001E4 F9               [12]  531 	mov	r1,a
      0001E5 8F 02            [24]  532 	mov	ar2,r7
      0001E7 88 82            [24]  533 	mov	dpl,r0
      0001E9 89 83            [24]  534 	mov	dph,r1
      0001EB 8A F0            [24]  535 	mov	b,r2
      0001ED 12 06 76         [24]  536 	lcall	__gptrget
      0001F0 FA               [12]  537 	mov	r2,a
      0001F1 60 20            [24]  538 	jz	00105$
                                    539 ;	src/uart.c:83: uart_write(text[i]);
      0001F3 8A 82            [24]  540 	mov	dpl, r2
      0001F5 C0 07            [24]  541 	push	ar7
      0001F7 C0 06            [24]  542 	push	ar6
      0001F9 C0 05            [24]  543 	push	ar5
      0001FB C0 04            [24]  544 	push	ar4
      0001FD C0 03            [24]  545 	push	ar3
      0001FF 12 01 C7         [24]  546 	lcall	_uart_write
      000202 D0 03            [24]  547 	pop	ar3
      000204 D0 04            [24]  548 	pop	ar4
      000206 D0 05            [24]  549 	pop	ar5
      000208 D0 06            [24]  550 	pop	ar6
      00020A D0 07            [24]  551 	pop	ar7
                                    552 ;	src/uart.c:82: for (i = 0; text[i] != '\0'; i++)
      00020C 0B               [12]  553 	inc	r3
      00020D BB 00 CF         [24]  554 	cjne	r3,#0x00,00103$
      000210 0C               [12]  555 	inc	r4
      000211 80 CC            [24]  556 	sjmp	00103$
      000213                        557 00105$:
                                    558 ;	src/uart.c:84: }
      000213 22               [24]  559 	ret
                                    560 ;------------------------------------------------------------
                                    561 ;Allocation info for local variables in function 'uart_init_tx_polling'
                                    562 ;------------------------------------------------------------
                                    563 ;	src/uart.c:88: void uart_init_tx_polling(void) {
                                    564 ;	-----------------------------------------
                                    565 ;	 function uart_init_tx_polling
                                    566 ;	-----------------------------------------
      000214                        567 _uart_init_tx_polling:
                                    568 ;	src/uart.c:89: TI = 1;
                                    569 ;	assignBit
      000214 D2 99            [12]  570 	setb	_TI
                                    571 ;	src/uart.c:90: }
      000216 22               [24]  572 	ret
                                    573 ;------------------------------------------------------------
                                    574 ;Allocation info for local variables in function 'uart_isr'
                                    575 ;------------------------------------------------------------
                                    576 ;SCON_buff     Allocated to registers 
                                    577 ;------------------------------------------------------------
                                    578 ;	src/uart.c:95: void uart_isr(void)
                                    579 ;	-----------------------------------------
                                    580 ;	 function uart_isr
                                    581 ;	-----------------------------------------
      000217                        582 _uart_isr:
      000217 C0 E0            [24]  583 	push	acc
      000219 C0 07            [24]  584 	push	ar7
      00021B C0 06            [24]  585 	push	ar6
      00021D C0 00            [24]  586 	push	ar0
      00021F C0 D0            [24]  587 	push	psw
      000221 75 D0 00         [24]  588 	mov	psw,#0x00
                                    589 ;	src/uart.c:103: if ((SCON_buff & 0x02) == 0x02) {
      000224 AF 98            [24]  590 	mov	r7,_SCON
      000226 74 02            [12]  591 	mov	a,#0x02
      000228 5F               [12]  592 	anl	a,r7
      000229 FE               [12]  593 	mov	r6,a
      00022A BE 02 05         [24]  594 	cjne	r6,#0x02,00102$
                                    595 ;	src/uart.c:104: is_TI = 1;
      00022D 75 08 01         [24]  596 	mov	_is_TI,#0x01
                                    597 ;	src/uart.c:106: TI = 0;
                                    598 ;	assignBit
      000230 C2 99            [12]  599 	clr	_TI
      000232                        600 00102$:
                                    601 ;	src/uart.c:109: if ((SCON_buff & 0x01) == 0x01) { // receiving byte
      000232 53 07 01         [24]  602 	anl	ar7,#0x01
      000235 BF 01 02         [24]  603 	cjne	r7,#0x01,00214$
      000238 80 03            [24]  604 	sjmp	00215$
      00023A                        605 00214$:
      00023A 02 02 DF         [24]  606 	ljmp	00132$
      00023D                        607 00215$:
                                    608 ;	src/uart.c:110: RI = 0;
                                    609 ;	assignBit
      00023D C2 98            [12]  610 	clr	_RI
                                    611 ;	src/uart.c:112: data_receiv = SBUF;//UART1_Read();
      00023F 85 99 22         [24]  612 	mov	_data_receiv,_SBUF
                                    613 ;	src/uart.c:114: if (is_motor_init == 1) {
      000242 74 01            [12]  614 	mov	a,#0x01
      000244 B5 0A 03         [24]  615 	cjne	a,_is_motor_init,00104$
                                    616 ;	src/uart.c:115: return;
      000247 02 02 DF         [24]  617 	ljmp	00132$
      00024A                        618 00104$:
                                    619 ;	src/uart.c:120: if (data_receiv == P_SYNC) {
      00024A 74 FF            [12]  620 	mov	a,#0xff
      00024C B5 22 03         [24]  621 	cjne	a,_data_receiv,00106$
                                    622 ;	src/uart.c:121: timeout_receiv = 0;
      00024F 75 4E 00         [24]  623 	mov	_timeout_receiv,#0x00
      000252                        624 00106$:
                                    625 ;	src/uart.c:124: if ((buffer_index2 <= 6) || ((buffer_index2 == 0) && (data_receiv == P_SYNC))) {
      000252 E5 24            [12]  626 	mov	a,_buffer_index2
      000254 24 F9            [12]  627 	add	a,#0xff - 0x06
      000256 50 0C            [24]  628 	jnc	00121$
      000258 E5 24            [12]  629 	mov	a,_buffer_index2
      00025A 60 03            [24]  630 	jz	00221$
      00025C 02 02 C0         [24]  631 	ljmp	00122$
      00025F                        632 00221$:
      00025F 74 FF            [12]  633 	mov	a,#0xff
      000261 B5 22 5C         [24]  634 	cjne	a,_data_receiv,00122$
      000264                        635 00121$:
                                    636 ;	src/uart.c:125: if (buffer_index1 == 0) {
      000264 E5 23            [12]  637 	mov	a,_buffer_index1
      000266 70 0E            [24]  638 	jnz	00119$
                                    639 ;	src/uart.c:126: buffer_data0[buffer_index2++] = data_receiv;
      000268 E5 24            [12]  640 	mov	a,_buffer_index2
      00026A FF               [12]  641 	mov	r7,a
      00026B 04               [12]  642 	inc	a
      00026C F5 24            [12]  643 	mov	_buffer_index2,a
      00026E EF               [12]  644 	mov	a,r7
      00026F 24 25            [12]  645 	add	a, #_buffer_data0
      000271 F8               [12]  646 	mov	r0,a
      000272 A6 22            [24]  647 	mov	@r0,_data_receiv
      000274 80 4A            [24]  648 	sjmp	00122$
      000276                        649 00119$:
                                    650 ;	src/uart.c:127: } else if (buffer_index1 == 1) {
      000276 74 01            [12]  651 	mov	a,#0x01
      000278 B5 23 0E         [24]  652 	cjne	a,_buffer_index1,00116$
                                    653 ;	src/uart.c:128: buffer_data1[buffer_index2++] = data_receiv;
      00027B E5 24            [12]  654 	mov	a,_buffer_index2
      00027D FF               [12]  655 	mov	r7,a
      00027E 04               [12]  656 	inc	a
      00027F F5 24            [12]  657 	mov	_buffer_index2,a
      000281 EF               [12]  658 	mov	a,r7
      000282 24 2C            [12]  659 	add	a, #_buffer_data1
      000284 F8               [12]  660 	mov	r0,a
      000285 A6 22            [24]  661 	mov	@r0,_data_receiv
      000287 80 37            [24]  662 	sjmp	00122$
      000289                        663 00116$:
                                    664 ;	src/uart.c:129: } else if (buffer_index1 == 2) {
      000289 74 02            [12]  665 	mov	a,#0x02
      00028B B5 23 0E         [24]  666 	cjne	a,_buffer_index1,00113$
                                    667 ;	src/uart.c:130: buffer_data2[buffer_index2++] = data_receiv;
      00028E E5 24            [12]  668 	mov	a,_buffer_index2
      000290 FF               [12]  669 	mov	r7,a
      000291 04               [12]  670 	inc	a
      000292 F5 24            [12]  671 	mov	_buffer_index2,a
      000294 EF               [12]  672 	mov	a,r7
      000295 24 33            [12]  673 	add	a, #_buffer_data2
      000297 F8               [12]  674 	mov	r0,a
      000298 A6 22            [24]  675 	mov	@r0,_data_receiv
      00029A 80 24            [24]  676 	sjmp	00122$
      00029C                        677 00113$:
                                    678 ;	src/uart.c:131: } else if (buffer_index1 == 3) {
      00029C 74 03            [12]  679 	mov	a,#0x03
      00029E B5 23 0E         [24]  680 	cjne	a,_buffer_index1,00110$
                                    681 ;	src/uart.c:132: buffer_data3[buffer_index2++] = data_receiv;
      0002A1 E5 24            [12]  682 	mov	a,_buffer_index2
      0002A3 FF               [12]  683 	mov	r7,a
      0002A4 04               [12]  684 	inc	a
      0002A5 F5 24            [12]  685 	mov	_buffer_index2,a
      0002A7 EF               [12]  686 	mov	a,r7
      0002A8 24 3A            [12]  687 	add	a, #_buffer_data3
      0002AA F8               [12]  688 	mov	r0,a
      0002AB A6 22            [24]  689 	mov	@r0,_data_receiv
      0002AD 80 11            [24]  690 	sjmp	00122$
      0002AF                        691 00110$:
                                    692 ;	src/uart.c:133: } else if (buffer_index1 == 4) {
      0002AF 74 04            [12]  693 	mov	a,#0x04
      0002B1 B5 23 0C         [24]  694 	cjne	a,_buffer_index1,00122$
                                    695 ;	src/uart.c:134: buffer_data4[buffer_index2++] = data_receiv;
      0002B4 E5 24            [12]  696 	mov	a,_buffer_index2
      0002B6 FF               [12]  697 	mov	r7,a
      0002B7 04               [12]  698 	inc	a
      0002B8 F5 24            [12]  699 	mov	_buffer_index2,a
      0002BA EF               [12]  700 	mov	a,r7
      0002BB 24 41            [12]  701 	add	a, #_buffer_data4
      0002BD F8               [12]  702 	mov	r0,a
      0002BE A6 22            [24]  703 	mov	@r0,_data_receiv
      0002C0                        704 00122$:
                                    705 ;	src/uart.c:138: if (buffer_index2 == 7) {
      0002C0 74 07            [12]  706 	mov	a,#0x07
      0002C2 B5 24 1A         [24]  707 	cjne	a,_buffer_index2,00132$
                                    708 ;	src/uart.c:139: buffer_index2 = 0;
      0002C5 75 24 00         [24]  709 	mov	_buffer_index2,#0x00
                                    710 ;	src/uart.c:141: buffer_ready[buffer_index1] = 1;
      0002C8 E5 23            [12]  711 	mov	a,_buffer_index1
      0002CA 24 48            [12]  712 	add	a, #_buffer_ready
      0002CC F8               [12]  713 	mov	r0,a
      0002CD 76 01            [12]  714 	mov	@r0,#0x01
                                    715 ;	src/uart.c:143: if (buffer_index1 < 4) { // if (buffer_index1 < 2) {
      0002CF 74 FC            [12]  716 	mov	a,#0x100 - 0x04
      0002D1 25 23            [12]  717 	add	a,_buffer_index1
      0002D3 40 07            [24]  718 	jc	00126$
                                    719 ;	src/uart.c:144: buffer_index1++;
      0002D5 E5 23            [12]  720 	mov	a,_buffer_index1
      0002D7 04               [12]  721 	inc	a
      0002D8 F5 23            [12]  722 	mov	_buffer_index1,a
      0002DA 80 03            [24]  723 	sjmp	00132$
      0002DC                        724 00126$:
                                    725 ;	src/uart.c:146: buffer_index1 = 0;
      0002DC 75 23 00         [24]  726 	mov	_buffer_index1,#0x00
      0002DF                        727 00132$:
                                    728 ;	src/uart.c:185: }
      0002DF D0 D0            [24]  729 	pop	psw
      0002E1 D0 00            [24]  730 	pop	ar0
      0002E3 D0 06            [24]  731 	pop	ar6
      0002E5 D0 07            [24]  732 	pop	ar7
      0002E7 D0 E0            [24]  733 	pop	acc
      0002E9 32               [24]  734 	reti
                                    735 ;	eliminated unneeded push/pop ar1
                                    736 ;	eliminated unneeded push/pop dpl
                                    737 ;	eliminated unneeded push/pop dph
                                    738 ;	eliminated unneeded push/pop b
                                    739 ;------------------------------------------------------------
                                    740 ;Allocation info for local variables in function 'is_uart_tx_finished'
                                    741 ;------------------------------------------------------------
                                    742 ;	src/uart.c:189: bool is_uart_tx_finished(void) {
                                    743 ;	-----------------------------------------
                                    744 ;	 function is_uart_tx_finished
                                    745 ;	-----------------------------------------
      0002EA                        746 _is_uart_tx_finished:
                                    747 ;	src/uart.c:190: return gTXFinished;
      0002EA 85 09 82         [24]  748 	mov	dpl, _gTXFinished
                                    749 ;	src/uart.c:191: }
      0002ED 22               [24]  750 	ret
                                    751 ;------------------------------------------------------------
                                    752 ;Allocation info for local variables in function 'is_uart_tx_buffer_empty'
                                    753 ;------------------------------------------------------------
                                    754 ;	src/uart.c:193: bool is_uart_tx_buffer_empty(void) {
                                    755 ;	-----------------------------------------
                                    756 ;	 function is_uart_tx_buffer_empty
                                    757 ;	-----------------------------------------
      0002EE                        758 _is_uart_tx_buffer_empty:
                                    759 ;	src/uart.c:199: return true;
      0002EE 75 82 01         [24]  760 	mov	dpl, #0x01
                                    761 ;	src/uart.c:200: }
      0002F1 22               [24]  762 	ret
                                    763 ;------------------------------------------------------------
                                    764 ;Allocation info for local variables in function 'uart_getc'
                                    765 ;------------------------------------------------------------
                                    766 ;rxdata        Allocated to registers 
                                    767 ;------------------------------------------------------------
                                    768 ;	src/uart.c:208: unsigned int uart_getc(void) {
                                    769 ;	-----------------------------------------
                                    770 ;	 function uart_getc
                                    771 ;	-----------------------------------------
      0002F2                        772 _uart_getc:
                                    773 ;	src/uart.c:230: return rxdata;
      0002F2 90 00 00         [24]  774 	mov	dptr,#0x0000
                                    775 ;	src/uart.c:231: }
      0002F5 22               [24]  776 	ret
                                    777 ;------------------------------------------------------------
                                    778 ;Allocation info for local variables in function 'uart_putc'
                                    779 ;------------------------------------------------------------
                                    780 ;txdata        Allocated to registers 
                                    781 ;------------------------------------------------------------
                                    782 ;	src/uart.c:239: void uart_putc(const uint8_t txdata) {
                                    783 ;	-----------------------------------------
                                    784 ;	 function uart_putc
                                    785 ;	-----------------------------------------
      0002F6                        786 _uart_putc:
                                    787 ;	src/uart.c:248: (void) txdata;
                                    788 ;	src/uart.c:249: }
      0002F6 22               [24]  789 	ret
                                    790 	.area CSEG    (CODE)
                                    791 	.area CONST   (CODE)
                                    792 	.area XINIT   (CODE)
                                    793 	.area CABS    (ABS,CODE)
