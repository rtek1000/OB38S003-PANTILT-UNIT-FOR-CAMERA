                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.5.0 #15242 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module motor
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-small
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _steps_phase_2
                                     12 	.globl _steps_phase_1
                                     13 	.globl _speed_ref
                                     14 	.globl _uart_write_Text
                                     15 	.globl _delay1ms
                                     16 	.globl _EXEN2
                                     17 	.globl _IEIIC
                                     18 	.globl _IELVI
                                     19 	.globl _IEKBI
                                     20 	.globl _IEADC
                                     21 	.globl _IESPI
                                     22 	.globl _IEPWM
                                     23 	.globl _EXF2
                                     24 	.globl _TF2
                                     25 	.globl _IICIF
                                     26 	.globl _LVIIF
                                     27 	.globl _KBIIF
                                     28 	.globl _ADCIF
                                     29 	.globl _SPIIF
                                     30 	.globl _PWMIF
                                     31 	.globl _MPIF
                                     32 	.globl _LAIF
                                     33 	.globl _RXIF
                                     34 	.globl _TXIF
                                     35 	.globl _RXAK
                                     36 	.globl _TXAK
                                     37 	.globl _BB
                                     38 	.globl _RW
                                     39 	.globl _SM0
                                     40 	.globl _SM1
                                     41 	.globl _SM2
                                     42 	.globl _REN
                                     43 	.globl _TB8
                                     44 	.globl _RB8
                                     45 	.globl _TI
                                     46 	.globl _RI
                                     47 	.globl _EA
                                     48 	.globl _ET2
                                     49 	.globl _ES
                                     50 	.globl _ET1
                                     51 	.globl _EX1
                                     52 	.globl _ET0
                                     53 	.globl _EX0
                                     54 	.globl _TF1
                                     55 	.globl _TR1
                                     56 	.globl _TF0
                                     57 	.globl _TR0
                                     58 	.globl _IE1
                                     59 	.globl _IT1
                                     60 	.globl _IE0
                                     61 	.globl _IT0
                                     62 	.globl _CY
                                     63 	.globl _AC
                                     64 	.globl _F0
                                     65 	.globl _RS1
                                     66 	.globl _RS0
                                     67 	.globl _OV
                                     68 	.globl _F1
                                     69 	.globl _P
                                     70 	.globl _P3_1
                                     71 	.globl _P3_0
                                     72 	.globl _P1_7
                                     73 	.globl _P1_6
                                     74 	.globl _P1_5
                                     75 	.globl _P1_4
                                     76 	.globl _P1_3
                                     77 	.globl _P1_2
                                     78 	.globl _P1_1
                                     79 	.globl _P1_0
                                     80 	.globl _P0_7
                                     81 	.globl _P0_6
                                     82 	.globl _P0_5
                                     83 	.globl _P0_4
                                     84 	.globl _P0_3
                                     85 	.globl _P0_2
                                     86 	.globl _P0_1
                                     87 	.globl _P0_0
                                     88 	.globl _T2
                                     89 	.globl _CRC
                                     90 	.globl _CC3
                                     91 	.globl _CC2
                                     92 	.globl _CC1
                                     93 	.globl _CMP1CON
                                     94 	.globl _CMP0CON
                                     95 	.globl _OPPIN
                                     96 	.globl _IICEBT
                                     97 	.globl _IICRWD
                                     98 	.globl _IICA2
                                     99 	.globl _IICA1
                                    100 	.globl _IICCTL
                                    101 	.globl _IICS
                                    102 	.globl _SPIS
                                    103 	.globl _SPIRXD
                                    104 	.globl _SPITXD
                                    105 	.globl _SPIC2
                                    106 	.globl _SPIC1
                                    107 	.globl _P3M1
                                    108 	.globl _P3M0
                                    109 	.globl _P1M1
                                    110 	.globl _P1M0
                                    111 	.globl _P0M1
                                    112 	.globl _P0M0
                                    113 	.globl _TH2
                                    114 	.globl _TL2
                                    115 	.globl _CRCH
                                    116 	.globl _CRCL
                                    117 	.globl _CCCON
                                    118 	.globl _T2CON
                                    119 	.globl _CCH3
                                    120 	.globl _CCL3
                                    121 	.globl _CCH2
                                    122 	.globl _CCL2
                                    123 	.globl _CCH1
                                    124 	.globl _CCL1
                                    125 	.globl _CCEN2
                                    126 	.globl _CCEN
                                    127 	.globl _WDTK
                                    128 	.globl _WDTC
                                    129 	.globl _PWMMDL
                                    130 	.globl _PWMMDH
                                    131 	.globl _PWMD3L
                                    132 	.globl _PWMD3H
                                    133 	.globl _PWMD2L
                                    134 	.globl _PWMD2H
                                    135 	.globl _PWMD1L
                                    136 	.globl _PWMD1H
                                    137 	.globl _PWMD0L
                                    138 	.globl _PWMD0H
                                    139 	.globl _PWMC
                                    140 	.globl _ADCSH
                                    141 	.globl _ADCCS
                                    142 	.globl _ADCDL
                                    143 	.globl _ADCDH
                                    144 	.globl _ADCC2
                                    145 	.globl _ADCC1
                                    146 	.globl _SWRES
                                    147 	.globl _LVC
                                    148 	.globl _RSTS
                                    149 	.globl _IRCON2
                                    150 	.globl _KBD
                                    151 	.globl _KBF
                                    152 	.globl _KBE
                                    153 	.globl _KBLS
                                    154 	.globl _ENHIT
                                    155 	.globl _INTDEG
                                    156 	.globl _IRCON
                                    157 	.globl _IP1
                                    158 	.globl _IP0
                                    159 	.globl _IEN1
                                    160 	.globl _IEN0
                                    161 	.globl _IEN2
                                    162 	.globl _PFCON
                                    163 	.globl _SRELH
                                    164 	.globl _SRELL
                                    165 	.globl _S0RELH
                                    166 	.globl _S0RELL
                                    167 	.globl _S0BUF
                                    168 	.globl _S0CON
                                    169 	.globl _ISPFC
                                    170 	.globl _ISPFDH
                                    171 	.globl _ISPFDL
                                    172 	.globl _ISPFAL
                                    173 	.globl _ISPFAH
                                    174 	.globl _TAKEY
                                    175 	.globl _IFCON
                                    176 	.globl _AUX
                                    177 	.globl _DPH1
                                    178 	.globl _DPL1
                                    179 	.globl _IP
                                    180 	.globl _IE
                                    181 	.globl _SBUF
                                    182 	.globl _SCON
                                    183 	.globl _CKCON
                                    184 	.globl _TH1
                                    185 	.globl _TH0
                                    186 	.globl _TL1
                                    187 	.globl _TL0
                                    188 	.globl _TMOD
                                    189 	.globl _TCON
                                    190 	.globl _PCON
                                    191 	.globl _DPH
                                    192 	.globl _DPL
                                    193 	.globl _SP
                                    194 	.globl _B
                                    195 	.globl _ACC
                                    196 	.globl _PSW
                                    197 	.globl _P3
                                    198 	.globl _P1
                                    199 	.globl _P0
                                    200 	.globl _mot2_cnt1
                                    201 	.globl _mot1_cnt1
                                    202 	.globl _mot2_speed_tmr
                                    203 	.globl _mot1_speed_tmr
                                    204 	.globl _mot2_speed_old
                                    205 	.globl _mot1_speed_old
                                    206 	.globl _mot2_speed
                                    207 	.globl _mot1_speed
                                    208 	.globl _mot2_direction
                                    209 	.globl _mot1_direction
                                    210 	.globl _mot2_enabled
                                    211 	.globl _mot1_enabled
                                    212 	.globl _mot2_step
                                    213 	.globl _mot1_step
                                    214 	.globl _is_motor_init
                                    215 	.globl _motor_init
                                    216 	.globl _motor1_enable
                                    217 	.globl _motor1_disable
                                    218 	.globl _motor2_enable
                                    219 	.globl _motor2_disable
                                    220 	.globl _motor1_set_speed
                                    221 	.globl _motor2_set_speed
                                    222 	.globl _motor_speed_calc
                                    223 	.globl _motor1_set_dir
                                    224 	.globl _motor2_set_dir
                                    225 	.globl _motor1_step_cc
                                    226 	.globl _motor1_step_ccw
                                    227 	.globl _motor2_step_cc
                                    228 	.globl _motor2_step_ccw
                                    229 ;--------------------------------------------------------
                                    230 ; special function registers
                                    231 ;--------------------------------------------------------
                                    232 	.area RSEG    (ABS,DATA)
      000000                        233 	.org 0x0000
                           000080   234 _P0	=	0x0080
                           000090   235 _P1	=	0x0090
                           0000B0   236 _P3	=	0x00b0
                           0000D0   237 _PSW	=	0x00d0
                           0000E0   238 _ACC	=	0x00e0
                           0000F0   239 _B	=	0x00f0
                           000081   240 _SP	=	0x0081
                           000082   241 _DPL	=	0x0082
                           000083   242 _DPH	=	0x0083
                           000087   243 _PCON	=	0x0087
                           000088   244 _TCON	=	0x0088
                           000089   245 _TMOD	=	0x0089
                           00008A   246 _TL0	=	0x008a
                           00008B   247 _TL1	=	0x008b
                           00008C   248 _TH0	=	0x008c
                           00008D   249 _TH1	=	0x008d
                           00008E   250 _CKCON	=	0x008e
                           000098   251 _SCON	=	0x0098
                           000099   252 _SBUF	=	0x0099
                           0000A8   253 _IE	=	0x00a8
                           0000A9   254 _IP	=	0x00a9
                           000084   255 _DPL1	=	0x0084
                           000085   256 _DPH1	=	0x0085
                           000091   257 _AUX	=	0x0091
                           00008F   258 _IFCON	=	0x008f
                           0000F7   259 _TAKEY	=	0x00f7
                           0000E1   260 _ISPFAH	=	0x00e1
                           0000E2   261 _ISPFAL	=	0x00e2
                           0000E3   262 _ISPFDL	=	0x00e3
                           0000EB   263 _ISPFDH	=	0x00eb
                           0000E4   264 _ISPFC	=	0x00e4
                           000098   265 _S0CON	=	0x0098
                           000099   266 _S0BUF	=	0x0099
                           0000AA   267 _S0RELL	=	0x00aa
                           0000BA   268 _S0RELH	=	0x00ba
                           0000AA   269 _SRELL	=	0x00aa
                           0000BA   270 _SRELH	=	0x00ba
                           0000D9   271 _PFCON	=	0x00d9
                           00009A   272 _IEN2	=	0x009a
                           0000A8   273 _IEN0	=	0x00a8
                           0000B8   274 _IEN1	=	0x00b8
                           0000A9   275 _IP0	=	0x00a9
                           0000B9   276 _IP1	=	0x00b9
                           0000C0   277 _IRCON	=	0x00c0
                           0000EE   278 _INTDEG	=	0x00ee
                           0000E5   279 _ENHIT	=	0x00e5
                           000093   280 _KBLS	=	0x0093
                           000094   281 _KBE	=	0x0094
                           000095   282 _KBF	=	0x0095
                           000096   283 _KBD	=	0x0096
                           000097   284 _IRCON2	=	0x0097
                           0000A1   285 _RSTS	=	0x00a1
                           0000E6   286 _LVC	=	0x00e6
                           0000E7   287 _SWRES	=	0x00e7
                           0000AB   288 _ADCC1	=	0x00ab
                           0000AC   289 _ADCC2	=	0x00ac
                           0000AD   290 _ADCDH	=	0x00ad
                           0000AE   291 _ADCDL	=	0x00ae
                           0000AF   292 _ADCCS	=	0x00af
                           0000EF   293 _ADCSH	=	0x00ef
                           0000B5   294 _PWMC	=	0x00b5
                           0000BC   295 _PWMD0H	=	0x00bc
                           0000BD   296 _PWMD0L	=	0x00bd
                           0000BE   297 _PWMD1H	=	0x00be
                           0000BF   298 _PWMD1L	=	0x00bf
                           0000B1   299 _PWMD2H	=	0x00b1
                           0000B2   300 _PWMD2L	=	0x00b2
                           0000B3   301 _PWMD3H	=	0x00b3
                           0000B4   302 _PWMD3L	=	0x00b4
                           0000CE   303 _PWMMDH	=	0x00ce
                           0000CF   304 _PWMMDL	=	0x00cf
                           0000B6   305 _WDTC	=	0x00b6
                           0000B7   306 _WDTK	=	0x00b7
                           0000C1   307 _CCEN	=	0x00c1
                           0000D1   308 _CCEN2	=	0x00d1
                           0000C2   309 _CCL1	=	0x00c2
                           0000C3   310 _CCH1	=	0x00c3
                           0000C4   311 _CCL2	=	0x00c4
                           0000C5   312 _CCH2	=	0x00c5
                           0000C6   313 _CCL3	=	0x00c6
                           0000C7   314 _CCH3	=	0x00c7
                           0000C8   315 _T2CON	=	0x00c8
                           0000C9   316 _CCCON	=	0x00c9
                           0000CA   317 _CRCL	=	0x00ca
                           0000CB   318 _CRCH	=	0x00cb
                           0000CC   319 _TL2	=	0x00cc
                           0000CD   320 _TH2	=	0x00cd
                           0000D2   321 _P0M0	=	0x00d2
                           0000D3   322 _P0M1	=	0x00d3
                           0000D4   323 _P1M0	=	0x00d4
                           0000D5   324 _P1M1	=	0x00d5
                           0000DA   325 _P3M0	=	0x00da
                           0000DB   326 _P3M1	=	0x00db
                           0000F1   327 _SPIC1	=	0x00f1
                           0000F2   328 _SPIC2	=	0x00f2
                           0000F3   329 _SPITXD	=	0x00f3
                           0000F4   330 _SPIRXD	=	0x00f4
                           0000F5   331 _SPIS	=	0x00f5
                           0000F8   332 _IICS	=	0x00f8
                           0000F9   333 _IICCTL	=	0x00f9
                           0000FA   334 _IICA1	=	0x00fa
                           0000FB   335 _IICA2	=	0x00fb
                           0000FC   336 _IICRWD	=	0x00fc
                           0000FD   337 _IICEBT	=	0x00fd
                           0000F6   338 _OPPIN	=	0x00f6
                           0000FE   339 _CMP0CON	=	0x00fe
                           0000FF   340 _CMP1CON	=	0x00ff
                           00C3C2   341 _CC1	=	0xc3c2
                           00C5C4   342 _CC2	=	0xc5c4
                           00C7C6   343 _CC3	=	0xc7c6
                           00CBCA   344 _CRC	=	0xcbca
                           00CDCC   345 _T2	=	0xcdcc
                                    346 ;--------------------------------------------------------
                                    347 ; special function bits
                                    348 ;--------------------------------------------------------
                                    349 	.area RSEG    (ABS,DATA)
      000000                        350 	.org 0x0000
                           000080   351 _P0_0	=	0x0080
                           000081   352 _P0_1	=	0x0081
                           000082   353 _P0_2	=	0x0082
                           000083   354 _P0_3	=	0x0083
                           000084   355 _P0_4	=	0x0084
                           000085   356 _P0_5	=	0x0085
                           000086   357 _P0_6	=	0x0086
                           000087   358 _P0_7	=	0x0087
                           000090   359 _P1_0	=	0x0090
                           000091   360 _P1_1	=	0x0091
                           000092   361 _P1_2	=	0x0092
                           000093   362 _P1_3	=	0x0093
                           000094   363 _P1_4	=	0x0094
                           000095   364 _P1_5	=	0x0095
                           000096   365 _P1_6	=	0x0096
                           000097   366 _P1_7	=	0x0097
                           0000B0   367 _P3_0	=	0x00b0
                           0000B2   368 _P3_1	=	0x00b2
                           0000D0   369 _P	=	0x00d0
                           0000D1   370 _F1	=	0x00d1
                           0000D2   371 _OV	=	0x00d2
                           0000D3   372 _RS0	=	0x00d3
                           0000D4   373 _RS1	=	0x00d4
                           0000D5   374 _F0	=	0x00d5
                           0000D6   375 _AC	=	0x00d6
                           0000D7   376 _CY	=	0x00d7
                           000088   377 _IT0	=	0x0088
                           000089   378 _IE0	=	0x0089
                           00008A   379 _IT1	=	0x008a
                           00008B   380 _IE1	=	0x008b
                           00008C   381 _TR0	=	0x008c
                           00008D   382 _TF0	=	0x008d
                           00008E   383 _TR1	=	0x008e
                           00008F   384 _TF1	=	0x008f
                           0000A8   385 _EX0	=	0x00a8
                           0000A9   386 _ET0	=	0x00a9
                           0000AA   387 _EX1	=	0x00aa
                           0000AB   388 _ET1	=	0x00ab
                           0000AC   389 _ES	=	0x00ac
                           0000AD   390 _ET2	=	0x00ad
                           0000AF   391 _EA	=	0x00af
                           000098   392 _RI	=	0x0098
                           000099   393 _TI	=	0x0099
                           00009A   394 _RB8	=	0x009a
                           00009B   395 _TB8	=	0x009b
                           00009C   396 _REN	=	0x009c
                           00009D   397 _SM2	=	0x009d
                           00009E   398 _SM1	=	0x009e
                           00009F   399 _SM0	=	0x009f
                           0000F8   400 _RW	=	0x00f8
                           0000F8   401 _BB	=	0x00f8
                           0000F9   402 _TXAK	=	0x00f9
                           0000FA   403 _RXAK	=	0x00fa
                           0000FB   404 _TXIF	=	0x00fb
                           0000FC   405 _RXIF	=	0x00fc
                           0000FD   406 _LAIF	=	0x00fd
                           0000FE   407 _MPIF	=	0x00fe
                           0000C0   408 _PWMIF	=	0x00c0
                           0000C1   409 _SPIIF	=	0x00c1
                           0000C2   410 _ADCIF	=	0x00c2
                           0000C3   411 _KBIIF	=	0x00c3
                           0000C4   412 _LVIIF	=	0x00c4
                           0000C5   413 _IICIF	=	0x00c5
                           0000C6   414 _TF2	=	0x00c6
                           0000C7   415 _EXF2	=	0x00c7
                           0000B8   416 _IEPWM	=	0x00b8
                           0000B9   417 _IESPI	=	0x00b9
                           0000BA   418 _IEADC	=	0x00ba
                           0000BB   419 _IEKBI	=	0x00bb
                           0000BC   420 _IELVI	=	0x00bc
                           0000BD   421 _IEIIC	=	0x00bd
                           0000BF   422 _EXEN2	=	0x00bf
                                    423 ;--------------------------------------------------------
                                    424 ; overlayable register banks
                                    425 ;--------------------------------------------------------
                                    426 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        427 	.ds 8
                                    428 ;--------------------------------------------------------
                                    429 ; internal ram data
                                    430 ;--------------------------------------------------------
                                    431 	.area DSEG    (DATA)
      00000A                        432 _is_motor_init::
      00000A                        433 	.ds 1
      00000B                        434 _mot1_step::
      00000B                        435 	.ds 1
      00000C                        436 _mot2_step::
      00000C                        437 	.ds 1
      00000D                        438 _mot1_enabled::
      00000D                        439 	.ds 1
      00000E                        440 _mot2_enabled::
      00000E                        441 	.ds 1
      00000F                        442 _mot1_direction::
      00000F                        443 	.ds 1
      000010                        444 _mot2_direction::
      000010                        445 	.ds 1
      000011                        446 _mot1_speed::
      000011                        447 	.ds 1
      000012                        448 _mot2_speed::
      000012                        449 	.ds 1
      000013                        450 _mot1_speed_old::
      000013                        451 	.ds 1
      000014                        452 _mot2_speed_old::
      000014                        453 	.ds 1
      000015                        454 _mot1_speed_tmr::
      000015                        455 	.ds 1
      000016                        456 _mot2_speed_tmr::
      000016                        457 	.ds 1
      000017                        458 _mot1_cnt1::
      000017                        459 	.ds 2
      000019                        460 _mot2_cnt1::
      000019                        461 	.ds 2
                                    462 ;--------------------------------------------------------
                                    463 ; overlayable items in internal ram
                                    464 ;--------------------------------------------------------
                                    465 	.area	OSEG    (OVR,DATA)
                                    466 	.area	OSEG    (OVR,DATA)
                                    467 	.area	OSEG    (OVR,DATA)
                                    468 ;--------------------------------------------------------
                                    469 ; indirectly addressable internal ram data
                                    470 ;--------------------------------------------------------
                                    471 	.area ISEG    (DATA)
                                    472 ;--------------------------------------------------------
                                    473 ; absolute internal ram data
                                    474 ;--------------------------------------------------------
                                    475 	.area IABS    (ABS,DATA)
                                    476 	.area IABS    (ABS,DATA)
                                    477 ;--------------------------------------------------------
                                    478 ; bit data
                                    479 ;--------------------------------------------------------
                                    480 	.area BSEG    (BIT)
                                    481 ;--------------------------------------------------------
                                    482 ; paged external ram data
                                    483 ;--------------------------------------------------------
                                    484 	.area PSEG    (PAG,XDATA)
                                    485 ;--------------------------------------------------------
                                    486 ; uninitialized external ram data
                                    487 ;--------------------------------------------------------
                                    488 	.area XSEG    (XDATA)
                                    489 ;--------------------------------------------------------
                                    490 ; absolute external ram data
                                    491 ;--------------------------------------------------------
                                    492 	.area XABS    (ABS,XDATA)
                                    493 ;--------------------------------------------------------
                                    494 ; initialized external ram data
                                    495 ;--------------------------------------------------------
                                    496 	.area XISEG   (XDATA)
                                    497 	.area HOME    (CODE)
                                    498 	.area GSINIT0 (CODE)
                                    499 	.area GSINIT1 (CODE)
                                    500 	.area GSINIT2 (CODE)
                                    501 	.area GSINIT3 (CODE)
                                    502 	.area GSINIT4 (CODE)
                                    503 	.area GSINIT5 (CODE)
                                    504 	.area GSINIT  (CODE)
                                    505 	.area GSFINAL (CODE)
                                    506 	.area CSEG    (CODE)
                                    507 ;--------------------------------------------------------
                                    508 ; global & static initialisations
                                    509 ;--------------------------------------------------------
                                    510 	.area HOME    (CODE)
                                    511 	.area GSINIT  (CODE)
                                    512 	.area GSFINAL (CODE)
                                    513 	.area GSINIT  (CODE)
                                    514 ;	src/motor.c:7: volatile uint8_t is_motor_init = 0;
      00015C 75 0A 00         [24]  515 	mov	_is_motor_init,#0x00
                                    516 ;	src/motor.c:9: uint8_t mot1_step = 0;
      00015F 75 0B 00         [24]  517 	mov	_mot1_step,#0x00
                                    518 ;	src/motor.c:10: uint8_t mot2_step = 0;
      000162 75 0C 00         [24]  519 	mov	_mot2_step,#0x00
                                    520 ;	src/motor.c:12: uint8_t mot1_enabled = 0;
      000165 75 0D 00         [24]  521 	mov	_mot1_enabled,#0x00
                                    522 ;	src/motor.c:13: uint8_t mot2_enabled = 0;
      000168 75 0E 00         [24]  523 	mov	_mot2_enabled,#0x00
                                    524 ;	src/motor.c:15: uint8_t mot1_direction = MOTOR_CC;
      00016B 75 0F 00         [24]  525 	mov	_mot1_direction,#0x00
                                    526 ;	src/motor.c:16: uint8_t mot2_direction = MOTOR_CC;
      00016E 75 10 00         [24]  527 	mov	_mot2_direction,#0x00
                                    528 ;	src/motor.c:18: uint8_t mot1_speed = 0; // relative to timer0
      000171 75 11 00         [24]  529 	mov	_mot1_speed,#0x00
                                    530 ;	src/motor.c:19: uint8_t mot2_speed = 0; // relative to timer0
      000174 75 12 00         [24]  531 	mov	_mot2_speed,#0x00
                                    532 ;	src/motor.c:21: uint8_t mot1_speed_old = 0; // relative to timer0
      000177 75 13 00         [24]  533 	mov	_mot1_speed_old,#0x00
                                    534 ;	src/motor.c:22: uint8_t mot2_speed_old = 0; // relative to timer0
      00017A 75 14 00         [24]  535 	mov	_mot2_speed_old,#0x00
                                    536 ;	src/motor.c:24: uint8_t mot1_speed_tmr = 200; // relative to timer0
      00017D 75 15 C8         [24]  537 	mov	_mot1_speed_tmr,#0xc8
                                    538 ;	src/motor.c:25: uint8_t mot2_speed_tmr = 200; // relative to timer0
      000180 75 16 C8         [24]  539 	mov	_mot2_speed_tmr,#0xc8
                                    540 ;	src/motor.c:27: uint16_t mot1_cnt1 = 0; // required for preset
      000183 E4               [12]  541 	clr	a
      000184 F5 17            [12]  542 	mov	_mot1_cnt1,a
      000186 F5 18            [12]  543 	mov	(_mot1_cnt1 + 1),a
                                    544 ;	src/motor.c:28: uint16_t mot2_cnt1 = 0; // required for preset
      000188 F5 19            [12]  545 	mov	_mot2_cnt1,a
      00018A F5 1A            [12]  546 	mov	(_mot2_cnt1 + 1),a
                                    547 ;--------------------------------------------------------
                                    548 ; Home
                                    549 ;--------------------------------------------------------
                                    550 	.area HOME    (CODE)
                                    551 	.area HOME    (CODE)
                                    552 ;--------------------------------------------------------
                                    553 ; code
                                    554 ;--------------------------------------------------------
                                    555 	.area CSEG    (CODE)
                                    556 ;------------------------------------------------------------
                                    557 ;Allocation info for local variables in function 'motor_init'
                                    558 ;------------------------------------------------------------
                                    559 ;	src/motor.c:40: void motor_init(void) {
                                    560 ;	-----------------------------------------
                                    561 ;	 function motor_init
                                    562 ;	-----------------------------------------
      0002F7                        563 _motor_init:
                           000007   564 	ar7 = 0x07
                           000006   565 	ar6 = 0x06
                           000005   566 	ar5 = 0x05
                           000004   567 	ar4 = 0x04
                           000003   568 	ar3 = 0x03
                           000002   569 	ar2 = 0x02
                           000001   570 	ar1 = 0x01
                           000000   571 	ar0 = 0x00
                                    572 ;	src/motor.c:41: is_motor_init = 1;
      0002F7 75 0A 01         [24]  573 	mov	_is_motor_init,#0x01
                                    574 ;	src/motor.c:43: motor1_set_speed(SPEED_MAX_REF);
      0002FA 75 82 32         [24]  575 	mov	dpl, #0x32
      0002FD 12 03 58         [24]  576 	lcall	_motor1_set_speed
                                    577 ;	src/motor.c:46: motor1_enable();
      000300 12 03 40         [24]  578 	lcall	_motor1_enable
                                    579 ;	src/motor.c:49: motor1_set_dir(MOVE_CCW);
      000303 75 82 01         [24]  580 	mov	dpl, #0x01
      000306 12 03 90         [24]  581 	lcall	_motor1_set_dir
                                    582 ;	src/motor.c:51: uart_write_Text("Motor 1: go to home, wait...\r\n");
      000309 90 07 2B         [24]  583 	mov	dptr,#___str_0
      00030C 75 F0 80         [24]  584 	mov	b, #0x80
      00030F 12 01 D5         [24]  585 	lcall	_uart_write_Text
                                    586 ;	src/motor.c:53: delay1ms(5000);
      000312 90 13 88         [24]  587 	mov	dptr,#0x1388
      000315 12 04 2B         [24]  588 	lcall	_delay1ms
                                    589 ;	src/motor.c:58: mot1_cnt1 = 0;
      000318 E4               [12]  590 	clr	a
      000319 F5 17            [12]  591 	mov	_mot1_cnt1,a
      00031B F5 18            [12]  592 	mov	(_mot1_cnt1 + 1),a
                                    593 ;	src/motor.c:60: motor2_set_speed(SPEED_MAX_REF);
      00031D 75 82 32         [24]  594 	mov	dpl, #0x32
      000320 12 03 62         [24]  595 	lcall	_motor2_set_speed
                                    596 ;	src/motor.c:66: motor2_set_dir(MOVE_CCW);
      000323 75 82 01         [24]  597 	mov	dpl, #0x01
      000326 12 03 94         [24]  598 	lcall	_motor2_set_dir
                                    599 ;	src/motor.c:68: uart_write_Text("Motor 2: go to home, wait...\r\n");
      000329 90 07 4A         [24]  600 	mov	dptr,#___str_1
      00032C 75 F0 80         [24]  601 	mov	b, #0x80
      00032F 12 01 D5         [24]  602 	lcall	_uart_write_Text
                                    603 ;	src/motor.c:70: delay1ms(5000);
      000332 90 13 88         [24]  604 	mov	dptr,#0x1388
      000335 12 04 2B         [24]  605 	lcall	_delay1ms
                                    606 ;	src/motor.c:75: mot2_cnt1 = 0;
      000338 E4               [12]  607 	clr	a
      000339 F5 19            [12]  608 	mov	_mot2_cnt1,a
      00033B F5 1A            [12]  609 	mov	(_mot2_cnt1 + 1),a
                                    610 ;	src/motor.c:77: is_motor_init = 0;
      00033D F5 0A            [12]  611 	mov	_is_motor_init,a
                                    612 ;	src/motor.c:78: }
      00033F 22               [24]  613 	ret
                                    614 ;------------------------------------------------------------
                                    615 ;Allocation info for local variables in function 'motor1_enable'
                                    616 ;------------------------------------------------------------
                                    617 ;	src/motor.c:80: void motor1_enable(void) {
                                    618 ;	-----------------------------------------
                                    619 ;	 function motor1_enable
                                    620 ;	-----------------------------------------
      000340                        621 _motor1_enable:
                                    622 ;	src/motor.c:81: mot1_enabled = true;
      000340 75 0D 01         [24]  623 	mov	_mot1_enabled,#0x01
                                    624 ;	src/motor.c:83: MOT1EN = mot1_enabled;
                                    625 ;	assignBit
      000343 D2 95            [12]  626 	setb	_P1_5
                                    627 ;	src/motor.c:84: }
      000345 22               [24]  628 	ret
                                    629 ;------------------------------------------------------------
                                    630 ;Allocation info for local variables in function 'motor1_disable'
                                    631 ;------------------------------------------------------------
                                    632 ;	src/motor.c:86: void motor1_disable(void) {
                                    633 ;	-----------------------------------------
                                    634 ;	 function motor1_disable
                                    635 ;	-----------------------------------------
      000346                        636 _motor1_disable:
                                    637 ;	src/motor.c:87: mot1_enabled = false;
      000346 75 0D 00         [24]  638 	mov	_mot1_enabled,#0x00
                                    639 ;	src/motor.c:89: MOT1EN = mot1_enabled;
                                    640 ;	assignBit
      000349 C2 95            [12]  641 	clr	_P1_5
                                    642 ;	src/motor.c:90: }
      00034B 22               [24]  643 	ret
                                    644 ;------------------------------------------------------------
                                    645 ;Allocation info for local variables in function 'motor2_enable'
                                    646 ;------------------------------------------------------------
                                    647 ;	src/motor.c:92: void motor2_enable(void) {
                                    648 ;	-----------------------------------------
                                    649 ;	 function motor2_enable
                                    650 ;	-----------------------------------------
      00034C                        651 _motor2_enable:
                                    652 ;	src/motor.c:93: mot2_enabled = true;
      00034C 75 0E 01         [24]  653 	mov	_mot2_enabled,#0x01
                                    654 ;	src/motor.c:95: MOT2EN = mot2_enabled;
                                    655 ;	assignBit
      00034F D2 84            [12]  656 	setb	_P0_4
                                    657 ;	src/motor.c:96: }
      000351 22               [24]  658 	ret
                                    659 ;------------------------------------------------------------
                                    660 ;Allocation info for local variables in function 'motor2_disable'
                                    661 ;------------------------------------------------------------
                                    662 ;	src/motor.c:98: void motor2_disable(void) {
                                    663 ;	-----------------------------------------
                                    664 ;	 function motor2_disable
                                    665 ;	-----------------------------------------
      000352                        666 _motor2_disable:
                                    667 ;	src/motor.c:99: mot2_enabled = false;
      000352 75 0E 00         [24]  668 	mov	_mot2_enabled,#0x00
                                    669 ;	src/motor.c:101: MOT2EN = mot2_enabled;
                                    670 ;	assignBit
      000355 C2 84            [12]  671 	clr	_P0_4
                                    672 ;	src/motor.c:102: }
      000357 22               [24]  673 	ret
                                    674 ;------------------------------------------------------------
                                    675 ;Allocation info for local variables in function 'motor1_set_speed'
                                    676 ;------------------------------------------------------------
                                    677 ;speed         Allocated to registers 
                                    678 ;------------------------------------------------------------
                                    679 ;	src/motor.c:104: void motor1_set_speed(uint8_t speed) {
                                    680 ;	-----------------------------------------
                                    681 ;	 function motor1_set_speed
                                    682 ;	-----------------------------------------
      000358                        683 _motor1_set_speed:
                                    684 ;	src/motor.c:107: mot1_speed_tmr = motor_speed_calc(mot1_speed);
      000358 85 82 11         [24]  685 	mov  _mot1_speed,dpl
      00035B 12 03 6C         [24]  686 	lcall	_motor_speed_calc
      00035E 85 82 15         [24]  687 	mov	_mot1_speed_tmr,dpl
                                    688 ;	src/motor.c:108: }
      000361 22               [24]  689 	ret
                                    690 ;------------------------------------------------------------
                                    691 ;Allocation info for local variables in function 'motor2_set_speed'
                                    692 ;------------------------------------------------------------
                                    693 ;speed         Allocated to registers 
                                    694 ;------------------------------------------------------------
                                    695 ;	src/motor.c:110: void motor2_set_speed(uint8_t speed) {
                                    696 ;	-----------------------------------------
                                    697 ;	 function motor2_set_speed
                                    698 ;	-----------------------------------------
      000362                        699 _motor2_set_speed:
                                    700 ;	src/motor.c:113: mot2_speed_tmr = motor_speed_calc(mot2_speed);
      000362 85 82 12         [24]  701 	mov  _mot2_speed,dpl
      000365 12 03 6C         [24]  702 	lcall	_motor_speed_calc
      000368 85 82 16         [24]  703 	mov	_mot2_speed_tmr,dpl
                                    704 ;	src/motor.c:114: }
      00036B 22               [24]  705 	ret
                                    706 ;------------------------------------------------------------
                                    707 ;Allocation info for local variables in function 'motor_speed_calc'
                                    708 ;------------------------------------------------------------
                                    709 ;speed         Allocated to registers r7 
                                    710 ;sp_calc       Allocated to registers r7 
                                    711 ;------------------------------------------------------------
                                    712 ;	src/motor.c:116: uint8_t motor_speed_calc(uint8_t speed) {
                                    713 ;	-----------------------------------------
                                    714 ;	 function motor_speed_calc
                                    715 ;	-----------------------------------------
      00036C                        716 _motor_speed_calc:
                                    717 ;	src/motor.c:119: if (speed > SPEED_MAX_REF) {
      00036C E5 82            [12]  718 	mov	a,dpl
      00036E FF               [12]  719 	mov	r7,a
      00036F 24 CD            [12]  720 	add	a,#0xff - 0x32
      000371 50 02            [24]  721 	jnc	00102$
                                    722 ;	src/motor.c:120: speed = SPEED_MAX_REF;
      000373 7F 32            [12]  723 	mov	r7,#0x32
      000375                        724 00102$:
                                    725 ;	src/motor.c:123: if (speed < SPEED_MIN_REF) {
      000375 BF 06 00         [24]  726 	cjne	r7,#0x06,00132$
      000378                        727 00132$:
      000378 50 02            [24]  728 	jnc	00104$
                                    729 ;	src/motor.c:124: speed = SPEED_MIN_REF;
      00037A 7F 06            [12]  730 	mov	r7,#0x06
      00037C                        731 00104$:
                                    732 ;	src/motor.c:127: sp_calc = SPEED_MAX_TMR + ((SPEED_MAX_REF - speed) / 2);
      00037C 74 32            [12]  733 	mov	a,#0x32
      00037E C3               [12]  734 	clr	c
      00037F 9F               [12]  735 	subb	a,r7
      000380 75 F0 02         [24]  736 	mov	b,#0x02
      000383 84               [48]  737 	div	ab
      000384 FF               [12]  738 	mov	r7,a
      000385 0F               [12]  739 	inc	r7
                                    740 ;	src/motor.c:133: if (sp_calc > SPEED_MIN_TMR) {
      000386 EF               [12]  741 	mov	a,r7
      000387 24 EC            [12]  742 	add	a,#0xff - 0x13
      000389 50 02            [24]  743 	jnc	00108$
                                    744 ;	src/motor.c:134: sp_calc = SPEED_MIN_TMR;
      00038B 7F 13            [12]  745 	mov	r7,#0x13
      00038D                        746 00108$:
                                    747 ;	src/motor.c:137: return sp_calc;
      00038D 8F 82            [24]  748 	mov	dpl, r7
                                    749 ;	src/motor.c:138: }
      00038F 22               [24]  750 	ret
                                    751 ;------------------------------------------------------------
                                    752 ;Allocation info for local variables in function 'motor1_set_dir'
                                    753 ;------------------------------------------------------------
                                    754 ;dir           Allocated to registers 
                                    755 ;------------------------------------------------------------
                                    756 ;	src/motor.c:140: void motor1_set_dir(uint8_t dir) {
                                    757 ;	-----------------------------------------
                                    758 ;	 function motor1_set_dir
                                    759 ;	-----------------------------------------
      000390                        760 _motor1_set_dir:
      000390 85 82 0F         [24]  761 	mov	_mot1_direction,dpl
                                    762 ;	src/motor.c:141: mot1_direction = dir;
                                    763 ;	src/motor.c:142: }
      000393 22               [24]  764 	ret
                                    765 ;------------------------------------------------------------
                                    766 ;Allocation info for local variables in function 'motor2_set_dir'
                                    767 ;------------------------------------------------------------
                                    768 ;dir           Allocated to registers 
                                    769 ;------------------------------------------------------------
                                    770 ;	src/motor.c:144: void motor2_set_dir(uint8_t dir) {
                                    771 ;	-----------------------------------------
                                    772 ;	 function motor2_set_dir
                                    773 ;	-----------------------------------------
      000394                        774 _motor2_set_dir:
      000394 85 82 10         [24]  775 	mov	_mot2_direction,dpl
                                    776 ;	src/motor.c:145: mot2_direction = dir;
                                    777 ;	src/motor.c:146: }
      000397 22               [24]  778 	ret
                                    779 ;------------------------------------------------------------
                                    780 ;Allocation info for local variables in function 'motor1_step_cc'
                                    781 ;------------------------------------------------------------
                                    782 ;	src/motor.c:148: void motor1_step_cc(void) {
                                    783 ;	-----------------------------------------
                                    784 ;	 function motor1_step_cc
                                    785 ;	-----------------------------------------
      000398                        786 _motor1_step_cc:
                                    787 ;	src/motor.c:149: if (mot1_cnt1 < 65535) {
      000398 C3               [12]  788 	clr	c
      000399 E5 17            [12]  789 	mov	a,_mot1_cnt1
      00039B 94 FF            [12]  790 	subb	a,#0xff
      00039D E5 18            [12]  791 	mov	a,(_mot1_cnt1 + 1)
      00039F 94 FF            [12]  792 	subb	a,#0xff
      0003A1 50 18            [24]  793 	jnc	00106$
                                    794 ;	src/motor.c:150: mot1_cnt1++;
      0003A3 05 17            [12]  795 	inc	_mot1_cnt1
      0003A5 E4               [12]  796 	clr	a
      0003A6 B5 17 02         [24]  797 	cjne	a,_mot1_cnt1,00121$
      0003A9 05 18            [12]  798 	inc	(_mot1_cnt1 + 1)
      0003AB                        799 00121$:
                                    800 ;	src/motor.c:152: if (mot1_step < 3) {
      0003AB 74 FD            [12]  801 	mov	a,#0x100 - 0x03
      0003AD 25 0B            [12]  802 	add	a,_mot1_step
      0003AF 40 04            [24]  803 	jc	00102$
                                    804 ;	src/motor.c:153: mot1_step++;
      0003B1 05 0B            [12]  805 	inc	_mot1_step
      0003B3 80 03            [24]  806 	sjmp	00103$
      0003B5                        807 00102$:
                                    808 ;	src/motor.c:155: mot1_step = 0;
      0003B5 75 0B 00         [24]  809 	mov	_mot1_step,#0x00
      0003B8                        810 00103$:
                                    811 ;	src/motor.c:158: motor1_output();
                                    812 ;	src/motor.c:160: }
      0003B8 02 03 DA         [24]  813 	ljmp	_motor1_output
      0003BB                        814 00106$:
      0003BB 22               [24]  815 	ret
                                    816 ;------------------------------------------------------------
                                    817 ;Allocation info for local variables in function 'motor1_step_ccw'
                                    818 ;------------------------------------------------------------
                                    819 ;	src/motor.c:162: void motor1_step_ccw(void) {
                                    820 ;	-----------------------------------------
                                    821 ;	 function motor1_step_ccw
                                    822 ;	-----------------------------------------
      0003BC                        823 _motor1_step_ccw:
                                    824 ;	src/motor.c:163: if (mot1_cnt1 > 0) {
      0003BC E5 17            [12]  825 	mov	a,_mot1_cnt1
      0003BE 45 18            [12]  826 	orl	a,(_mot1_cnt1 + 1)
      0003C0 60 17            [24]  827 	jz	00106$
                                    828 ;	src/motor.c:164: mot1_cnt1--;
      0003C2 15 17            [12]  829 	dec	_mot1_cnt1
      0003C4 74 FF            [12]  830 	mov	a,#0xff
      0003C6 B5 17 02         [24]  831 	cjne	a,_mot1_cnt1,00121$
      0003C9 15 18            [12]  832 	dec	(_mot1_cnt1 + 1)
      0003CB                        833 00121$:
                                    834 ;	src/motor.c:166: if (mot1_step > 0) {
      0003CB E5 0B            [12]  835 	mov	a,_mot1_step
      0003CD 60 04            [24]  836 	jz	00102$
                                    837 ;	src/motor.c:167: mot1_step--;
      0003CF 15 0B            [12]  838 	dec	_mot1_step
      0003D1 80 03            [24]  839 	sjmp	00103$
      0003D3                        840 00102$:
                                    841 ;	src/motor.c:169: mot1_step = 3;
      0003D3 75 0B 03         [24]  842 	mov	_mot1_step,#0x03
      0003D6                        843 00103$:
                                    844 ;	src/motor.c:172: motor1_output();
                                    845 ;	src/motor.c:174: }
      0003D6 02 03 DA         [24]  846 	ljmp	_motor1_output
      0003D9                        847 00106$:
      0003D9 22               [24]  848 	ret
                                    849 ;------------------------------------------------------------
                                    850 ;Allocation info for local variables in function 'motor1_output'
                                    851 ;------------------------------------------------------------
                                    852 ;	src/motor.c:176: static void motor1_output(void) {
                                    853 ;	-----------------------------------------
                                    854 ;	 function motor1_output
                                    855 ;	-----------------------------------------
      0003DA                        856 _motor1_output:
                                    857 ;	src/motor.c:177: MOT1PA = steps_phase_1[mot1_step];
      0003DA E5 0B            [12]  858 	mov	a,_mot1_step
      0003DC 90 07 23         [24]  859 	mov	dptr,#_steps_phase_1
      0003DF 93               [24]  860 	movc	a,@a+dptr
      0003E0 24 FF            [12]  861 	add	a,#0xff
      0003E2 92 96            [24]  862 	mov	_P1_6,c
                                    863 ;	src/motor.c:178: MOT1PB = steps_phase_2[mot1_step];
      0003E4 E5 0B            [12]  864 	mov	a,_mot1_step
      0003E6 90 07 27         [24]  865 	mov	dptr,#_steps_phase_2
      0003E9 93               [24]  866 	movc	a,@a+dptr
      0003EA 24 FF            [12]  867 	add	a,#0xff
      0003EC 92 97            [24]  868 	mov	_P1_7,c
                                    869 ;	src/motor.c:179: }
      0003EE 22               [24]  870 	ret
                                    871 ;------------------------------------------------------------
                                    872 ;Allocation info for local variables in function 'motor2_step_cc'
                                    873 ;------------------------------------------------------------
                                    874 ;	src/motor.c:181: void motor2_step_cc(void) {
                                    875 ;	-----------------------------------------
                                    876 ;	 function motor2_step_cc
                                    877 ;	-----------------------------------------
      0003EF                        878 _motor2_step_cc:
                                    879 ;	src/motor.c:182: if (mot2_step < 3) {
      0003EF 74 FD            [12]  880 	mov	a,#0x100 - 0x03
      0003F1 25 0C            [12]  881 	add	a,_mot2_step
      0003F3 40 04            [24]  882 	jc	00102$
                                    883 ;	src/motor.c:183: mot2_step++;
      0003F5 05 0C            [12]  884 	inc	_mot2_step
      0003F7 80 03            [24]  885 	sjmp	00103$
      0003F9                        886 00102$:
                                    887 ;	src/motor.c:185: mot2_step = 0;
      0003F9 75 0C 00         [24]  888 	mov	_mot2_step,#0x00
      0003FC                        889 00103$:
                                    890 ;	src/motor.c:188: motor2_output();
                                    891 ;	src/motor.c:189: }
      0003FC 02 04 0D         [24]  892 	ljmp	_motor2_output
                                    893 ;------------------------------------------------------------
                                    894 ;Allocation info for local variables in function 'motor2_step_ccw'
                                    895 ;------------------------------------------------------------
                                    896 ;	src/motor.c:191: void motor2_step_ccw(void) {
                                    897 ;	-----------------------------------------
                                    898 ;	 function motor2_step_ccw
                                    899 ;	-----------------------------------------
      0003FF                        900 _motor2_step_ccw:
                                    901 ;	src/motor.c:192: if (mot2_step > 0) {
      0003FF E5 0C            [12]  902 	mov	a,_mot2_step
      000401 60 04            [24]  903 	jz	00102$
                                    904 ;	src/motor.c:193: mot2_step--;
      000403 15 0C            [12]  905 	dec	_mot2_step
      000405 80 03            [24]  906 	sjmp	00103$
      000407                        907 00102$:
                                    908 ;	src/motor.c:195: mot2_step = 0;
      000407 75 0C 00         [24]  909 	mov	_mot2_step,#0x00
      00040A                        910 00103$:
                                    911 ;	src/motor.c:198: motor2_output();
                                    912 ;	src/motor.c:199: }
      00040A 02 04 0D         [24]  913 	ljmp	_motor2_output
                                    914 ;------------------------------------------------------------
                                    915 ;Allocation info for local variables in function 'motor2_output'
                                    916 ;------------------------------------------------------------
                                    917 ;	src/motor.c:201: static void motor2_output(void) {
                                    918 ;	-----------------------------------------
                                    919 ;	 function motor2_output
                                    920 ;	-----------------------------------------
      00040D                        921 _motor2_output:
                                    922 ;	src/motor.c:202: MOT2PA = steps_phase_1[mot1_step];
      00040D E5 0B            [12]  923 	mov	a,_mot1_step
      00040F 90 07 23         [24]  924 	mov	dptr,#_steps_phase_1
      000412 93               [24]  925 	movc	a,@a+dptr
      000413 24 FF            [12]  926 	add	a,#0xff
      000415 92 85            [24]  927 	mov	_P0_5,c
                                    928 ;	src/motor.c:203: MOT2PB = steps_phase_2[mot1_step];
      000417 E5 0B            [12]  929 	mov	a,_mot1_step
      000419 90 07 27         [24]  930 	mov	dptr,#_steps_phase_2
      00041C 93               [24]  931 	movc	a,@a+dptr
      00041D 24 FF            [12]  932 	add	a,#0xff
      00041F 92 87            [24]  933 	mov	_P0_7,c
                                    934 ;	src/motor.c:204: }
      000421 22               [24]  935 	ret
                                    936 	.area CSEG    (CODE)
                                    937 	.area CONST   (CODE)
                                    938 	.area CONST   (CODE)
      00071B                        939 _speed_ref:
      00071B 06                     940 	.db #0x06	; 6
      00071C 0C                     941 	.db #0x0c	; 12
      00071D 12                     942 	.db #0x12	; 18
      00071E 19                     943 	.db #0x19	; 25
      00071F 1F                     944 	.db #0x1f	; 31
      000720 25                     945 	.db #0x25	; 37
      000721 2C                     946 	.db #0x2c	; 44
      000722 32                     947 	.db #0x32	; 50	'2'
                                    948 	.area CSEG    (CODE)
                                    949 	.area CONST   (CODE)
      000723                        950 _steps_phase_1:
      000723 01                     951 	.db #0x01	;  1
      000724 00                     952 	.db #0x00	;  0
      000725 00                     953 	.db #0x00	;  0
      000726 01                     954 	.db #0x01	;  1
                                    955 	.area CSEG    (CODE)
                                    956 	.area CONST   (CODE)
      000727                        957 _steps_phase_2:
      000727 01                     958 	.db #0x01	;  1
      000728 01                     959 	.db #0x01	;  1
      000729 00                     960 	.db #0x00	;  0
      00072A 00                     961 	.db #0x00	;  0
                                    962 	.area CSEG    (CODE)
                                    963 	.area CONST   (CODE)
      00072B                        964 ___str_0:
      00072B 4D 6F 74 6F 72 20 31   965 	.ascii "Motor 1: go to home, wait..."
             3A 20 67 6F 20 74 6F
             20 68 6F 6D 65 2C 20
             77 61 69 74 2E 2E 2E
      000747 0D                     966 	.db 0x0d
      000748 0A                     967 	.db 0x0a
      000749 00                     968 	.db 0x00
                                    969 	.area CSEG    (CODE)
                                    970 	.area CONST   (CODE)
      00074A                        971 ___str_1:
      00074A 4D 6F 74 6F 72 20 32   972 	.ascii "Motor 2: go to home, wait..."
             3A 20 67 6F 20 74 6F
             20 68 6F 6D 65 2C 20
             77 61 69 74 2E 2E 2E
      000766 0D                     973 	.db 0x0d
      000767 0A                     974 	.db 0x0a
      000768 00                     975 	.db 0x00
                                    976 	.area CSEG    (CODE)
                                    977 	.area XINIT   (CODE)
                                    978 	.area CABS    (ABS,CODE)
