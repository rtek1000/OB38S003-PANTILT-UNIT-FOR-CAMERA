                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.5.0 #15242 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module hal
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-small
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _EXEN2
                                     12 	.globl _IEIIC
                                     13 	.globl _IELVI
                                     14 	.globl _IEKBI
                                     15 	.globl _IEADC
                                     16 	.globl _IESPI
                                     17 	.globl _IEPWM
                                     18 	.globl _EXF2
                                     19 	.globl _TF2
                                     20 	.globl _IICIF
                                     21 	.globl _LVIIF
                                     22 	.globl _KBIIF
                                     23 	.globl _ADCIF
                                     24 	.globl _SPIIF
                                     25 	.globl _PWMIF
                                     26 	.globl _MPIF
                                     27 	.globl _LAIF
                                     28 	.globl _RXIF
                                     29 	.globl _TXIF
                                     30 	.globl _RXAK
                                     31 	.globl _TXAK
                                     32 	.globl _BB
                                     33 	.globl _RW
                                     34 	.globl _SM0
                                     35 	.globl _SM1
                                     36 	.globl _SM2
                                     37 	.globl _REN
                                     38 	.globl _TB8
                                     39 	.globl _RB8
                                     40 	.globl _TI
                                     41 	.globl _RI
                                     42 	.globl _EA
                                     43 	.globl _ET2
                                     44 	.globl _ES
                                     45 	.globl _ET1
                                     46 	.globl _EX1
                                     47 	.globl _ET0
                                     48 	.globl _EX0
                                     49 	.globl _TF1
                                     50 	.globl _TR1
                                     51 	.globl _TF0
                                     52 	.globl _TR0
                                     53 	.globl _IE1
                                     54 	.globl _IT1
                                     55 	.globl _IE0
                                     56 	.globl _IT0
                                     57 	.globl _CY
                                     58 	.globl _AC
                                     59 	.globl _F0
                                     60 	.globl _RS1
                                     61 	.globl _RS0
                                     62 	.globl _OV
                                     63 	.globl _F1
                                     64 	.globl _P
                                     65 	.globl _P3_1
                                     66 	.globl _P3_0
                                     67 	.globl _P1_7
                                     68 	.globl _P1_6
                                     69 	.globl _P1_5
                                     70 	.globl _P1_4
                                     71 	.globl _P1_3
                                     72 	.globl _P1_2
                                     73 	.globl _P1_1
                                     74 	.globl _P1_0
                                     75 	.globl _P0_7
                                     76 	.globl _P0_6
                                     77 	.globl _P0_5
                                     78 	.globl _P0_4
                                     79 	.globl _P0_3
                                     80 	.globl _P0_2
                                     81 	.globl _P0_1
                                     82 	.globl _P0_0
                                     83 	.globl _T2
                                     84 	.globl _CRC
                                     85 	.globl _CC3
                                     86 	.globl _CC2
                                     87 	.globl _CC1
                                     88 	.globl _CMP1CON
                                     89 	.globl _CMP0CON
                                     90 	.globl _OPPIN
                                     91 	.globl _IICEBT
                                     92 	.globl _IICRWD
                                     93 	.globl _IICA2
                                     94 	.globl _IICA1
                                     95 	.globl _IICCTL
                                     96 	.globl _IICS
                                     97 	.globl _SPIS
                                     98 	.globl _SPIRXD
                                     99 	.globl _SPITXD
                                    100 	.globl _SPIC2
                                    101 	.globl _SPIC1
                                    102 	.globl _P3M1
                                    103 	.globl _P3M0
                                    104 	.globl _P1M1
                                    105 	.globl _P1M0
                                    106 	.globl _P0M1
                                    107 	.globl _P0M0
                                    108 	.globl _TH2
                                    109 	.globl _TL2
                                    110 	.globl _CRCH
                                    111 	.globl _CRCL
                                    112 	.globl _CCCON
                                    113 	.globl _T2CON
                                    114 	.globl _CCH3
                                    115 	.globl _CCL3
                                    116 	.globl _CCH2
                                    117 	.globl _CCL2
                                    118 	.globl _CCH1
                                    119 	.globl _CCL1
                                    120 	.globl _CCEN2
                                    121 	.globl _CCEN
                                    122 	.globl _WDTK
                                    123 	.globl _WDTC
                                    124 	.globl _PWMMDL
                                    125 	.globl _PWMMDH
                                    126 	.globl _PWMD3L
                                    127 	.globl _PWMD3H
                                    128 	.globl _PWMD2L
                                    129 	.globl _PWMD2H
                                    130 	.globl _PWMD1L
                                    131 	.globl _PWMD1H
                                    132 	.globl _PWMD0L
                                    133 	.globl _PWMD0H
                                    134 	.globl _PWMC
                                    135 	.globl _ADCSH
                                    136 	.globl _ADCCS
                                    137 	.globl _ADCDL
                                    138 	.globl _ADCDH
                                    139 	.globl _ADCC2
                                    140 	.globl _ADCC1
                                    141 	.globl _SWRES
                                    142 	.globl _LVC
                                    143 	.globl _RSTS
                                    144 	.globl _IRCON2
                                    145 	.globl _KBD
                                    146 	.globl _KBF
                                    147 	.globl _KBE
                                    148 	.globl _KBLS
                                    149 	.globl _ENHIT
                                    150 	.globl _INTDEG
                                    151 	.globl _IRCON
                                    152 	.globl _IP1
                                    153 	.globl _IP0
                                    154 	.globl _IEN1
                                    155 	.globl _IEN0
                                    156 	.globl _IEN2
                                    157 	.globl _PFCON
                                    158 	.globl _SRELH
                                    159 	.globl _SRELL
                                    160 	.globl _S0RELH
                                    161 	.globl _S0RELL
                                    162 	.globl _S0BUF
                                    163 	.globl _S0CON
                                    164 	.globl _ISPFC
                                    165 	.globl _ISPFDH
                                    166 	.globl _ISPFDL
                                    167 	.globl _ISPFAL
                                    168 	.globl _ISPFAH
                                    169 	.globl _TAKEY
                                    170 	.globl _IFCON
                                    171 	.globl _AUX
                                    172 	.globl _DPH1
                                    173 	.globl _DPL1
                                    174 	.globl _IP
                                    175 	.globl _IE
                                    176 	.globl _SBUF
                                    177 	.globl _SCON
                                    178 	.globl _CKCON
                                    179 	.globl _TH1
                                    180 	.globl _TH0
                                    181 	.globl _TL1
                                    182 	.globl _TL0
                                    183 	.globl _TMOD
                                    184 	.globl _TCON
                                    185 	.globl _PCON
                                    186 	.globl _DPH
                                    187 	.globl _DPL
                                    188 	.globl _SP
                                    189 	.globl _B
                                    190 	.globl _ACC
                                    191 	.globl _PSW
                                    192 	.globl _P3
                                    193 	.globl _P1
                                    194 	.globl _P0
                                    195 	.globl _set_clock_mode
                                    196 	.globl _enable_watchdog
                                    197 	.globl _disable_watchdog
                                    198 	.globl _refresh_watchdog
                                    199 	.globl _reset_mcu
                                    200 	.globl _init_port_pins
                                    201 	.globl _init_uart
                                    202 	.globl _get_capture_flags
                                    203 	.globl _set_capture_flags
                                    204 	.globl _init_timer0_8bit_autoreload
                                    205 	.globl _init_timer1_8bit_autoreload
                                    206 	.globl _init_timer2_as_capture
                                    207 	.globl _pca0_run
                                    208 	.globl _pca0_halt
                                    209 	.globl _get_capture_mode
                                    210 	.globl _clear_capture_flag
                                    211 	.globl _countsToTime
                                    212 ;--------------------------------------------------------
                                    213 ; special function registers
                                    214 ;--------------------------------------------------------
                                    215 	.area RSEG    (ABS,DATA)
      000000                        216 	.org 0x0000
                           000080   217 _P0	=	0x0080
                           000090   218 _P1	=	0x0090
                           0000B0   219 _P3	=	0x00b0
                           0000D0   220 _PSW	=	0x00d0
                           0000E0   221 _ACC	=	0x00e0
                           0000F0   222 _B	=	0x00f0
                           000081   223 _SP	=	0x0081
                           000082   224 _DPL	=	0x0082
                           000083   225 _DPH	=	0x0083
                           000087   226 _PCON	=	0x0087
                           000088   227 _TCON	=	0x0088
                           000089   228 _TMOD	=	0x0089
                           00008A   229 _TL0	=	0x008a
                           00008B   230 _TL1	=	0x008b
                           00008C   231 _TH0	=	0x008c
                           00008D   232 _TH1	=	0x008d
                           00008E   233 _CKCON	=	0x008e
                           000098   234 _SCON	=	0x0098
                           000099   235 _SBUF	=	0x0099
                           0000A8   236 _IE	=	0x00a8
                           0000A9   237 _IP	=	0x00a9
                           000084   238 _DPL1	=	0x0084
                           000085   239 _DPH1	=	0x0085
                           000091   240 _AUX	=	0x0091
                           00008F   241 _IFCON	=	0x008f
                           0000F7   242 _TAKEY	=	0x00f7
                           0000E1   243 _ISPFAH	=	0x00e1
                           0000E2   244 _ISPFAL	=	0x00e2
                           0000E3   245 _ISPFDL	=	0x00e3
                           0000EB   246 _ISPFDH	=	0x00eb
                           0000E4   247 _ISPFC	=	0x00e4
                           000098   248 _S0CON	=	0x0098
                           000099   249 _S0BUF	=	0x0099
                           0000AA   250 _S0RELL	=	0x00aa
                           0000BA   251 _S0RELH	=	0x00ba
                           0000AA   252 _SRELL	=	0x00aa
                           0000BA   253 _SRELH	=	0x00ba
                           0000D9   254 _PFCON	=	0x00d9
                           00009A   255 _IEN2	=	0x009a
                           0000A8   256 _IEN0	=	0x00a8
                           0000B8   257 _IEN1	=	0x00b8
                           0000A9   258 _IP0	=	0x00a9
                           0000B9   259 _IP1	=	0x00b9
                           0000C0   260 _IRCON	=	0x00c0
                           0000EE   261 _INTDEG	=	0x00ee
                           0000E5   262 _ENHIT	=	0x00e5
                           000093   263 _KBLS	=	0x0093
                           000094   264 _KBE	=	0x0094
                           000095   265 _KBF	=	0x0095
                           000096   266 _KBD	=	0x0096
                           000097   267 _IRCON2	=	0x0097
                           0000A1   268 _RSTS	=	0x00a1
                           0000E6   269 _LVC	=	0x00e6
                           0000E7   270 _SWRES	=	0x00e7
                           0000AB   271 _ADCC1	=	0x00ab
                           0000AC   272 _ADCC2	=	0x00ac
                           0000AD   273 _ADCDH	=	0x00ad
                           0000AE   274 _ADCDL	=	0x00ae
                           0000AF   275 _ADCCS	=	0x00af
                           0000EF   276 _ADCSH	=	0x00ef
                           0000B5   277 _PWMC	=	0x00b5
                           0000BC   278 _PWMD0H	=	0x00bc
                           0000BD   279 _PWMD0L	=	0x00bd
                           0000BE   280 _PWMD1H	=	0x00be
                           0000BF   281 _PWMD1L	=	0x00bf
                           0000B1   282 _PWMD2H	=	0x00b1
                           0000B2   283 _PWMD2L	=	0x00b2
                           0000B3   284 _PWMD3H	=	0x00b3
                           0000B4   285 _PWMD3L	=	0x00b4
                           0000CE   286 _PWMMDH	=	0x00ce
                           0000CF   287 _PWMMDL	=	0x00cf
                           0000B6   288 _WDTC	=	0x00b6
                           0000B7   289 _WDTK	=	0x00b7
                           0000C1   290 _CCEN	=	0x00c1
                           0000D1   291 _CCEN2	=	0x00d1
                           0000C2   292 _CCL1	=	0x00c2
                           0000C3   293 _CCH1	=	0x00c3
                           0000C4   294 _CCL2	=	0x00c4
                           0000C5   295 _CCH2	=	0x00c5
                           0000C6   296 _CCL3	=	0x00c6
                           0000C7   297 _CCH3	=	0x00c7
                           0000C8   298 _T2CON	=	0x00c8
                           0000C9   299 _CCCON	=	0x00c9
                           0000CA   300 _CRCL	=	0x00ca
                           0000CB   301 _CRCH	=	0x00cb
                           0000CC   302 _TL2	=	0x00cc
                           0000CD   303 _TH2	=	0x00cd
                           0000D2   304 _P0M0	=	0x00d2
                           0000D3   305 _P0M1	=	0x00d3
                           0000D4   306 _P1M0	=	0x00d4
                           0000D5   307 _P1M1	=	0x00d5
                           0000DA   308 _P3M0	=	0x00da
                           0000DB   309 _P3M1	=	0x00db
                           0000F1   310 _SPIC1	=	0x00f1
                           0000F2   311 _SPIC2	=	0x00f2
                           0000F3   312 _SPITXD	=	0x00f3
                           0000F4   313 _SPIRXD	=	0x00f4
                           0000F5   314 _SPIS	=	0x00f5
                           0000F8   315 _IICS	=	0x00f8
                           0000F9   316 _IICCTL	=	0x00f9
                           0000FA   317 _IICA1	=	0x00fa
                           0000FB   318 _IICA2	=	0x00fb
                           0000FC   319 _IICRWD	=	0x00fc
                           0000FD   320 _IICEBT	=	0x00fd
                           0000F6   321 _OPPIN	=	0x00f6
                           0000FE   322 _CMP0CON	=	0x00fe
                           0000FF   323 _CMP1CON	=	0x00ff
                           00C3C2   324 _CC1	=	0xc3c2
                           00C5C4   325 _CC2	=	0xc5c4
                           00C7C6   326 _CC3	=	0xc7c6
                           00CBCA   327 _CRC	=	0xcbca
                           00CDCC   328 _T2	=	0xcdcc
                                    329 ;--------------------------------------------------------
                                    330 ; special function bits
                                    331 ;--------------------------------------------------------
                                    332 	.area RSEG    (ABS,DATA)
      000000                        333 	.org 0x0000
                           000080   334 _P0_0	=	0x0080
                           000081   335 _P0_1	=	0x0081
                           000082   336 _P0_2	=	0x0082
                           000083   337 _P0_3	=	0x0083
                           000084   338 _P0_4	=	0x0084
                           000085   339 _P0_5	=	0x0085
                           000086   340 _P0_6	=	0x0086
                           000087   341 _P0_7	=	0x0087
                           000090   342 _P1_0	=	0x0090
                           000091   343 _P1_1	=	0x0091
                           000092   344 _P1_2	=	0x0092
                           000093   345 _P1_3	=	0x0093
                           000094   346 _P1_4	=	0x0094
                           000095   347 _P1_5	=	0x0095
                           000096   348 _P1_6	=	0x0096
                           000097   349 _P1_7	=	0x0097
                           0000B0   350 _P3_0	=	0x00b0
                           0000B2   351 _P3_1	=	0x00b2
                           0000D0   352 _P	=	0x00d0
                           0000D1   353 _F1	=	0x00d1
                           0000D2   354 _OV	=	0x00d2
                           0000D3   355 _RS0	=	0x00d3
                           0000D4   356 _RS1	=	0x00d4
                           0000D5   357 _F0	=	0x00d5
                           0000D6   358 _AC	=	0x00d6
                           0000D7   359 _CY	=	0x00d7
                           000088   360 _IT0	=	0x0088
                           000089   361 _IE0	=	0x0089
                           00008A   362 _IT1	=	0x008a
                           00008B   363 _IE1	=	0x008b
                           00008C   364 _TR0	=	0x008c
                           00008D   365 _TF0	=	0x008d
                           00008E   366 _TR1	=	0x008e
                           00008F   367 _TF1	=	0x008f
                           0000A8   368 _EX0	=	0x00a8
                           0000A9   369 _ET0	=	0x00a9
                           0000AA   370 _EX1	=	0x00aa
                           0000AB   371 _ET1	=	0x00ab
                           0000AC   372 _ES	=	0x00ac
                           0000AD   373 _ET2	=	0x00ad
                           0000AF   374 _EA	=	0x00af
                           000098   375 _RI	=	0x0098
                           000099   376 _TI	=	0x0099
                           00009A   377 _RB8	=	0x009a
                           00009B   378 _TB8	=	0x009b
                           00009C   379 _REN	=	0x009c
                           00009D   380 _SM2	=	0x009d
                           00009E   381 _SM1	=	0x009e
                           00009F   382 _SM0	=	0x009f
                           0000F8   383 _RW	=	0x00f8
                           0000F8   384 _BB	=	0x00f8
                           0000F9   385 _TXAK	=	0x00f9
                           0000FA   386 _RXAK	=	0x00fa
                           0000FB   387 _TXIF	=	0x00fb
                           0000FC   388 _RXIF	=	0x00fc
                           0000FD   389 _LAIF	=	0x00fd
                           0000FE   390 _MPIF	=	0x00fe
                           0000C0   391 _PWMIF	=	0x00c0
                           0000C1   392 _SPIIF	=	0x00c1
                           0000C2   393 _ADCIF	=	0x00c2
                           0000C3   394 _KBIIF	=	0x00c3
                           0000C4   395 _LVIIF	=	0x00c4
                           0000C5   396 _IICIF	=	0x00c5
                           0000C6   397 _TF2	=	0x00c6
                           0000C7   398 _EXF2	=	0x00c7
                           0000B8   399 _IEPWM	=	0x00b8
                           0000B9   400 _IESPI	=	0x00b9
                           0000BA   401 _IEADC	=	0x00ba
                           0000BB   402 _IEKBI	=	0x00bb
                           0000BC   403 _IELVI	=	0x00bc
                           0000BD   404 _IEIIC	=	0x00bd
                           0000BF   405 _EXEN2	=	0x00bf
                                    406 ;--------------------------------------------------------
                                    407 ; overlayable register banks
                                    408 ;--------------------------------------------------------
                                    409 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        410 	.ds 8
                                    411 ;--------------------------------------------------------
                                    412 ; internal ram data
                                    413 ;--------------------------------------------------------
                                    414 	.area DSEG    (DATA)
                                    415 ;--------------------------------------------------------
                                    416 ; overlayable items in internal ram
                                    417 ;--------------------------------------------------------
                                    418 	.area	OSEG    (OVR,DATA)
                                    419 	.area	OSEG    (OVR,DATA)
                                    420 ;--------------------------------------------------------
                                    421 ; indirectly addressable internal ram data
                                    422 ;--------------------------------------------------------
                                    423 	.area ISEG    (DATA)
                                    424 ;--------------------------------------------------------
                                    425 ; absolute internal ram data
                                    426 ;--------------------------------------------------------
                                    427 	.area IABS    (ABS,DATA)
                                    428 	.area IABS    (ABS,DATA)
                                    429 ;--------------------------------------------------------
                                    430 ; bit data
                                    431 ;--------------------------------------------------------
                                    432 	.area BSEG    (BIT)
                                    433 ;--------------------------------------------------------
                                    434 ; paged external ram data
                                    435 ;--------------------------------------------------------
                                    436 	.area PSEG    (PAG,XDATA)
                                    437 ;--------------------------------------------------------
                                    438 ; uninitialized external ram data
                                    439 ;--------------------------------------------------------
                                    440 	.area XSEG    (XDATA)
                                    441 ;--------------------------------------------------------
                                    442 ; absolute external ram data
                                    443 ;--------------------------------------------------------
                                    444 	.area XABS    (ABS,XDATA)
                                    445 ;--------------------------------------------------------
                                    446 ; initialized external ram data
                                    447 ;--------------------------------------------------------
                                    448 	.area XISEG   (XDATA)
                                    449 	.area HOME    (CODE)
                                    450 	.area GSINIT0 (CODE)
                                    451 	.area GSINIT1 (CODE)
                                    452 	.area GSINIT2 (CODE)
                                    453 	.area GSINIT3 (CODE)
                                    454 	.area GSINIT4 (CODE)
                                    455 	.area GSINIT5 (CODE)
                                    456 	.area GSINIT  (CODE)
                                    457 	.area GSFINAL (CODE)
                                    458 	.area CSEG    (CODE)
                                    459 ;--------------------------------------------------------
                                    460 ; global & static initialisations
                                    461 ;--------------------------------------------------------
                                    462 	.area HOME    (CODE)
                                    463 	.area GSINIT  (CODE)
                                    464 	.area GSFINAL (CODE)
                                    465 	.area GSINIT  (CODE)
                                    466 ;--------------------------------------------------------
                                    467 ; Home
                                    468 ;--------------------------------------------------------
                                    469 	.area HOME    (CODE)
                                    470 	.area HOME    (CODE)
                                    471 ;--------------------------------------------------------
                                    472 ; code
                                    473 ;--------------------------------------------------------
                                    474 	.area CSEG    (CODE)
                                    475 ;------------------------------------------------------------
                                    476 ;Allocation info for local variables in function 'set_clock_mode'
                                    477 ;------------------------------------------------------------
                                    478 ;	drivers/ob38s003/src/hal.c:12: void set_clock_mode(void) {
                                    479 ;	-----------------------------------------
                                    480 ;	 function set_clock_mode
                                    481 ;	-----------------------------------------
      00044F                        482 _set_clock_mode:
                           000007   483 	ar7 = 0x07
                           000006   484 	ar6 = 0x06
                           000005   485 	ar5 = 0x05
                           000004   486 	ar4 = 0x04
                           000003   487 	ar3 = 0x03
                           000002   488 	ar2 = 0x02
                           000001   489 	ar1 = 0x01
                           000000   490 	ar0 = 0x00
                                    491 ;	drivers/ob38s003/src/hal.c:15: CKCON &= ~0x70;
      00044F 53 8E 8F         [24]  492 	anl	_CKCON,#0x8f
                                    493 ;	drivers/ob38s003/src/hal.c:16: }
      000452 22               [24]  494 	ret
                                    495 ;------------------------------------------------------------
                                    496 ;Allocation info for local variables in function 'enable_watchdog'
                                    497 ;------------------------------------------------------------
                                    498 ;	drivers/ob38s003/src/hal.c:19: void enable_watchdog(void) {
                                    499 ;	-----------------------------------------
                                    500 ;	 function enable_watchdog
                                    501 ;	-----------------------------------------
      000453                        502 _enable_watchdog:
                                    503 ;	drivers/ob38s003/src/hal.c:21: TAKEY = 0x55;
      000453 75 F7 55         [24]  504 	mov	_TAKEY,#0x55
                                    505 ;	drivers/ob38s003/src/hal.c:22: TAKEY = 0xAA;
      000456 75 F7 AA         [24]  506 	mov	_TAKEY,#0xaa
                                    507 ;	drivers/ob38s003/src/hal.c:23: TAKEY = 0x5A;
      000459 75 F7 5A         [24]  508 	mov	_TAKEY,#0x5a
                                    509 ;	drivers/ob38s003/src/hal.c:29: WDTC = 0x28;
      00045C 75 B6 28         [24]  510 	mov	_WDTC,#0x28
                                    511 ;	drivers/ob38s003/src/hal.c:30: }
      00045F 22               [24]  512 	ret
                                    513 ;------------------------------------------------------------
                                    514 ;Allocation info for local variables in function 'disable_watchdog'
                                    515 ;------------------------------------------------------------
                                    516 ;	drivers/ob38s003/src/hal.c:32: void disable_watchdog(void) {
                                    517 ;	-----------------------------------------
                                    518 ;	 function disable_watchdog
                                    519 ;	-----------------------------------------
      000460                        520 _disable_watchdog:
                                    521 ;	drivers/ob38s003/src/hal.c:34: TAKEY = 0x55;
      000460 75 F7 55         [24]  522 	mov	_TAKEY,#0x55
                                    523 ;	drivers/ob38s003/src/hal.c:35: TAKEY = 0xAA;
      000463 75 F7 AA         [24]  524 	mov	_TAKEY,#0xaa
                                    525 ;	drivers/ob38s003/src/hal.c:36: TAKEY = 0x5A;
      000466 75 F7 5A         [24]  526 	mov	_TAKEY,#0x5a
                                    527 ;	drivers/ob38s003/src/hal.c:39: WDTC &= ~0x20;
      000469 53 B6 DF         [24]  528 	anl	_WDTC,#0xdf
                                    529 ;	drivers/ob38s003/src/hal.c:40: }
      00046C 22               [24]  530 	ret
                                    531 ;------------------------------------------------------------
                                    532 ;Allocation info for local variables in function 'refresh_watchdog'
                                    533 ;------------------------------------------------------------
                                    534 ;	drivers/ob38s003/src/hal.c:42: void refresh_watchdog(void) {
                                    535 ;	-----------------------------------------
                                    536 ;	 function refresh_watchdog
                                    537 ;	-----------------------------------------
      00046D                        538 _refresh_watchdog:
                                    539 ;	drivers/ob38s003/src/hal.c:44: WDTK = 0x55;
      00046D 75 B7 55         [24]  540 	mov	_WDTK,#0x55
                                    541 ;	drivers/ob38s003/src/hal.c:45: }
      000470 22               [24]  542 	ret
                                    543 ;------------------------------------------------------------
                                    544 ;Allocation info for local variables in function 'reset_mcu'
                                    545 ;------------------------------------------------------------
                                    546 ;	drivers/ob38s003/src/hal.c:47: void reset_mcu(void) {
                                    547 ;	-----------------------------------------
                                    548 ;	 function reset_mcu
                                    549 ;	-----------------------------------------
      000471                        550 _reset_mcu:
                                    551 ;	drivers/ob38s003/src/hal.c:49: TAKEY = 0x55;
      000471 75 F7 55         [24]  552 	mov	_TAKEY,#0x55
                                    553 ;	drivers/ob38s003/src/hal.c:50: TAKEY = 0xAA;
      000474 75 F7 AA         [24]  554 	mov	_TAKEY,#0xaa
                                    555 ;	drivers/ob38s003/src/hal.c:52: TAKEY = 0x5A;
      000477 75 F7 5A         [24]  556 	mov	_TAKEY,#0x5a
                                    557 ;	drivers/ob38s003/src/hal.c:54: SWRES = 0xFF;
      00047A 75 E7 FF         [24]  558 	mov	_SWRES,#0xff
                                    559 ;	drivers/ob38s003/src/hal.c:55: }
      00047D 22               [24]  560 	ret
                                    561 ;------------------------------------------------------------
                                    562 ;Allocation info for local variables in function 'init_port_pins'
                                    563 ;------------------------------------------------------------
                                    564 ;	drivers/ob38s003/src/hal.c:57: void init_port_pins(void) {
                                    565 ;	-----------------------------------------
                                    566 ;	 function init_port_pins
                                    567 ;	-----------------------------------------
      00047E                        568 _init_port_pins:
                                    569 ;	drivers/ob38s003/src/hal.c:62: P1M1 &= ~0x01;
      00047E 53 D5 FE         [24]  570 	anl	_P1M1,#0xfe
                                    571 ;	drivers/ob38s003/src/hal.c:63: P1M0 |= 0x01;
      000481 43 D4 01         [24]  572 	orl	_P1M0,#0x01
                                    573 ;	drivers/ob38s003/src/hal.c:66: P1M1 &= ~0x20;
      000484 53 D5 DF         [24]  574 	anl	_P1M1,#0xdf
                                    575 ;	drivers/ob38s003/src/hal.c:67: P1M0 |= 0x20;
      000487 43 D4 20         [24]  576 	orl	_P1M0,#0x20
                                    577 ;	drivers/ob38s003/src/hal.c:70: P1M1 &= ~0x40;
      00048A 53 D5 BF         [24]  578 	anl	_P1M1,#0xbf
                                    579 ;	drivers/ob38s003/src/hal.c:71: P1M0 |= 0x40;
      00048D 43 D4 40         [24]  580 	orl	_P1M0,#0x40
                                    581 ;	drivers/ob38s003/src/hal.c:74: P1M1 &= ~0x80;
      000490 53 D5 7F         [24]  582 	anl	_P1M1,#0x7f
                                    583 ;	drivers/ob38s003/src/hal.c:75: P1M0 |= 0x80;
      000493 43 D4 80         [24]  584 	orl	_P1M0,#0x80
                                    585 ;	drivers/ob38s003/src/hal.c:82: P0M1 &= ~0x20;
      000496 53 D3 DF         [24]  586 	anl	_P0M1,#0xdf
                                    587 ;	drivers/ob38s003/src/hal.c:83: P0M0 |= 0x20;
      000499 43 D2 20         [24]  588 	orl	_P0M0,#0x20
                                    589 ;	drivers/ob38s003/src/hal.c:86: P0M1 &= ~0x80;
      00049C 53 D3 7F         [24]  590 	anl	_P0M1,#0x7f
                                    591 ;	drivers/ob38s003/src/hal.c:87: P0M0 |= 0x80;
      00049F 43 D2 80         [24]  592 	orl	_P0M0,#0x80
                                    593 ;	drivers/ob38s003/src/hal.c:98: P1M1 &= ~0x01;
      0004A2 53 D5 FE         [24]  594 	anl	_P1M1,#0xfe
                                    595 ;	drivers/ob38s003/src/hal.c:99: P1M0 |= 0x01;
      0004A5 43 D4 01         [24]  596 	orl	_P1M0,#0x01
                                    597 ;	drivers/ob38s003/src/hal.c:119: }
      0004A8 22               [24]  598 	ret
                                    599 ;------------------------------------------------------------
                                    600 ;Allocation info for local variables in function 'init_uart'
                                    601 ;------------------------------------------------------------
                                    602 ;	drivers/ob38s003/src/hal.c:121: void init_uart(void) {
                                    603 ;	-----------------------------------------
                                    604 ;	 function init_uart
                                    605 ;	-----------------------------------------
      0004A9                        606 _init_uart:
                                    607 ;	drivers/ob38s003/src/hal.c:123: AUX |= 0x80;
      0004A9 43 91 80         [24]  608 	orl	_AUX,#0x80
                                    609 ;	drivers/ob38s003/src/hal.c:126: SM1 = 1;
                                    610 ;	assignBit
      0004AC D2 9E            [12]  611 	setb	_SM1
                                    612 ;	drivers/ob38s003/src/hal.c:129: PCON |= 0x80;
      0004AE 43 87 80         [24]  613 	orl	_PCON,#0x80
                                    614 ;	drivers/ob38s003/src/hal.c:132: PFCON |= 0x10;
      0004B1 43 D9 10         [24]  615 	orl	_PFCON,#0x10
                                    616 ;	drivers/ob38s003/src/hal.c:141: SRELH = 0x03;
      0004B4 75 BA 03         [24]  617 	mov	_SRELH,#0x03
                                    618 ;	drivers/ob38s003/src/hal.c:142: SRELL = 0x98;
      0004B7 75 AA 98         [24]  619 	mov	_SRELL,#0x98
                                    620 ;	drivers/ob38s003/src/hal.c:147: }
      0004BA 22               [24]  621 	ret
                                    622 ;------------------------------------------------------------
                                    623 ;Allocation info for local variables in function 'get_capture_flags'
                                    624 ;------------------------------------------------------------
                                    625 ;	drivers/ob38s003/src/hal.c:149: uint8_t get_capture_flags(void) {
                                    626 ;	-----------------------------------------
                                    627 ;	 function get_capture_flags
                                    628 ;	-----------------------------------------
      0004BB                        629 _get_capture_flags:
                                    630 ;	drivers/ob38s003/src/hal.c:150: return CCCON;
      0004BB 85 C9 82         [24]  631 	mov	dpl, _CCCON
                                    632 ;	drivers/ob38s003/src/hal.c:151: }
      0004BE 22               [24]  633 	ret
                                    634 ;------------------------------------------------------------
                                    635 ;Allocation info for local variables in function 'set_capture_flags'
                                    636 ;------------------------------------------------------------
                                    637 ;flags         Allocated to registers 
                                    638 ;------------------------------------------------------------
                                    639 ;	drivers/ob38s003/src/hal.c:153: void set_capture_flags(const uint8_t flags) {
                                    640 ;	-----------------------------------------
                                    641 ;	 function set_capture_flags
                                    642 ;	-----------------------------------------
      0004BF                        643 _set_capture_flags:
      0004BF 85 82 C9         [24]  644 	mov	_CCCON,dpl
                                    645 ;	drivers/ob38s003/src/hal.c:154: CCCON = flags;
                                    646 ;	drivers/ob38s003/src/hal.c:155: }
      0004C2 22               [24]  647 	ret
                                    648 ;------------------------------------------------------------
                                    649 ;Allocation info for local variables in function 'init_timer0_8bit_autoreload'
                                    650 ;------------------------------------------------------------
                                    651 ;	drivers/ob38s003/src/hal.c:157: void init_timer0_8bit_autoreload(void) {
                                    652 ;	-----------------------------------------
                                    653 ;	 function init_timer0_8bit_autoreload
                                    654 ;	-----------------------------------------
      0004C3                        655 _init_timer0_8bit_autoreload:
                                    656 ;	drivers/ob38s003/src/hal.c:161: TMOD |= 0x02;
      0004C3 43 89 02         [24]  657 	orl	_TMOD,#0x02
                                    658 ;	drivers/ob38s003/src/hal.c:166: }
      0004C6 22               [24]  659 	ret
                                    660 ;------------------------------------------------------------
                                    661 ;Allocation info for local variables in function 'init_timer1_8bit_autoreload'
                                    662 ;------------------------------------------------------------
                                    663 ;	drivers/ob38s003/src/hal.c:168: void init_timer1_8bit_autoreload(void) {
                                    664 ;	-----------------------------------------
                                    665 ;	 function init_timer1_8bit_autoreload
                                    666 ;	-----------------------------------------
      0004C7                        667 _init_timer1_8bit_autoreload:
                                    668 ;	drivers/ob38s003/src/hal.c:172: TMOD |= 0x20;
      0004C7 43 89 20         [24]  669 	orl	_TMOD,#0x20
                                    670 ;	drivers/ob38s003/src/hal.c:180: }
      0004CA 22               [24]  671 	ret
                                    672 ;------------------------------------------------------------
                                    673 ;Allocation info for local variables in function 'init_timer2_as_capture'
                                    674 ;------------------------------------------------------------
                                    675 ;	drivers/ob38s003/src/hal.c:185: void init_timer2_as_capture(void) {
                                    676 ;	-----------------------------------------
                                    677 ;	 function init_timer2_as_capture
                                    678 ;	-----------------------------------------
      0004CB                        679 _init_timer2_as_capture:
                                    680 ;	drivers/ob38s003/src/hal.c:188: CCEN = 0x60;
      0004CB 75 C1 60         [24]  681 	mov	_CCEN,#0x60
                                    682 ;	drivers/ob38s003/src/hal.c:196: T2CON = 0x81;
      0004CE 75 C8 81         [24]  683 	mov	_T2CON,#0x81
                                    684 ;	drivers/ob38s003/src/hal.c:197: }
      0004D1 22               [24]  685 	ret
                                    686 ;------------------------------------------------------------
                                    687 ;Allocation info for local variables in function 'pca0_run'
                                    688 ;------------------------------------------------------------
                                    689 ;	drivers/ob38s003/src/hal.c:201: void pca0_run(void) {
                                    690 ;	-----------------------------------------
                                    691 ;	 function pca0_run
                                    692 ;	-----------------------------------------
      0004D2                        693 _pca0_run:
                                    694 ;	drivers/ob38s003/src/hal.c:203: T2CON &= ~0x03;
      0004D2 53 C8 FC         [24]  695 	anl	_T2CON,#0xfc
                                    696 ;	drivers/ob38s003/src/hal.c:205: T2CON |= 0x01;
      0004D5 43 C8 01         [24]  697 	orl	_T2CON,#0x01
                                    698 ;	drivers/ob38s003/src/hal.c:206: }
      0004D8 22               [24]  699 	ret
                                    700 ;------------------------------------------------------------
                                    701 ;Allocation info for local variables in function 'pca0_halt'
                                    702 ;------------------------------------------------------------
                                    703 ;	drivers/ob38s003/src/hal.c:208: void pca0_halt(void) {
                                    704 ;	-----------------------------------------
                                    705 ;	 function pca0_halt
                                    706 ;	-----------------------------------------
      0004D9                        707 _pca0_halt:
                                    708 ;	drivers/ob38s003/src/hal.c:210: T2CON &= ~0x03;
      0004D9 53 C8 FC         [24]  709 	anl	_T2CON,#0xfc
                                    710 ;	drivers/ob38s003/src/hal.c:211: }
      0004DC 22               [24]  711 	ret
                                    712 ;------------------------------------------------------------
                                    713 ;Allocation info for local variables in function 'get_capture_mode'
                                    714 ;------------------------------------------------------------
                                    715 ;	drivers/ob38s003/src/hal.c:213: uint16_t get_capture_mode(void) {
                                    716 ;	-----------------------------------------
                                    717 ;	 function get_capture_mode
                                    718 ;	-----------------------------------------
      0004DD                        719 _get_capture_mode:
                                    720 ;	drivers/ob38s003/src/hal.c:215: return (CCH1 << 8) | CCL1;
      0004DD AF C3            [24]  721 	mov	r7,_CCH1
      0004DF 7E 00            [12]  722 	mov	r6,#0x00
      0004E1 AC C2            [24]  723 	mov	r4,_CCL1
      0004E3 7D 00            [12]  724 	mov	r5,#0x00
      0004E5 EC               [12]  725 	mov	a,r4
      0004E6 42 06            [12]  726 	orl	ar6,a
      0004E8 ED               [12]  727 	mov	a,r5
      0004E9 42 07            [12]  728 	orl	ar7,a
      0004EB 8E 82            [24]  729 	mov	dpl,r6
      0004ED 8F 83            [24]  730 	mov	dph,r7
                                    731 ;	drivers/ob38s003/src/hal.c:216: }
      0004EF 22               [24]  732 	ret
                                    733 ;------------------------------------------------------------
                                    734 ;Allocation info for local variables in function 'clear_capture_flag'
                                    735 ;------------------------------------------------------------
                                    736 ;	drivers/ob38s003/src/hal.c:218: void clear_capture_flag(void) {
                                    737 ;	-----------------------------------------
                                    738 ;	 function clear_capture_flag
                                    739 ;	-----------------------------------------
      0004F0                        740 _clear_capture_flag:
                                    741 ;	drivers/ob38s003/src/hal.c:220: CCCON &= ~0x02;
      0004F0 53 C9 FD         [24]  742 	anl	_CCCON,#0xfd
                                    743 ;	drivers/ob38s003/src/hal.c:221: }
      0004F3 22               [24]  744 	ret
                                    745 ;------------------------------------------------------------
                                    746 ;Allocation info for local variables in function 'countsToTime'
                                    747 ;------------------------------------------------------------
                                    748 ;counts        Allocated to registers r6 r7 
                                    749 ;duration      Allocated to registers 
                                    750 ;------------------------------------------------------------
                                    751 ;	drivers/ob38s003/src/hal.c:224: uint16_t countsToTime(const uint16_t counts) {
                                    752 ;	-----------------------------------------
                                    753 ;	 function countsToTime
                                    754 ;	-----------------------------------------
      0004F4                        755 _countsToTime:
                                    756 ;	drivers/ob38s003/src/hal.c:231: duration = counts >> 1;
      0004F4 E5 83            [12]  757 	mov	a,dph
      0004F6 C3               [12]  758 	clr	c
      0004F7 13               [12]  759 	rrc	a
      0004F8 C5 82            [12]  760 	xch	a,dpl
      0004FA 13               [12]  761 	rrc	a
      0004FB C5 82            [12]  762 	xch	a,dpl
      0004FD F5 83            [12]  763 	mov	dph,a
                                    764 ;	drivers/ob38s003/src/hal.c:233: return duration;
                                    765 ;	drivers/ob38s003/src/hal.c:234: }
      0004FF 22               [24]  766 	ret
                                    767 	.area CSEG    (CODE)
                                    768 	.area CONST   (CODE)
                                    769 	.area XINIT   (CODE)
                                    770 	.area CABS    (ABS,CODE)
