// uncomment only one define at a time
//#define USE_SOFTWIRE_LIBRARY
// I think SoftwareWire only supports AVR
//#define USE_SOFTWAREWIRE_LIBRARY
// hardware i2c
#define USE_WIRE_LIBRARY